﻿namespace FlexEthernet {
    partial class Collector {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent() {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btEnviar = new System.Windows.Forms.Button();
            this.btLimparEnvio = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEnviar = new System.Windows.Forms.TextBox();
            this.lbStatus = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btConectar = new System.Windows.Forms.Button();
            this.txtPorta = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIp = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRecebido = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btLimparRecebido = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btEnviar);
            this.panel1.Controls.Add(this.btLimparEnvio);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtEnviar);
            this.panel1.Controls.Add(this.lbStatus);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btConectar);
            this.panel1.Controls.Add(this.txtPorta);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtIp);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(567, 243);
            this.panel1.TabIndex = 0;
            // 
            // btEnviar
            // 
            this.btEnviar.Location = new System.Drawing.Point(402, 205);
            this.btEnviar.Name = "btEnviar";
            this.btEnviar.Size = new System.Drawing.Size(75, 23);
            this.btEnviar.TabIndex = 10;
            this.btEnviar.Text = "Enviar";
            this.btEnviar.UseVisualStyleBackColor = true;
            this.btEnviar.Click += new System.EventHandler(this.btEnviar_Click);
            // 
            // btLimparEnvio
            // 
            this.btLimparEnvio.Location = new System.Drawing.Point(483, 205);
            this.btLimparEnvio.Name = "btLimparEnvio";
            this.btLimparEnvio.Size = new System.Drawing.Size(75, 23);
            this.btLimparEnvio.TabIndex = 9;
            this.btLimparEnvio.Text = "Limpar";
            this.btLimparEnvio.UseVisualStyleBackColor = true;
            this.btLimparEnvio.Click += new System.EventHandler(this.btLimparEnvio_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Enviar:";
            // 
            // txtEnviar
            // 
            this.txtEnviar.Location = new System.Drawing.Point(6, 114);
            this.txtEnviar.Multiline = true;
            this.txtEnviar.Name = "txtEnviar";
            this.txtEnviar.Size = new System.Drawing.Size(553, 84);
            this.txtEnviar.TabIndex = 7;
            // 
            // lbStatus
            // 
            this.lbStatus.AutoSize = true;
            this.lbStatus.Location = new System.Drawing.Point(53, 56);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(65, 13);
            this.lbStatus.TabIndex = 6;
            this.lbStatus.Text = "Aguardando";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Status:";
            // 
            // btConectar
            // 
            this.btConectar.Location = new System.Drawing.Point(416, 6);
            this.btConectar.Name = "btConectar";
            this.btConectar.Size = new System.Drawing.Size(143, 23);
            this.btConectar.TabIndex = 4;
            this.btConectar.Text = "Conectar";
            this.btConectar.UseVisualStyleBackColor = true;
            this.btConectar.Click += new System.EventHandler(this.btConectar_Click);
            // 
            // txtPorta
            // 
            this.txtPorta.Location = new System.Drawing.Point(284, 8);
            this.txtPorta.Name = "txtPorta";
            this.txtPorta.Size = new System.Drawing.Size(115, 20);
            this.txtPorta.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(246, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Porta";
            // 
            // txtIp
            // 
            this.txtIp.Location = new System.Drawing.Point(29, 8);
            this.txtIp.Name = "txtIp";
            this.txtIp.Size = new System.Drawing.Size(211, 20);
            this.txtIp.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "IP:";
            // 
            // txtRecebido
            // 
            this.txtRecebido.Location = new System.Drawing.Point(12, 302);
            this.txtRecebido.Multiline = true;
            this.txtRecebido.Name = "txtRecebido";
            this.txtRecebido.ReadOnly = true;
            this.txtRecebido.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRecebido.Size = new System.Drawing.Size(567, 245);
            this.txtRecebido.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 286);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Recebido:";
            // 
            // btLimparRecebido
            // 
            this.btLimparRecebido.Location = new System.Drawing.Point(503, 554);
            this.btLimparRecebido.Name = "btLimparRecebido";
            this.btLimparRecebido.Size = new System.Drawing.Size(75, 23);
            this.btLimparRecebido.TabIndex = 3;
            this.btLimparRecebido.Text = "Limpar";
            this.btLimparRecebido.UseVisualStyleBackColor = true;
            this.btLimparRecebido.Click += new System.EventHandler(this.btLimparRecebido_Click);
            // 
            // Collector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 587);
            this.Controls.Add(this.btLimparRecebido);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtRecebido);
            this.Controls.Add(this.panel1);
            this.Name = "Collector";
            this.Text = " M-ID10W Ethernet Collector";
            this.Load += new System.EventHandler(this.Collector_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btConectar;
        private System.Windows.Forms.TextBox txtPorta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btEnviar;
        private System.Windows.Forms.Button btLimparEnvio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtEnviar;
        private System.Windows.Forms.TextBox txtRecebido;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btLimparRecebido;
    }
}

