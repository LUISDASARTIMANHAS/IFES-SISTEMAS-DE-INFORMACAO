﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlexEthernet {
    public partial class Collector : Form {

        TcpClient server;
        StreamReader reader;
        StreamWriter writer;
        String sIp = String.Empty;
        int iPorta = 0;

        NetworkStream networkStream;
        Thread th;
        Thread Rec;




        public Collector() {
            InitializeComponent();
            lbStatus.Text = "Desconectado";
        }

        private void btConectar_Click(object sender, EventArgs e) {

            if (String.IsNullOrWhiteSpace(txtIp.Text)) {
                MessageBox.Show("Digite o IP!");
            }
            else {
                if (String.IsNullOrWhiteSpace(txtPorta.Text)) {
                    MessageBox.Show("Digite a Porta!");
                }
                else {
                    sIp = txtIp.Text;
                    iPorta = Int32.Parse(txtPorta.Text);
                }

                Console.WriteLine("Conectando no servidor...");
                server = new TcpClient(sIp, iPorta);
                Console.WriteLine("Cliente connectado!");

                networkStream = server.GetStream();

                reader = new StreamReader(networkStream);
                writer = new StreamWriter(networkStream);

                Rec = new Thread(Receiver);
                Rec.Start();
            }
        }

        private void AtualizarTexto(StringBuilder texto) {
            if (this.txtRecebido.InvokeRequired) {
                this.txtRecebido.BeginInvoke((MethodInvoker)delegate () { this.txtRecebido.AppendText(texto.ToString()); });
            }
            else {
                this.txtRecebido.AppendText(texto.ToString());
            }
        }

        private void Receiver() {
            
            while (true) {
                if (networkStream.CanRead) {
                    byte[] myReadBuffer = new byte[1024];
                    StringBuilder myCompleteMessage = new StringBuilder();
                    int numberOfBytesRead = 0;

                    // Se a mensagem for maior que o buffer ele vai concatenando.
                    do {
                        numberOfBytesRead = networkStream.Read(myReadBuffer, 0, myReadBuffer.Length);

                        myCompleteMessage.AppendFormat("{0}", Encoding.ASCII.GetString(myReadBuffer, 0, numberOfBytesRead));
                    }
                    while (networkStream.DataAvailable);

                    // Atualiza a caixa de texto
                   AtualizarTexto(myCompleteMessage);


                }
                else {
                    Console.WriteLine("Sorry.  You cannot read from this NetworkStream.");
                }
            }

        }

        //Envia o código para a Antena
        private void Sender() {
            try {
                String data = txtEnviar.Text;

                writer.WriteLine(data);
                writer.Flush();

                Console.WriteLine("Terminou Envio");
                
            }
            catch (SocketException ex) {
                Console.WriteLine(ex);
            }

        }

        private void btEnviar_Click(object sender, EventArgs e) {
            Sender();
            
        }

        private void btLimparEnvio_Click(object sender, EventArgs e) {
            txtEnviar.Text = "";
        }

        private void btLimparRecebido_Click(object sender, EventArgs e) {
            txtRecebido.Text = "";
        }

        private void Collector_Load(object sender, EventArgs e) {

        }
    }
}

