﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace RFID
{
    public class CFComApi
    {
        /******** Func: Open Device *******************************/
        //  Param: pcCom: COM, Value: "COM1" , "COM2" ....
        //        iBaudRate:Baudrate from 4800bps to 115200bps  device default BaudRate is 115200bps
        //  Return: Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_OpenDevice(string pcCom, int iBaudRate);

        /******** Func: Close Device *******************************/
        //  Param: None
        //  Return: Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_CloseDevice();
        
        /******** Func: GetDeviceInfo. 9Bytes**********/
        //  Param:  bDevAdr:0xFF
        //          pucSystemInfo:SysInfo  9Bytes 1:SoftVer 2:HardVer 3 - 9:DeviceSN
        //  Return: Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_GetDeviceSystemInfo(byte bDevAdr, byte[] pucSystemInfo);

        /******** Func: Get Device One Param**********/
        //  Param: bDevAdr: 0xFF
        //         pucDevParamAddr: Param Addr			
        //         pValue:Return Param Value 
        //  Return:Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_ReadDeviceOneParam(byte bDevAdr, byte pucDevParamAddr, byte[] pValue);

        /******** Func: Set Device One Param**********/
        //  Param: bDevAdr: 0xFF
        //         pucDevParamAddr: Param Addr		
        //         bValue:Param	
        //  Return:Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_SetDeviceOneParam(byte bDevAdr, byte pucDevParamAddr, byte bValue);
        
        /******** Func: Stop all RF reading**********/
        //  Param:  bDevAdr:0xFF
        //  Return: Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_StopRead(byte bDevAdr);
        
        /******** Func: Start all RF reading**********/
        //  Param:  bDevAdr:0xFF
        //  Return: Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_StartRead(byte bDevAdr);

        /*
         * Callback function prototype
         * msg == 0: Device Insert
         * msg == 1: Device Out
         * msg == 2: param1 means tag number, param2 means tagdata, param3 means tagdata length, param4 means DevSN
         */
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void CallbackDelegate(int msg, int param1, IntPtr param2, int param3, IntPtr param4);

        [DllImport("CFComApi.dll", EntryPoint = "CFCom_SetCallback")]
        internal static extern int CFCom_SetCallback(CallbackDelegate pfAddr);

        /******** Func: Inventory EPC**********/
        //  Param: bDevAdr: 0xFF
        //         pBuffer: Get Buffer
        //         Totallen: Get Buffer Length
        //         CardNum:  Tag Number
        //  Return: Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_InventoryG2(byte bDevAdr, byte[] pBuffer, out ushort Totallen, out ushort CardNum);

        /******** Func: Write EPC**********/
        //  Param: bDevAdr: 0xFF
        //         Password: Password (4 bytes)
        //         WriteEPC: Write Data
        //         WriteEPClen: Write Length
        //  Return: Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_WriteEPCG2(byte bDevAdr, byte[] Password, byte[] WriteEPC, byte WriteEPClen);

        /******** Func: Read Card**********/
        //  Param: bDevAdr: 0xFF
        //         Password: Password (4 bytes)
        //         Mem:      0:Reserved 1:EPC 2:TID 3:USER
        //         WordPtr:  Start Address 
        //         ReadEPClen: Read Length
        //         Data: Read Data
        //  Return: Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_ReadCardG2(byte bDevAdr, byte[] Password, byte Mem, byte WordPtr, byte ReadEPClen, byte[] Data);

        /******** Func: Write Card**********/
        //  Param: bDevAdr: 0xFF
        //         Password: Password (4 bytes)
        //         Mem:      0:Reserved 1:EPC 2:TID 3:USER
        //         WordPtr:  Start Address 
        //         WriteEPC: Write Data
        //         WriteEPClen: Write Length
        //  Return: Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_WriteCardG2(byte bDevAdr, byte[] Password, byte Mem, byte WordPtr, byte Writelen, byte[] Writedata);
    
        /******** Func: RelayOn**********/
        //  Param: bDevAdr:  0xFF
        //  Return:Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_RelayOn(byte bDevAdr);

        /******** Func: RelayOff**********/
        //  Param: bDevAdr:  0xFF
        //  Return:Success return 1, failed return 0
        /*********************************************************/
        [DllImport("CFComApi.dll")]
        public static extern bool CFCom_RelayOff(byte bDevAdr);
    }
}
