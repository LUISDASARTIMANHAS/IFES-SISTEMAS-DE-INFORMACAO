﻿namespace ViaondaAgentEmuladorTeclado
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbMid10Sv2 = new System.Windows.Forms.CheckBox();
            this.cbSerialUsb = new System.Windows.Forms.CheckBox();
            this.cbEthernet = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.ComboBox_baud2 = new System.Windows.Forms.ComboBox();
            this.ComboBox_COM = new System.Windows.Forms.ComboBox();
            this.txtPortaLeitor = new System.Windows.Forms.TextBox();
            this.txtIpLeitor = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.nudReadTagInterval = new System.Windows.Forms.NumericUpDown();
            this.cbEnableInterval = new System.Windows.Forms.CheckBox();
            this.cbNoRepeat = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.cbGravarLog = new System.Windows.Forms.CheckBox();
            this.cbIgnorarZeros = new System.Windows.Forms.CheckBox();
            this.cbHabilitarEmulacao = new System.Windows.Forms.CheckBox();
            this.nudPosicaoFinal = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.nudPosicaoInicial = new System.Windows.Forms.NumericUpDown();
            this.cbConvertHexDec = new System.Windows.Forms.CheckBox();
            this.cbTraduzirEPC = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbEnviarEnter = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbIniciarMinimizado = new System.Windows.Forms.CheckBox();
            this.cbConectarIniciar = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtLeitura = new System.Windows.Forms.TextBox();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnMinimizar = new System.Windows.Forms.Button();
            this.btnEncerrar = new System.Windows.Forms.Button();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.mnEncerrar = new System.Windows.Forms.ToolStripMenuItem();
            this.btnReconectar = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tagConfigGerais = new System.Windows.Forms.TabPage();
            this.tagConfigRFID = new System.Windows.Forms.TabPage();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txtMACAddr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txtNewMask = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNewIP = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.ComboBox_scantime = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.Button5 = new System.Windows.Forms.Button();
            this.ComboBox_dmaxfre = new System.Windows.Forms.ComboBox();
            this.ComboBox_dminfre = new System.Windows.Forms.ComboBox();
            this.ComboBox_PowerDbm = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.radioButton_band5 = new System.Windows.Forms.RadioButton();
            this.radioButton_band4 = new System.Windows.Forms.RadioButton();
            this.radioButton_band3 = new System.Windows.Forms.RadioButton();
            this.radioButton_band2 = new System.Windows.Forms.RadioButton();
            this.radioButton_band1 = new System.Windows.Forms.RadioButton();
            this.Edit_Version = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.Timer_Test_ = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudReadTagInterval)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPosicaoFinal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPosicaoInicial)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tagConfigGerais.SuspendLayout();
            this.tagConfigRFID.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbMid10Sv2);
            this.groupBox1.Controls.Add(this.cbSerialUsb);
            this.groupBox1.Controls.Add(this.cbEthernet);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.ComboBox_baud2);
            this.groupBox1.Controls.Add(this.ComboBox_COM);
            this.groupBox1.Controls.Add(this.txtPortaLeitor);
            this.groupBox1.Controls.Add(this.txtIpLeitor);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(574, 119);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Comunicação com o Leitor RFID";
            // 
            // cbMid10Sv2
            // 
            this.cbMid10Sv2.AutoSize = true;
            this.cbMid10Sv2.Location = new System.Drawing.Point(483, 85);
            this.cbMid10Sv2.Name = "cbMid10Sv2";
            this.cbMid10Sv2.Size = new System.Drawing.Size(77, 17);
            this.cbMid10Sv2.TabIndex = 24;
            this.cbMid10Sv2.Text = "MID10Sv2";
            this.cbMid10Sv2.UseVisualStyleBackColor = true;
            // 
            // cbSerialUsb
            // 
            this.cbSerialUsb.AutoSize = true;
            this.cbSerialUsb.Location = new System.Drawing.Point(24, 82);
            this.cbSerialUsb.Name = "cbSerialUsb";
            this.cbSerialUsb.Size = new System.Drawing.Size(85, 17);
            this.cbSerialUsb.TabIndex = 23;
            this.cbSerialUsb.Text = "Serial / USB";
            this.cbSerialUsb.UseVisualStyleBackColor = true;
            this.cbSerialUsb.CheckedChanged += new System.EventHandler(this.CbSerialUsb_CheckedChanged);
            // 
            // cbEthernet
            // 
            this.cbEthernet.AutoSize = true;
            this.cbEthernet.Location = new System.Drawing.Point(24, 41);
            this.cbEthernet.Name = "cbEthernet";
            this.cbEthernet.Size = new System.Drawing.Size(66, 17);
            this.cbEthernet.TabIndex = 22;
            this.cbEthernet.Text = "Ethernet";
            this.cbEthernet.UseVisualStyleBackColor = true;
            this.cbEthernet.CheckedChanged += new System.EventHandler(this.CbEthernet_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(21, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(28, 13);
            this.label16.TabIndex = 21;
            this.label16.Text = "Tipo";
            // 
            // ComboBox_baud2
            // 
            this.ComboBox_baud2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_baud2.FormattingEnabled = true;
            this.ComboBox_baud2.Items.AddRange(new object[] {
            "9600bps",
            "19200bps",
            "38400bps",
            "57600bps",
            "115200bps"});
            this.ComboBox_baud2.Location = new System.Drawing.Point(355, 82);
            this.ComboBox_baud2.Name = "ComboBox_baud2";
            this.ComboBox_baud2.Size = new System.Drawing.Size(121, 21);
            this.ComboBox_baud2.TabIndex = 20;
            // 
            // ComboBox_COM
            // 
            this.ComboBox_COM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_COM.FormattingEnabled = true;
            this.ComboBox_COM.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "COM10",
            "COM11",
            "COM12",
            "COM13",
            "COM14",
            "COM15"});
            this.ComboBox_COM.Location = new System.Drawing.Point(355, 37);
            this.ComboBox_COM.Name = "ComboBox_COM";
            this.ComboBox_COM.Size = new System.Drawing.Size(121, 21);
            this.ComboBox_COM.TabIndex = 19;
            // 
            // txtPortaLeitor
            // 
            this.txtPortaLeitor.Location = new System.Drawing.Point(139, 83);
            this.txtPortaLeitor.Name = "txtPortaLeitor";
            this.txtPortaLeitor.Size = new System.Drawing.Size(205, 20);
            this.txtPortaLeitor.TabIndex = 3;
            // 
            // txtIpLeitor
            // 
            this.txtIpLeitor.Location = new System.Drawing.Point(139, 38);
            this.txtIpLeitor.Name = "txtIpLeitor";
            this.txtIpLeitor.Size = new System.Drawing.Size(205, 20);
            this.txtIpLeitor.TabIndex = 2;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(352, 67);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Baud rate";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(136, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Porta";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(352, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(32, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Porta";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(136, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "IP Leitor";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.nudReadTagInterval);
            this.groupBox2.Controls.Add(this.cbEnableInterval);
            this.groupBox2.Controls.Add(this.cbNoRepeat);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.cbGravarLog);
            this.groupBox2.Controls.Add(this.cbIgnorarZeros);
            this.groupBox2.Controls.Add(this.cbHabilitarEmulacao);
            this.groupBox2.Controls.Add(this.nudPosicaoFinal);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.nudPosicaoInicial);
            this.groupBox2.Controls.Add(this.cbConvertHexDec);
            this.groupBox2.Controls.Add(this.cbTraduzirEPC);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.cbEnviarEnter);
            this.groupBox2.Location = new System.Drawing.Point(6, 131);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(746, 137);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Configuração Emulação";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(672, 48);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 13);
            this.label12.TabIndex = 17;
            this.label12.Text = "milesegundos";
            // 
            // nudReadTagInterval
            // 
            this.nudReadTagInterval.Location = new System.Drawing.Point(599, 44);
            this.nudReadTagInterval.Maximum = new decimal(new int[] {
            60000,
            0,
            0,
            0});
            this.nudReadTagInterval.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudReadTagInterval.Name = "nudReadTagInterval";
            this.nudReadTagInterval.Size = new System.Drawing.Size(72, 20);
            this.nudReadTagInterval.TabIndex = 16;
            this.nudReadTagInterval.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // cbEnableInterval
            // 
            this.cbEnableInterval.AutoSize = true;
            this.cbEnableInterval.Location = new System.Drawing.Point(464, 46);
            this.cbEnableInterval.Name = "cbEnableInterval";
            this.cbEnableInterval.Size = new System.Drawing.Size(135, 17);
            this.cbEnableInterval.TabIndex = 15;
            this.cbEnableInterval.Text = "Habilitar Intervalo Tags";
            this.cbEnableInterval.UseVisualStyleBackColor = true;
            // 
            // cbNoRepeat
            // 
            this.cbNoRepeat.AutoSize = true;
            this.cbNoRepeat.Location = new System.Drawing.Point(464, 28);
            this.cbNoRepeat.Name = "cbNoRepeat";
            this.cbNoRepeat.Size = new System.Drawing.Size(110, 17);
            this.cbNoRepeat.TabIndex = 14;
            this.cbNoRepeat.Text = "Não Repetir Tags";
            this.cbNoRepeat.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(280, 105);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 20);
            this.button2.TabIndex = 13;
            this.button2.Text = "Abrir Local";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // cbGravarLog
            // 
            this.cbGravarLog.AutoSize = true;
            this.cbGravarLog.Location = new System.Drawing.Point(280, 82);
            this.cbGravarLog.Name = "cbGravarLog";
            this.cbGravarLog.Size = new System.Drawing.Size(79, 17);
            this.cbGravarLog.TabIndex = 12;
            this.cbGravarLog.Text = "Gravar Log";
            this.cbGravarLog.UseVisualStyleBackColor = true;
            // 
            // cbIgnorarZeros
            // 
            this.cbIgnorarZeros.AutoSize = true;
            this.cbIgnorarZeros.Location = new System.Drawing.Point(280, 46);
            this.cbIgnorarZeros.Name = "cbIgnorarZeros";
            this.cbIgnorarZeros.Size = new System.Drawing.Size(124, 17);
            this.cbIgnorarZeros.TabIndex = 11;
            this.cbIgnorarZeros.Text = "Ignorar 0 à esquerda";
            this.cbIgnorarZeros.UseVisualStyleBackColor = true;
            // 
            // cbHabilitarEmulacao
            // 
            this.cbHabilitarEmulacao.AutoSize = true;
            this.cbHabilitarEmulacao.Location = new System.Drawing.Point(25, 28);
            this.cbHabilitarEmulacao.Name = "cbHabilitarEmulacao";
            this.cbHabilitarEmulacao.Size = new System.Drawing.Size(114, 17);
            this.cbHabilitarEmulacao.TabIndex = 10;
            this.cbHabilitarEmulacao.Text = "Habilitar Emulação";
            this.cbHabilitarEmulacao.UseVisualStyleBackColor = true;
            // 
            // nudPosicaoFinal
            // 
            this.nudPosicaoFinal.Location = new System.Drawing.Point(116, 73);
            this.nudPosicaoFinal.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nudPosicaoFinal.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudPosicaoFinal.Name = "nudPosicaoFinal";
            this.nudPosicaoFinal.Size = new System.Drawing.Size(72, 20);
            this.nudPosicaoFinal.TabIndex = 9;
            this.nudPosicaoFinal.Value = new decimal(new int[] {
            24,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(113, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Posição Final";
            // 
            // nudPosicaoInicial
            // 
            this.nudPosicaoInicial.Location = new System.Drawing.Point(25, 73);
            this.nudPosicaoInicial.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nudPosicaoInicial.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudPosicaoInicial.Name = "nudPosicaoInicial";
            this.nudPosicaoInicial.Size = new System.Drawing.Size(72, 20);
            this.nudPosicaoInicial.TabIndex = 7;
            this.nudPosicaoInicial.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cbConvertHexDec
            // 
            this.cbConvertHexDec.AutoSize = true;
            this.cbConvertHexDec.Location = new System.Drawing.Point(280, 64);
            this.cbConvertHexDec.Name = "cbConvertHexDec";
            this.cbConvertHexDec.Size = new System.Drawing.Size(141, 17);
            this.cbConvertHexDec.TabIndex = 6;
            this.cbConvertHexDec.Text = "Converter Hex para Dec";
            this.cbConvertHexDec.UseVisualStyleBackColor = true;
            // 
            // cbTraduzirEPC
            // 
            this.cbTraduzirEPC.AutoSize = true;
            this.cbTraduzirEPC.Location = new System.Drawing.Point(280, 28);
            this.cbTraduzirEPC.Name = "cbTraduzirEPC";
            this.cbTraduzirEPC.Size = new System.Drawing.Size(88, 17);
            this.cbTraduzirEPC.TabIndex = 5;
            this.cbTraduzirEPC.Text = "Traduzir EPC";
            this.cbTraduzirEPC.UseVisualStyleBackColor = true;
            this.cbTraduzirEPC.CheckedChanged += new System.EventHandler(this.CbTraduzirEPC_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Posição Inicial";
            // 
            // cbEnviarEnter
            // 
            this.cbEnviarEnter.AutoSize = true;
            this.cbEnviarEnter.Location = new System.Drawing.Point(139, 28);
            this.cbEnviarEnter.Name = "cbEnviarEnter";
            this.cbEnviarEnter.Size = new System.Drawing.Size(139, 17);
            this.cbEnviarEnter.TabIndex = 0;
            this.cbEnviarEnter.Text = "Enviar [ENTER] no final";
            this.cbEnviarEnter.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbIniciarMinimizado);
            this.groupBox3.Controls.Add(this.cbConectarIniciar);
            this.groupBox3.Location = new System.Drawing.Point(588, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(164, 119);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Configurações do Agent";
            // 
            // cbIniciarMinimizado
            // 
            this.cbIniciarMinimizado.AutoSize = true;
            this.cbIniciarMinimizado.Location = new System.Drawing.Point(17, 61);
            this.cbIniciarMinimizado.Name = "cbIniciarMinimizado";
            this.cbIniciarMinimizado.Size = new System.Drawing.Size(109, 17);
            this.cbIniciarMinimizado.TabIndex = 2;
            this.cbIniciarMinimizado.Text = "Iniciar Minimizado";
            this.cbIniciarMinimizado.UseVisualStyleBackColor = true;
            // 
            // cbConectarIniciar
            // 
            this.cbConectarIniciar.AutoSize = true;
            this.cbConectarIniciar.Location = new System.Drawing.Point(17, 38);
            this.cbConectarIniciar.Name = "cbConectarIniciar";
            this.cbConectarIniciar.Size = new System.Drawing.Size(114, 17);
            this.cbConectarIniciar.TabIndex = 1;
            this.cbConectarIniciar.Text = "Conectar ao iniciar";
            this.cbConectarIniciar.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.txtResultado);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.txtLeitura);
            this.groupBox4.Location = new System.Drawing.Point(6, 274);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(746, 118);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Simulador de Resultado";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Resultado para Emulação";
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(24, 81);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(716, 20);
            this.txtResultado.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Leitura";
            // 
            // txtLeitura
            // 
            this.txtLeitura.Location = new System.Drawing.Point(24, 40);
            this.txtLeitura.Name = "txtLeitura";
            this.txtLeitura.Size = new System.Drawing.Size(716, 20);
            this.txtLeitura.TabIndex = 5;
            this.txtLeitura.TextChanged += new System.EventHandler(this.txtLeitura_TextChanged);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(12, 445);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(80, 26);
            this.btnSalvar.TabIndex = 4;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.Button1_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(98, 445);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(80, 26);
            this.btnCancelar.TabIndex = 5;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Location = new System.Drawing.Point(612, 445);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(80, 26);
            this.btnMinimizar.TabIndex = 6;
            this.btnMinimizar.Text = "Minimizar";
            this.btnMinimizar.UseVisualStyleBackColor = true;
            this.btnMinimizar.Click += new System.EventHandler(this.Button3_Click);
            // 
            // btnEncerrar
            // 
            this.btnEncerrar.Location = new System.Drawing.Point(698, 445);
            this.btnEncerrar.Name = "btnEncerrar";
            this.btnEncerrar.Size = new System.Drawing.Size(80, 26);
            this.btnEncerrar.TabIndex = 7;
            this.btnEncerrar.Text = "Encerrar";
            this.btnEncerrar.UseVisualStyleBackColor = true;
            this.btnEncerrar.Click += new System.EventHandler(this.BtnEncerrar_Click);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "Viaonda RFID - Emulador Teclado";
            this.notifyIcon1.Visible = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnConfig,
            this.mnEncerrar});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(152, 48);
            // 
            // mnConfig
            // 
            this.mnConfig.Name = "mnConfig";
            this.mnConfig.Size = new System.Drawing.Size(151, 22);
            this.mnConfig.Text = "Configurações";
            this.mnConfig.Click += new System.EventHandler(this.MnConfig_Click);
            // 
            // mnEncerrar
            // 
            this.mnEncerrar.Name = "mnEncerrar";
            this.mnEncerrar.Size = new System.Drawing.Size(151, 22);
            this.mnEncerrar.Text = "Encerrar";
            this.mnEncerrar.Click += new System.EventHandler(this.MnEncerrar_Click);
            // 
            // btnReconectar
            // 
            this.btnReconectar.Location = new System.Drawing.Point(184, 445);
            this.btnReconectar.Name = "btnReconectar";
            this.btnReconectar.Size = new System.Drawing.Size(80, 26);
            this.btnReconectar.TabIndex = 9;
            this.btnReconectar.Text = "Reconectar";
            this.btnReconectar.UseVisualStyleBackColor = true;
            this.btnReconectar.Click += new System.EventHandler(this.BtnReconectar_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tagConfigGerais);
            this.tabControl1.Controls.Add(this.tagConfigRFID);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(766, 427);
            this.tabControl1.TabIndex = 10;
            // 
            // tagConfigGerais
            // 
            this.tagConfigGerais.Controls.Add(this.groupBox1);
            this.tagConfigGerais.Controls.Add(this.groupBox2);
            this.tagConfigGerais.Controls.Add(this.groupBox3);
            this.tagConfigGerais.Controls.Add(this.groupBox4);
            this.tagConfigGerais.Location = new System.Drawing.Point(4, 22);
            this.tagConfigGerais.Name = "tagConfigGerais";
            this.tagConfigGerais.Padding = new System.Windows.Forms.Padding(3);
            this.tagConfigGerais.Size = new System.Drawing.Size(758, 401);
            this.tagConfigGerais.TabIndex = 0;
            this.tagConfigGerais.Text = "Configurações Gerais";
            this.tagConfigGerais.UseVisualStyleBackColor = true;
            // 
            // tagConfigRFID
            // 
            this.tagConfigRFID.Controls.Add(this.comboBox4);
            this.tagConfigRFID.Controls.Add(this.label40);
            this.tagConfigRFID.Controls.Add(this.txtMACAddr);
            this.tagConfigRFID.Controls.Add(this.label11);
            this.tagConfigRFID.Controls.Add(this.button1);
            this.tagConfigRFID.Controls.Add(this.label10);
            this.tagConfigRFID.Controls.Add(this.txtNewMask);
            this.tagConfigRFID.Controls.Add(this.label9);
            this.tagConfigRFID.Controls.Add(this.txtNewIP);
            this.tagConfigRFID.Controls.Add(this.label8);
            this.tagConfigRFID.Controls.Add(this.progressBar1);
            this.tagConfigRFID.Controls.Add(this.ComboBox_scantime);
            this.tagConfigRFID.Controls.Add(this.label17);
            this.tagConfigRFID.Controls.Add(this.Button5);
            this.tagConfigRFID.Controls.Add(this.ComboBox_dmaxfre);
            this.tagConfigRFID.Controls.Add(this.ComboBox_dminfre);
            this.tagConfigRFID.Controls.Add(this.ComboBox_PowerDbm);
            this.tagConfigRFID.Controls.Add(this.label15);
            this.tagConfigRFID.Controls.Add(this.label14);
            this.tagConfigRFID.Controls.Add(this.label13);
            this.tagConfigRFID.Controls.Add(this.groupBox30);
            this.tagConfigRFID.Controls.Add(this.Edit_Version);
            this.tagConfigRFID.Controls.Add(this.label7);
            this.tagConfigRFID.Location = new System.Drawing.Point(4, 22);
            this.tagConfigRFID.Name = "tagConfigRFID";
            this.tagConfigRFID.Padding = new System.Windows.Forms.Padding(3);
            this.tagConfigRFID.Size = new System.Drawing.Size(758, 401);
            this.tagConfigRFID.TabIndex = 1;
            this.tagConfigRFID.Text = "Configurações RFID";
            this.tagConfigRFID.UseVisualStyleBackColor = true;
            // 
            // comboBox4
            // 
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Answer Mode",
            "Active mode",
            "Trigger mode(Low)",
            "Trigger mode(High)"});
            this.comboBox4.Location = new System.Drawing.Point(18, 72);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(250, 21);
            this.comboBox4.TabIndex = 65;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(15, 56);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(99, 13);
            this.label40.TabIndex = 64;
            this.label40.Text = "Modo de Operação";
            // 
            // txtMACAddr
            // 
            this.txtMACAddr.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtMACAddr.Enabled = false;
            this.txtMACAddr.Location = new System.Drawing.Point(307, 250);
            this.txtMACAddr.Name = "txtMACAddr";
            this.txtMACAddr.Size = new System.Drawing.Size(116, 20);
            this.txtMACAddr.TabIndex = 63;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(307, 234);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 13);
            this.label11.TabIndex = 62;
            this.label11.Text = "MAC Address";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 276);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 25);
            this.button1.TabIndex = 61;
            this.button1.Text = "Aplicar Configurações de Rede";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(15, 202);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 13);
            this.label10.TabIndex = 60;
            this.label10.Text = "Configurações de Rede";
            // 
            // txtNewMask
            // 
            this.txtNewMask.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtNewMask.Enabled = false;
            this.txtNewMask.Location = new System.Drawing.Point(185, 250);
            this.txtNewMask.Name = "txtNewMask";
            this.txtNewMask.Size = new System.Drawing.Size(116, 20);
            this.txtNewMask.TabIndex = 59;
            this.txtNewMask.Text = "255.255.255.0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(185, 234);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 58;
            this.label9.Text = "Máscara";
            // 
            // txtNewIP
            // 
            this.txtNewIP.BackColor = System.Drawing.SystemColors.Window;
            this.txtNewIP.Location = new System.Drawing.Point(15, 250);
            this.txtNewIP.Name = "txtNewIP";
            this.txtNewIP.Size = new System.Drawing.Size(164, 20);
            this.txtNewIP.TabIndex = 57;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 234);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 13);
            this.label8.TabIndex = 56;
            this.label8.Text = "Endereço IP";
            // 
            // progressBar1
            // 
            this.progressBar1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.progressBar1.Location = new System.Drawing.Point(18, 336);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(499, 21);
            this.progressBar1.TabIndex = 55;
            this.progressBar1.Visible = false;
            // 
            // ComboBox_scantime
            // 
            this.ComboBox_scantime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_scantime.FormattingEnabled = true;
            this.ComboBox_scantime.Location = new System.Drawing.Point(380, 32);
            this.ComboBox_scantime.Name = "ComboBox_scantime";
            this.ComboBox_scantime.Size = new System.Drawing.Size(121, 21);
            this.ComboBox_scantime.TabIndex = 54;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(377, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 13);
            this.label17.TabIndex = 53;
            this.label17.Text = "Intervalo de Leitura";
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(18, 156);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(197, 25);
            this.Button5.TabIndex = 52;
            this.Button5.Text = "Aplicar Configurações de RF";
            this.Button5.UseVisualStyleBackColor = true;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // ComboBox_dmaxfre
            // 
            this.ComboBox_dmaxfre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_dmaxfre.FormattingEnabled = true;
            this.ComboBox_dmaxfre.Location = new System.Drawing.Point(274, 32);
            this.ComboBox_dmaxfre.Name = "ComboBox_dmaxfre";
            this.ComboBox_dmaxfre.Size = new System.Drawing.Size(100, 21);
            this.ComboBox_dmaxfre.TabIndex = 51;
            // 
            // ComboBox_dminfre
            // 
            this.ComboBox_dminfre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_dminfre.FormattingEnabled = true;
            this.ComboBox_dminfre.Location = new System.Drawing.Point(168, 32);
            this.ComboBox_dminfre.Name = "ComboBox_dminfre";
            this.ComboBox_dminfre.Size = new System.Drawing.Size(100, 21);
            this.ComboBox_dminfre.TabIndex = 50;
            // 
            // ComboBox_PowerDbm
            // 
            this.ComboBox_PowerDbm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_PowerDbm.FormattingEnabled = true;
            this.ComboBox_PowerDbm.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this.ComboBox_PowerDbm.Location = new System.Drawing.Point(97, 32);
            this.ComboBox_PowerDbm.Name = "ComboBox_PowerDbm";
            this.ComboBox_PowerDbm.Size = new System.Drawing.Size(65, 21);
            this.ComboBox_PowerDbm.TabIndex = 49;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(271, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 13);
            this.label15.TabIndex = 48;
            this.label15.Text = "Frequência Máx.";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(165, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 13);
            this.label14.TabIndex = 47;
            this.label14.Text = "Frequência Min.";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(94, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 13);
            this.label13.TabIndex = 46;
            this.label13.Text = "Potência";
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.radioButton_band5);
            this.groupBox30.Controls.Add(this.radioButton_band4);
            this.groupBox30.Controls.Add(this.radioButton_band3);
            this.groupBox30.Controls.Add(this.radioButton_band2);
            this.groupBox30.Controls.Add(this.radioButton_band1);
            this.groupBox30.Location = new System.Drawing.Point(18, 98);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(483, 53);
            this.groupBox30.TabIndex = 45;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "Faixa de Operação";
            // 
            // radioButton_band5
            // 
            this.radioButton_band5.AutoSize = true;
            this.radioButton_band5.Location = new System.Drawing.Point(409, 21);
            this.radioButton_band5.Name = "radioButton_band5";
            this.radioButton_band5.Size = new System.Drawing.Size(67, 17);
            this.radioButton_band5.TabIndex = 5;
            this.radioButton_band5.TabStop = true;
            this.radioButton_band5.Text = "EU band";
            this.radioButton_band5.UseVisualStyleBackColor = true;
            this.radioButton_band5.CheckedChanged += new System.EventHandler(this.RadioButton_band5_CheckedChanged);
            // 
            // radioButton_band4
            // 
            this.radioButton_band4.AutoSize = true;
            this.radioButton_band4.Location = new System.Drawing.Point(308, 21);
            this.radioButton_band4.Name = "radioButton_band4";
            this.radioButton_band4.Size = new System.Drawing.Size(86, 17);
            this.radioButton_band4.TabIndex = 3;
            this.radioButton_band4.TabStop = true;
            this.radioButton_band4.Text = "Korean band";
            this.radioButton_band4.UseVisualStyleBackColor = true;
            this.radioButton_band4.CheckedChanged += new System.EventHandler(this.RadioButton_band4_CheckedChanged);
            // 
            // radioButton_band3
            // 
            this.radioButton_band3.AutoSize = true;
            this.radioButton_band3.Location = new System.Drawing.Point(206, 21);
            this.radioButton_band3.Name = "radioButton_band3";
            this.radioButton_band3.Size = new System.Drawing.Size(87, 17);
            this.radioButton_band3.TabIndex = 2;
            this.radioButton_band3.TabStop = true;
            this.radioButton_band3.Text = "BR/US band";
            this.radioButton_band3.UseVisualStyleBackColor = true;
            this.radioButton_band3.CheckedChanged += new System.EventHandler(this.RadioButton_band3_CheckedChanged);
            // 
            // radioButton_band2
            // 
            this.radioButton_band2.AutoSize = true;
            this.radioButton_band2.Location = new System.Drawing.Point(95, 21);
            this.radioButton_band2.Name = "radioButton_band2";
            this.radioButton_band2.Size = new System.Drawing.Size(96, 17);
            this.radioButton_band2.TabIndex = 1;
            this.radioButton_band2.TabStop = true;
            this.radioButton_band2.Text = "Chinese band2";
            this.radioButton_band2.UseVisualStyleBackColor = true;
            this.radioButton_band2.CheckedChanged += new System.EventHandler(this.RadioButton_band2_CheckedChanged);
            // 
            // radioButton_band1
            // 
            this.radioButton_band1.AutoSize = true;
            this.radioButton_band1.Location = new System.Drawing.Point(6, 21);
            this.radioButton_band1.Name = "radioButton_band1";
            this.radioButton_band1.Size = new System.Drawing.Size(74, 17);
            this.radioButton_band1.TabIndex = 0;
            this.radioButton_band1.TabStop = true;
            this.radioButton_band1.Text = "User band";
            this.radioButton_band1.UseVisualStyleBackColor = true;
            this.radioButton_band1.CheckedChanged += new System.EventHandler(this.RadioButton_band1_CheckedChanged);
            // 
            // Edit_Version
            // 
            this.Edit_Version.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_Version.Enabled = false;
            this.Edit_Version.Location = new System.Drawing.Point(18, 33);
            this.Edit_Version.Name = "Edit_Version";
            this.Edit_Version.Size = new System.Drawing.Size(73, 20);
            this.Edit_Version.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Versão";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 511);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(794, 22);
            this.statusStrip1.TabIndex = 11;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.StatusStrip1_ItemClicked);
            // 
            // statusLabel
            // 
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // Timer_Test_
            // 
            this.Timer_Test_.Interval = 20;
            this.Timer_Test_.Tick += new System.EventHandler(this.Timer_Test__Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 533);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnReconectar);
            this.Controls.Add(this.btnEncerrar);
            this.Controls.Add(this.btnMinimizar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnSalvar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Viaonda RFID - Emulador Teclado";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudReadTagInterval)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPosicaoFinal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPosicaoInicial)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tagConfigGerais.ResumeLayout(false);
            this.tagConfigRFID.ResumeLayout(false);
            this.tagConfigRFID.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtPortaLeitor;
        private System.Windows.Forms.TextBox txtIpLeitor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnMinimizar;
        private System.Windows.Forms.Button btnEncerrar;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnConfig;
        private System.Windows.Forms.ToolStripMenuItem mnEncerrar;
        private System.Windows.Forms.CheckBox cbEnviarEnter;
        private System.Windows.Forms.CheckBox cbIniciarMinimizado;
        private System.Windows.Forms.CheckBox cbConectarIniciar;
        private System.Windows.Forms.CheckBox cbConvertHexDec;
        private System.Windows.Forms.CheckBox cbTraduzirEPC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnReconectar;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tagConfigGerais;
        private System.Windows.Forms.TabPage tagConfigRFID;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtLeitura;
        private System.Windows.Forms.Timer Timer_Test_;
        private System.Windows.Forms.CheckBox cbHabilitarEmulacao;
        private System.Windows.Forms.NumericUpDown nudPosicaoFinal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nudPosicaoInicial;
        private System.Windows.Forms.CheckBox cbIgnorarZeros;
        private System.Windows.Forms.Button Button5;
        private System.Windows.Forms.ComboBox ComboBox_dmaxfre;
        private System.Windows.Forms.ComboBox ComboBox_dminfre;
        private System.Windows.Forms.ComboBox ComboBox_PowerDbm;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.RadioButton radioButton_band5;
        private System.Windows.Forms.RadioButton radioButton_band4;
        private System.Windows.Forms.RadioButton radioButton_band3;
        private System.Windows.Forms.RadioButton radioButton_band2;
        private System.Windows.Forms.RadioButton radioButton_band1;
        private System.Windows.Forms.TextBox Edit_Version;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox ComboBox_scantime;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtNewMask;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNewIP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMACAddr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox cbGravarLog;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.CheckBox cbEnableInterval;
        private System.Windows.Forms.CheckBox cbNoRepeat;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown nudReadTagInterval;
        private System.Windows.Forms.ComboBox ComboBox_baud2;
        internal System.Windows.Forms.ComboBox ComboBox_COM;
        private System.Windows.Forms.CheckBox cbSerialUsb;
        private System.Windows.Forms.CheckBox cbEthernet;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox cbMid10Sv2;
    }
}

