﻿using ReaderB;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using UHF;
using RFID;
using System.Runtime.InteropServices;
using WindowsInput;

namespace ViaondaAgentEmuladorTeclado
{

    public partial class Form1 : Form
    {

        ViaondaClass Viaonda = new ViaondaClass();

        SerialPort port;

        private bool fAppClosed; 
        private byte fComAdr = 0xff;
        private int ferrorcode;
        private byte fBaud;
        private double fdminfre;
        private double fdmaxfre;
        private byte Maskadr;
        private byte MaskLen;
        private byte MaskFlag;
        private int fCmdRet = 30;
        private int fOpenComIndex;
        private bool fIsInventoryScan;
        private bool fisinventoryscan_6B;
        private byte[] fOperEPC = new byte[36];
        private byte[] fPassWord = new byte[4];
        private byte[] fOperID_6B = new byte[8];
        private int CardNum1 = 0;
        ArrayList list = new ArrayList();
        private bool fTimer_6B_ReadWrite;
        private string fInventory_EPC_List;
        private int frmcomportindex;
        private bool ComOpen = false;
        private bool breakflag = false;
        private double x_z;
        private double y_f;
        
        
        public string fRecvUDPstring = "";
        CFComApi.CallbackDelegate myDelegate;
        public string RemostIP = "";

        InputSimulator inputSimulator = new InputSimulator();

        private static System.Timers.Timer aTimer;

        public Form1()
        {
            InitializeComponent();
            myDelegate = new CFComApi.CallbackDelegate(ProcessDelegate);
            RFID.CFComApi.CFCom_SetCallback(myDelegate);
            
        }

        private void OnTimedEvent(Object source, System.Timers.ElapsedEventArgs e)
        {
            vLimparLeitura("");
            vAtualizarTxtResultado("");
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            SalvarConfiguracoes();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                Hide();
                notifyIcon1.Visible = true;
            }
        }

        private void MnConfig_Click(object sender, EventArgs e)
        {
            Show();
            this.WindowState = FormWindowState.Normal;
            notifyIcon1.Visible = false;
        }

        private void MnEncerrar_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Hide();
            notifyIcon1.Visible = true;
        }

        private void CarregarConfiguracoes()
        {
            txtIpLeitor.Text = Properties.Settings.Default.IPLeitor.ToString();
            txtPortaLeitor.Text = Properties.Settings.Default.PortaLeitor.ToString();
            cbConectarIniciar.Checked = Properties.Settings.Default.ConectarAoIniciar;
            cbIniciarMinimizado.Checked = Properties.Settings.Default.IniciarMinimizado;
            cbHabilitarEmulacao.Checked = Properties.Settings.Default.HabilitarEmulacao;
            cbTraduzirEPC.Checked = Properties.Settings.Default.TraduzirEPC;
            cbEnviarEnter.Checked = Properties.Settings.Default.EnviarEnter;
            cbConvertHexDec.Checked = Properties.Settings.Default.ConvertHex2Dec;
            cbIgnorarZeros.Checked = Properties.Settings.Default.Ignorar0;
            nudPosicaoInicial.Value = Properties.Settings.Default.PosicaoInicial;
            nudPosicaoFinal.Value = Properties.Settings.Default.PosicaoFinal;
            cbGravarLog.Checked = Properties.Settings.Default.GravarLog;
            cbNoRepeat.Checked = Properties.Settings.Default.NoRepeat;
            cbMid10Sv2.Checked = Properties.Settings.Default.Mid10sV2;

            cbSerialUsb.Checked = false;
            cbEthernet.Checked = false;
            if (Properties.Settings.Default.Serial_Ethernet == "SERIAL") cbSerialUsb.Checked = true;
            if (Properties.Settings.Default.Serial_Ethernet == "ETHERNET") cbEthernet.Checked = true;

            ComboBox_baud2.SelectedItem = Properties.Settings.Default.SerialBaudRate.ToString();
            ComboBox_COM.SelectedItem = Properties.Settings.Default.SerialPort.ToString();

            cbEnableInterval.Checked = Properties.Settings.Default.EnableInterval;
            try
            {
                nudReadTagInterval.Value = Properties.Settings.Default.DelayTags;
            }
            catch
            {
                nudReadTagInterval.Value = nudReadTagInterval.Minimum;
            }
            if (cbEnableInterval.Checked)
                Timer_Test_.Interval = Decimal.ToInt32(nudReadTagInterval.Value);
            else
                Timer_Test_.Interval = 5;

            txtNewIP.Text = txtIpLeitor.Text;


            InitReaderList();
        }

        private void SalvarConfiguracoes()
        {
            Properties.Settings.Default.IPLeitor = txtIpLeitor.Text;
            Properties.Settings.Default.PortaLeitor = txtPortaLeitor.Text;
            Properties.Settings.Default.ConectarAoIniciar = cbConectarIniciar.Checked;
            Properties.Settings.Default.IniciarMinimizado = cbIniciarMinimizado.Checked;
            Properties.Settings.Default.HabilitarEmulacao = cbHabilitarEmulacao.Checked;
            Properties.Settings.Default.TraduzirEPC = cbTraduzirEPC.Checked;
            Properties.Settings.Default.EnviarEnter = cbEnviarEnter.Checked;
            Properties.Settings.Default.ConvertHex2Dec = cbConvertHexDec.Checked;
            Properties.Settings.Default.Ignorar0 = cbIgnorarZeros.Checked;
            Properties.Settings.Default.PosicaoInicial = Decimal.ToInt32(nudPosicaoInicial.Value);
            Properties.Settings.Default.PosicaoFinal = Decimal.ToInt32(nudPosicaoFinal.Value);
            Properties.Settings.Default.GravarLog = cbGravarLog.Checked;
            Properties.Settings.Default.EnableInterval = cbEnableInterval.Checked;
            Properties.Settings.Default.NoRepeat = cbNoRepeat.Checked;
            Properties.Settings.Default.DelayTags = Decimal.ToInt32(nudReadTagInterval.Value);
            if (cbSerialUsb.Checked) Properties.Settings.Default.Serial_Ethernet = "SERIAL";
            if (cbEthernet.Checked) Properties.Settings.Default.Serial_Ethernet = "ETHERNET";
            Properties.Settings.Default.SerialBaudRate = ComboBox_baud2.SelectedItem.ToString();
            Properties.Settings.Default.SerialPort = ComboBox_COM.SelectedItem.ToString();
            Properties.Settings.Default.Mid10sV2 = cbMid10Sv2.Checked;

            Properties.Settings.Default.Save();
            if (cbEnableInterval.Checked)
                Timer_Test_.Interval = Decimal.ToInt32(nudReadTagInterval.Value);
            else
                Timer_Test_.Interval = 5;
        }

        private void InitReaderList()
        {
            int i = 0;
            // ComboBox_PowerDbm.SelectedIndex = 0;
            
            for (i = 0; i < 63; i++)
            {
                ComboBox_dminfre.Items.Add(Convert.ToString(902.6 + i * 0.4) + " MHz");
                ComboBox_dmaxfre.Items.Add(Convert.ToString(902.6 + i * 0.4) + " MHz");
            }
            ComboBox_dmaxfre.SelectedIndex = 62;
            ComboBox_dminfre.SelectedIndex = 0;
            for (i = 0x03; i <= 0xff; i++)
                ComboBox_scantime.Items.Add(Convert.ToString(i) + "*100ms");
            ComboBox_scantime.SelectedIndex = 7;

            ComboBox_scantime.SelectedIndex = Properties.Settings.Default.ScanTime;
            //Timer_Test_.Interval = (ComboBox_scantime.SelectedIndex + 3) * 100;
            
            ComboBox_PowerDbm.SelectedIndex = 30;
            
        }

        private void ColetarModoOperacao()
        {
            byte[] Parameter = new byte[12];

            fCmdRet = StaticClassReaderB.GetWorkModeParameter(ref fComAdr, Parameter, frmcomportindex);
            if (fCmdRet == 0)
            {                                
                comboBox4.SelectedIndex = Convert.ToInt32(Parameter[4]);                
            }            
        }


        private void  ColetarInfoLeitorSerial()
        {
            byte TrType = 0;
            byte[] VersionInfo = new byte[2];
            byte ReaderType = 0;
            byte ScanTime = 0;
            byte dmaxfre = 0;
            byte dminfre = 0;
            byte powerdBm = 0;
            byte FreBand = 0;
            byte Ant = 0;
            byte BeepEn = 0;
            byte OutputRep = 0;
            byte CheckAnt = 0;
            //text_RDVersion.Text = "";
            int ctime = System.Environment.TickCount;
            fCmdRet = RWDev.GetReaderInformation(ref fComAdr, VersionInfo, ref ReaderType, ref TrType, ref dmaxfre, ref dminfre, ref powerdBm, ref ScanTime, ref Ant, ref BeepEn, ref OutputRep, ref CheckAnt, frmcomportindex);
            if (fCmdRet != 0)
            {
                string strLog = "Get Reader Information failed: " + GetReturnCodeDesc(fCmdRet);
                WriteLog( strLog);
            }
            else
            {
                //CommunicationTime = System.Environment.TickCount - ctime;
                Edit_Version.Text = Convert.ToString(VersionInfo[0], 10).PadLeft(2, '0') + "." + Convert.ToString(VersionInfo[1], 10).PadLeft(2, '0');

                ComboBox_PowerDbm.SelectedIndex = Convert.ToInt32(powerdBm);
                //text_address.Text = Convert.ToString(fComAdr, 16).PadLeft(2, '0');
                switch (FreBand)
                {
                    case 0:
                        {
                            radioButton_band1.Checked = true;
                            fdminfre = 902.6 + (dminfre & 0x3F) * 0.4;
                            fdmaxfre = 902.6 + (dmaxfre & 0x3F) * 0.4;
                        }
                        break;
                    case 1:
                        {
                            radioButton_band2.Checked = true;
                            fdminfre = 920.125 + (dminfre & 0x3F) * 0.25;
                            fdmaxfre = 920.125 + (dmaxfre & 0x3F) * 0.25;
                        }
                        break;
                    case 2:
                        {
                            radioButton_band3.Checked = true;
                            fdminfre = 902.75 + (dminfre & 0x3F) * 0.5;
                            fdmaxfre = 902.75 + (dmaxfre & 0x3F) * 0.5;
                        }
                        break;
                    case 3:
                        {
                            radioButton_band4.Checked = true;
                            fdminfre = 917.1 + (dminfre & 0x3F) * 0.2;
                            fdmaxfre = 917.1 + (dmaxfre & 0x3F) * 0.2;
                        }
                        break;
                    case 4:
                        {
                            radioButton_band5.Checked = true;
                            fdminfre = 865.1 + (dminfre & 0x3F) * 0.2;
                            fdmaxfre = 865.1 + (dmaxfre & 0x3F) * 0.2;
                        }
                        break;
                }

                ComboBox_dminfre.SelectedIndex = dminfre & 0x3F;
                ComboBox_dmaxfre.SelectedIndex = dmaxfre & 0x3F;

                string strLog = "Get Reader Information success ";
                WriteLog(strLog);
            }
        }

        private void ColetarInfoLeitor()
        {
            byte[] TrType = new byte[2];
            byte[] VersionInfo = new byte[2];
            byte ReaderType = 0;
            byte ScanTime = 0;
            byte dmaxfre = 0;
            byte dminfre = 0;
            byte powerdBm = 0;
            byte FreBand = 0;
            Edit_Version.Text = "";
            
            ComboBox_PowerDbm.Items.Clear();
            fCmdRet = StaticClassReaderB.GetReaderInformation(ref fComAdr, VersionInfo, ref ReaderType, TrType, ref dmaxfre, ref dminfre, ref powerdBm, ref ScanTime, frmcomportindex);
            if (fCmdRet == 0)
            {
                Edit_Version.Text = Convert.ToString(VersionInfo[0], 10).PadLeft(2, '0') + "." + Convert.ToString(VersionInfo[1], 10).PadLeft(2, '0');
                if (VersionInfo[1] >= 30)
                {
                    for (int i = 0; i < 31; i++)
                        ComboBox_PowerDbm.Items.Add(Convert.ToString(i));
                    if (powerdBm > 30)
                        ComboBox_PowerDbm.SelectedIndex = 30;
                    else
                        ComboBox_PowerDbm.SelectedIndex = powerdBm;
                }
                else
                {
                    for (int i = 0; i < 19; i++)
                        ComboBox_PowerDbm.Items.Add(Convert.ToString(i));
                    if (powerdBm > 18)
                        ComboBox_PowerDbm.SelectedIndex = 18;
                    else
                        ComboBox_PowerDbm.SelectedIndex = powerdBm;
                }

                ComboBox_scantime.SelectedIndex = ScanTime - 3;

                FreBand = Convert.ToByte(((dmaxfre & 0xc0) >> 4) | (dminfre >> 6));
                switch (FreBand)
                {
                    case 0:
                        {
                            radioButton_band1.Checked = true;
                            fdminfre = 902.6 + (dminfre & 0x3F) * 0.4;
                            fdmaxfre = 902.6 + (dmaxfre & 0x3F) * 0.4;
                        }
                        break;
                    case 1:
                        {
                            radioButton_band2.Checked = true;
                            fdminfre = 920.125 + (dminfre & 0x3F) * 0.25;
                            fdmaxfre = 920.125 + (dmaxfre & 0x3F) * 0.25;
                        }
                        break;
                    case 2:
                        {
                            radioButton_band3.Checked = true;
                            fdminfre = 902.75 + (dminfre & 0x3F) * 0.5;
                            fdmaxfre = 902.75 + (dmaxfre & 0x3F) * 0.5;
                        }
                        break;
                    case 3:
                        {
                            radioButton_band4.Checked = true;
                            fdminfre = 917.1 + (dminfre & 0x3F) * 0.2;
                            fdmaxfre = 917.1 + (dmaxfre & 0x3F) * 0.2;
                        }
                        break;
                    case 4:
                        {
                            radioButton_band5.Checked = true;
                            fdminfre = 865.1 + (dminfre & 0x3F) * 0.2;
                            fdmaxfre = 865.1 + (dmaxfre & 0x3F) * 0.2;
                        }
                        break;
                }

                ComboBox_dminfre.SelectedIndex = dminfre & 0x3F;
                ComboBox_dmaxfre.SelectedIndex = dmaxfre & 0x3F;

                string str = "";
                Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                IPEndPoint iep = new IPEndPoint(IPAddress.Parse(txtIpLeitor.Text), 65535);
                EndPoint ep = (EndPoint)iep;
                sock.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);
                string request = "X";
                byte[] buffer = Encoding.ASCII.GetBytes(request);
                sock.SendTo(buffer, iep);
                if (sock.Poll(58 * 1000 * 1000, SelectMode.SelectRead)) // Waiting an answer for 5s, if nothing: timeout
                {
                    for (int i = 0; i < 3; i++)
                    {
                        byte[] buffer1 = new byte[1000];
                        sock.ReceiveTimeout = 10;
                        iep = new IPEndPoint(IPAddress.Parse(txtIpLeitor.Text), 65535);
                        int m_count = sock.ReceiveFrom(buffer1, ref ep);
                        if (m_count > 0)
                        {

                            byte[] buffer2 = new byte[m_count];
                            Array.Copy(buffer1, buffer2, m_count);
                            string fRecvIDPstring = Encoding.ASCII.GetString(buffer2);
                            if (fRecvIDPstring.Substring(0, 1) == "A")
                            {
                                int m = fRecvIDPstring.IndexOf('/');
                                Information.mac = fRecvIDPstring.Substring(1, m - 1);
                                txtMACAddr.Text = Information.mac;
                                Information.portnum = fRecvIDPstring.Substring(m + 1, 4);
                                m = fRecvIDPstring.IndexOf('*');
                                int n = fRecvIDPstring.Length - m - 8;
                                string IDPstring = fRecvIDPstring.Substring(m + 8, n);
                                Information.usename = IDPstring.Substring(0, IDPstring.IndexOf('/'));
                                Information.dsname = IDPstring.Substring(IDPstring.IndexOf('/') + 1, IDPstring.Length - IDPstring.IndexOf('/') - 1);
                                Information.IP = ep.ToString().Substring(0, ep.ToString().IndexOf(':'));
                                if (((Information.usename == "") && (Information.dsname == "")) || (Information.dsname == "/"))
                                {
                                    str = "";
                                }
                                else
                                {
                                    str = Information.usename + '/' + Information.dsname;
                                }                                
                            }
                        }
                            break;
                    }
                }

                ColetarModoOperacao();
            }
        }

        public class Information
        {
            public static string IP = "";
            public static string usename = "";
            public static string dsname = "";
            public static string mac = "";
            public static string portnum = "";
            public static string tup = "";
            public static string rm = "";
            public static string cm = "";
            public static string ct = "";
            public static string fc = "";
            public static string dt = "";
            public static string br = "";
            public static string pr = "";
            public static string bb = "";
            public static string rc = "";
            public static string ml = "";
            public static string md = "";
            public static string di = "";
            public static string dp = "";
            public static string gi = "";
            public static string nm = "";
        }

        private void ReconectarEthernet()
        {
            int port, openresult = 0;
            string IPAddr;

            port = Convert.ToInt32(txtPortaLeitor.Text);
            IPAddr = txtIpLeitor.Text;
            fComAdr = Convert.ToByte("FF", 16);
            openresult = StaticClassReaderB.OpenNetPort(port, IPAddr, ref fComAdr, ref frmcomportindex);
            Thread.Sleep(100);

            if (openresult != 0)
                for (int i = 0; i < 5; i++)
                {
                    openresult = StaticClassReaderB.OpenNetPort(port, IPAddr, ref fComAdr, ref frmcomportindex);
                    if (openresult == 0)
                        break;
                    Thread.Sleep(100);
                }
            fOpenComIndex = frmcomportindex;
            if (openresult == 0)
            {
                ComOpen = true;
                ColetarInfoLeitor();
                Thread.Sleep(2000);
                txtNewIP.Enabled = true;
                button1.Enabled = true;
                comboBox4.Enabled = true;
                //Timer_Test_.Enabled = true;
                btnReconectar.Text = "Parar";
            }
            if ((openresult == 0x35) || (openresult == 0x30))
            {
                statusLabel.Text = "Erro ao se conectar ao leitor";
                StaticClassReaderB.CloseNetPort(frmcomportindex);
                ComOpen = false;
                return;
            }
            if ((fOpenComIndex != -1) && (openresult != 0X35) && (openresult != 0X30))
            {                
                ComOpen = true;
            }
            if ((fOpenComIndex == -1) && (openresult == 0x30))
            {
                statusLabel.Text = "Erro ao se conectar ao leitor";
                notifyIcon1.Icon = Properties.Resources.espiral_cinza;

            }
            else
            {
                statusLabel.Text = "Conectado com sucesso";
                notifyIcon1.Icon = Properties.Resources.espiral;
                txtNewIP.Text = txtIpLeitor.Text;
            }

            //RefreshStatus();
        }

        public void WriteLog(string sText)
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(WriteLog), new object[] { sText });
                return;
            }
            statusLabel.Text = sText;
        }

        private void ReconectarSerialUsb()
        {
            if (!cbMid10Sv2.Checked)
            {
                int portNum = ComboBox_COM.SelectedIndex + 1;
                int FrmPortIndex = 0;
                string strException = string.Empty;
                fBaud = Convert.ToByte(ComboBox_baud2.SelectedIndex);
                if (fBaud > 2)
                    fBaud = Convert.ToByte(fBaud + 2);
                fComAdr = 255;//Dispositivo aberto de endereço de transmissão
                fCmdRet = RWDev.OpenComPort(portNum, ref fComAdr, fBaud, ref FrmPortIndex);
                if (fCmdRet != 0)
                {
                    string strLog = "Connect failed: " + GetReturnCodeDesc(fCmdRet);
                    WriteLog(strLog);
                    return;
                }
                else
                {
                    frmcomportindex = FrmPortIndex;
                    string strLog = "Connected " + ComboBox_COM.Text + "@" + ComboBox_baud2.Text;
                    WriteLog(strLog);
                    txtNewIP.Enabled = false;
                    button1.Enabled = false;
                    comboBox4.Enabled = false;
                    ColetarInfoLeitorSerial();
                    Thread.Sleep(2000);
                    //Timer_Test_.Enabled = true;
                    btnReconectar.Text = "Parar";
                }
            }
            else
            {
                byte[] arrBuffer = new byte[64];

                String strPort = ComboBox_COM.Text;
                if (RFID.CFComApi.CFCom_OpenDevice(strPort, 115200))
                {
                    string strLog = "Connected " + ComboBox_COM.Text + "@" + ComboBox_baud2.Text;
                    WriteLog(strLog);
                    if (RFID.CFComApi.CFCom_GetDeviceSystemInfo(0xFF, arrBuffer) == false)
                    {
                        strLog = "Connected " + ComboBox_COM.Text + "@" + ComboBox_baud2.Text + " - Leitor não detectado";
                        WriteLog(strLog);
                        return;
                        //RFID.CFComApi.CFCom_CloseDevice();
                        //return;
                    }
                    
                }
                else
                {
                    string strLog = "Connect failed";
                    WriteLog(strLog);
                    return;
                }
            }


        }

        public void ProcessDelegate(int msg, int param1, IntPtr param2, int param3, IntPtr param4)
        {
            string strLog;

            if (msg == 0)
            {
                strLog = "Device Insert";
                WriteLog(strLog);
            }
            else if (msg == 1)
            {
                strLog = "No Device";
                WriteLog(strLog);
            }
            else if (msg == 2)
            {
                int iTagLength = 0;
                int iTagNumber = 0;
                iTagLength = param3;
                iTagNumber = param1;
                if (iTagNumber == 0) return;
                int iIndex = 0;
                int iLength = 0;
                byte bPackLength = 0;
                int i = 0;
                byte[] byData = new byte[(int)iTagLength];
                Marshal.Copy((IntPtr)param2, byData, 0, (int)iTagLength);
                for (iIndex = 0; iIndex < 1; iIndex++)
                {
                    bPackLength = byData[iLength];
                    string str2 = "";
                    string str1 = "";
                    string str4 = "";
                    str1 = byData[1 + iLength + 0].ToString("X2");
                    str2 = str2 + "Type:" + str1 + " ";  //Tag Type

                    str1 = byData[1 + iLength + 1].ToString("X2");
                    str2 = str2 + "Ant:" + str1 + " Tag:";  //Ant

                    string str3 = "";
                    for (i = 2; i < bPackLength - 1; i++)
                    {
                        str1 = byData[1 + iLength + i].ToString("X2");                        
                        str4 = str4 + str1;
                        str3 = str3 + str1 + " ";
                    }
                    string sEPC = str4;
                    str2 = str2 + str3;
                    str1 = byData[1 + iLength + i].ToString("X2");
                    str2 = str2 + "RSSI:" + str1 + "\r\n";  //RSSI
                    iLength = iLength + bPackLength + 1;
                    strLog = str2;

                    if (cbNoRepeat.Checked)
                    {
                        if (txtLeitura.Text != sEPC)
                        {
                            DoUpDate(sEPC.Trim());
                            //EmularTeclado(sEPC.Trim());
                        }
                    }
                    else
                    {
                        DoUpDate(sEPC.Trim());
                        //EmularTeclado(sEPC.Trim());
                    }
                    
                    WriteLog(strLog);
                }
            }
        }
        
        

        private void DoUpDate(string sEpc)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(DoUpDate), new object[] { sEpc });
                EmularTeclado(sEpc.Trim());
                return;
            }
            txtLeitura.Text = sEpc;
            
        }

        private void port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            
            int intBuffer;
            intBuffer = port.BytesToRead;        
            
            byte[] byteBuffer = new byte[32];
            port.Read(byteBuffer, 0, 32);
            
            
            string stemp = ByteArrayToHexString(byteBuffer);            
            
            DoUpDate(stemp);
            

        }

        private void Reconectar()
        {
            if (cbEthernet.Checked)
                ReconectarEthernet();

            if (cbSerialUsb.Checked)
                ReconectarSerialUsb();

            aTimer.Interval = Decimal.ToInt32(nudReadTagInterval.Value);
            
            // Have the timer fire repeated events (true is the default)
            aTimer.AutoReset = true;

            // Start the timer
            aTimer.Enabled = true;



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CarregarConfiguracoes();

            if(cbIniciarMinimizado.Checked)
            {
                this.WindowState = FormWindowState.Minimized;
                notifyIcon1.Visible = true;
            }

            aTimer = new System.Timers.Timer();
            aTimer.Elapsed += OnTimedEvent;


            if (cbConectarIniciar.Checked)
            {
                Thread.Sleep(5000);
                Reconectar();
            }

        }

        private void BtnReconectar_Click(object sender, EventArgs e)
        {

            Reconnect();
        }

        private void Reconnect()
        {
            if (btnReconectar.Text != "Parar")
                Reconectar();
            else
            {
                Timer_Test_.Enabled = false;
                if (cbSerialUsb.Checked && !cbMid10Sv2.Checked)
                {
                    if (frmcomportindex > 0)
                        fCmdRet = RWDev.CloseSpecComPort(frmcomportindex);
                    if (fCmdRet == 0) frmcomportindex = -1;
                }

                if(cbMid10Sv2.Checked)
                {
                    RFID.CFComApi.CFCom_SetCallback(null);
                    RFID.CFComApi.CFCom_CloseDevice();
                }

                btnReconectar.Text = "Reconectar";
            }
        }

        private void BtnEncerrar_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void Timer_Test__Tick(object sender, EventArgs e)
        {
            if (!cbMid10Sv2.Checked)
            {

                if (fIsInventoryScan)
                    return;

                if (cbEthernet.Checked)
                    Inventory();
                if (cbSerialUsb.Checked)
                    InventorySerial();
            }
        }

        private void Inventory()
        {
            int i;
            int CardNum = 0;
            int Totallen = 0;
            int EPClen, m;
            byte[] EPC = new byte[5000];
            int CardIndex;
            string temps;
            string s, sEPC;
            bool isonlistview;
            fIsInventoryScan = true;
            byte AdrTID = 0;
            byte LenTID = 0;
            byte TIDFlag = 0;
            
            AdrTID = 0;
            LenTID = 0;
            TIDFlag = 0;

            ListViewItem aListItem = new ListViewItem();
            fCmdRet = StaticClassReaderB.Inventory_G2(ref fComAdr, AdrTID, LenTID, TIDFlag, EPC, ref Totallen, ref CardNum, frmcomportindex);
            if ((fCmdRet == 1) | (fCmdRet == 2) | (fCmdRet == 3) | (fCmdRet == 4) | (fCmdRet == 0xFB))
            {
                byte[] daw = new byte[Totallen];
                Array.Copy(EPC, daw, Totallen);
                temps = ByteArrayToHexString(daw);
                fInventory_EPC_List = temps;            
                m = 0;                
                if (CardNum == 0)
                {
                    fIsInventoryScan = false;
                    return;
                }
                for (CardIndex = 0; CardIndex < CardNum; CardIndex++)
                {
                    EPClen = daw[m];
                    sEPC = temps.Substring(m * 2 + 2, EPClen * 2);
                    m = m + EPClen + 1;
                    if (sEPC.Length != EPClen * 2)
                        return;
                    isonlistview = false;

                    if (cbNoRepeat.Checked)
                    {
                        if (txtLeitura.Text != sEPC)
                        {
                            txtLeitura.Text = sEPC;
                            //EmularTeclado(sEPC);
                        }
                    }
                    else
                    {
                        txtLeitura.Text = sEPC;
                        //EmularTeclado(sEPC);
                    }

                    
                }
            }
            else if (((fCmdRet == 0x30) || (fCmdRet == 0x37) || (fCmdRet == 0x35)))
            {
                fCmdRet = StaticClassReaderB.CloseNetPort(frmcomportindex);
                frmcomportindex = -1;
                int port = Convert.ToInt32(txtPortaLeitor.Text);
                string IPAddr = txtIpLeitor.Text;
                fCmdRet = StaticClassReaderB.OpenNetPort(port, IPAddr, ref fComAdr, ref frmcomportindex);
                fOpenComIndex = frmcomportindex;
            }
            
            fIsInventoryScan = false;
            if (fAppClosed)
                Close();
        }

        private void InventorySerial()
        {
            byte Ant = 0;
            int CardNum = 0;
            int Totallen = 0;
            int EPClen, m;
            byte[] EPC = new byte[50000];
            int CardIndex;
            string temps, temp;
            temp = "";
            string sEPC;
            byte MaskMem = 0;
            byte[] MaskAdr = new byte[2];
            byte MaskLen = 0;
            byte[] MaskData = new byte[100];
            byte MaskFlag = 0;
            byte AdrTID = 0;
            byte LenTID = 0;
            AdrTID = 0;
            LenTID = 6;
            MaskFlag = 0;
            bool isonlistview;

            int cbtime = System.Environment.TickCount;
            DataGridViewRow rows = new DataGridViewRow();
            CardNum = 0;
            fCmdRet = RWDev.Inventory_G2(ref fComAdr, 0x04, 0x00, MaskMem, MaskAdr, MaskLen, MaskData, MaskFlag, AdrTID, LenTID, 0x00, 0x00, 0x80, 0x0A, 0x01, EPC, ref Ant, ref Totallen, ref CardNum, frmcomportindex);
            
            int x_time = System.Environment.TickCount - cbtime;//Tempo de comando
            string strLog = "Inventory: " + GetReturnCodeDesc(fCmdRet);
            WriteLog(strLog);

            if ((fCmdRet == 1) | (fCmdRet == 2) | (fCmdRet == 3) | (fCmdRet == 4))//O representante encontrou o fim，
            {
                byte[] daw = new byte[Totallen];
                Array.Copy(EPC, daw, Totallen);
                temps = ByteArrayToHexString(daw);
                fInventory_EPC_List = temps;
                m = 0;
                if (CardNum == 0)
                {
                    fIsInventoryScan = false;
                    return;
                }
                sEPC = "";
                for (CardIndex = 0; CardIndex < CardNum; CardIndex++)
                {
                    EPClen = daw[m];
                    
                    try
                    {
                        sEPC = temps.Substring(m * 2 + 2, EPClen * 2);
                        m = m + EPClen + 1;
                    }
                    catch
                    { }

                    if (sEPC.Length != EPClen * 2)
                        return;
                    isonlistview = false;

                    if (cbNoRepeat.Checked)
                    {
                        if (txtLeitura.Text != sEPC)
                        {
                            txtLeitura.Text = sEPC;
                            //EmularTeclado(sEPC);
                        }
                    }
                    else
                    {
                        txtLeitura.Text = sEPC;
                        //EmularTeclado(sEPC);
                    }


                }
            }
        }

        private byte[] HexStringToByteArray(string s)
        {
            s = s.Replace(" ", "");
            byte[] buffer = new byte[s.Length / 2];
            for (int i = 0; i < s.Length; i += 2)
                buffer[i / 2] = (byte)Convert.ToByte(s.Substring(i, 2), 16);
            return buffer;
        }

        private void EmularTeclado(string sEPC)
        {

            string sSend2Key = "";
            vAtualizartxtStatus("TAG Identificada...");

            if (cbTraduzirEPC.Checked)
            {
                cEPCClass thisEpc = Viaonda.cEPCDecode(sEPC);
                sSend2Key = thisEpc.sEPCTagUri.ToString();
                if (thisEpc.sErrorMessage != "")
                    statusLabel.Text = "Erro ao Traduzir o EPC: " + thisEpc.sErrorMessage;
                
            }
            else
            {
                string sTemp;

                if (sEPC.Length >= nudPosicaoFinal.Value)
                    sTemp = sEPC.Substring(Decimal.ToInt32(nudPosicaoInicial.Value - 1), Decimal.ToInt32(nudPosicaoFinal.Value - (nudPosicaoInicial.Value - 1)));
                else
                    sTemp = sEPC;

                if(cbConvertHexDec.Checked)
                {
                    try
                    {
                        sSend2Key = int.Parse(sTemp, System.Globalization.NumberStyles.HexNumber).ToString();
                    }
                    catch
                    {
                        sSend2Key = "";
                        statusLabel.Text = "Erro ao converter para Decimal";
                    }
                }
                else
                {
                    if(cbIgnorarZeros.Checked)
                        sSend2Key = sTemp.TrimStart('0');
                    else
                        sSend2Key = sTemp;
                }
            }

            //txtResultado.Text = sSend2Key;
            vAtualizarTxtResultado(sSend2Key);

            if (cbHabilitarEmulacao.Checked && sSend2Key != "")
            {
                inputSimulator.Keyboard.TextEntry(sSend2Key);
                /*
                char[] b = new char[sSend2Key.Length];


                b = sSend2Key.ToCharArray();

                
                foreach (char c in b)
                {
                    try
                    {
                        SendKeys.Send(c.ToString());
                    }
                    catch
                    {
                        //SendKeys.SendWait(c.ToString());
                        inputSimulator.Keyboard.TextEntry(c.ToString());
                    }
                }
                */
                //SendKeys.Flush();




                //SendKeys.Send(sSend2Key);
                //SendKeys.Flush();




                if (cbEnviarEnter.Checked)
                {
                    try
                    {
                        //SendKeys.Send("{ENTER}");
                        inputSimulator.Keyboard.KeyPress(WindowsInput.Native.VirtualKeyCode.RETURN);
                    }                    
                        catch (Exception ex)
                    {
                        inputSimulator.Keyboard.KeyPress(WindowsInput.Native.VirtualKeyCode.RETURN);
                        //SendKeys.SendWait("{ENTER}");
                    }
                    //SendKeys.Flush();
                }

                
                //if (cbEnableInterval.Checked)
                //    Thread.Sleep(Decimal.ToInt32(nudReadTagInterval.Value));
            }

            GravarLog(sEPC, sSend2Key);
        }

        public void vAtualizartxtStatus(string sText)
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(vAtualizartxtStatus), new object[] { sText });
                return;
            }
            statusLabel.Text = sText;
            
        }

        public void vAtualizarTxtResultado(string sResult)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(vAtualizarTxtResultado), new object[] { sResult });
                return;
            }
            txtResultado.Text = sResult;
        }

        public void vLimparLeitura(string sResult)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(vLimparLeitura), new object[] { sResult });
                return;
            }
            txtLeitura.Text = sResult;
        }

        private void GravarLog(string sEPC, string sData)
        {
            if(cbGravarLog.Checked)
                ViaondaClass.WriteLog(sEPC, sData);
        }

        private string ByteArrayToHexString(byte[] data)
        {
            StringBuilder sb = new StringBuilder(data.Length * 3);
            foreach (byte b in data)
                sb.Append(Convert.ToString(b, 16).PadLeft(2, '0'));
            return sb.ToString().ToUpper();

        }
        private void AddCmdLog(string CMD, string cmdStr, int cmdRet)
        {
            try
            {
                statusLabel.Text = "";
                statusLabel.Text = DateTime.Now.ToLongTimeString() + " " +
                                            cmdStr + ": " +
                                            GetReturnCodeDesc(cmdRet);
            }
            finally
            {
                ;
            }
        }
        private void AddCmdLog(string CMD, string cmdStr, int cmdRet, int errocode)
        {
            try
            {
                statusLabel.Text = "";
                statusLabel.Text = DateTime.Now.ToLongTimeString() + " " +
                                            cmdStr + ": " +
                                            GetReturnCodeDesc(cmdRet) + " " + "0x" + Convert.ToString(errocode, 16).PadLeft(2, '0');
            }
            finally
            {
                ;
            }
        }

        private string GetReturnCodeDesc(int cmdRet)
        {
            switch (cmdRet)
            {
                case 0x00:
                    return "Operation Successed";
                case 0x01:
                    return "Return before Inventory finished";
                case 0x02:
                    return "the Inventory-scan-time overflow";
                case 0x03:
                    return "More Data";
                case 0x04:
                    return "Reader module MCU is Full";
                case 0x05:
                    return "Access Password Error";
                case 0x09:
                    return "Destroy Password Error";
                case 0x0a:
                    return "Destroy Password Error Cannot be Zero";
                case 0x0b:
                    return "Tag Not Support the command";
                case 0x0c:
                    return "Use the commmand,Access Password Cannot be Zero";
                case 0x0d:
                    return "Tag is protected,cannot set it again";
                case 0x0e:
                    return "Tag is unprotected,no need to reset it";
                case 0x10:
                    return "There is some locked bytes,write fail";
                case 0x11:
                    return "can not lock it";
                case 0x12:
                    return "is locked,cannot lock it again";
                case 0x13:
                    return "Parameter Save Fail,Can Use Before Power";
                case 0x14:
                    return "Cannot adjust";
                case 0x15:
                    return "Return before Inventory finished";
                case 0x16:
                    return "Inventory-Scan-Time overflow";
                case 0x17:
                    return "More Data";
                case 0x18:
                    return "Reader module MCU is full";
                case 0x19:
                    return "Not Support Command Or AccessPassword Cannot be Zero";
                case 0xFA:
                    return "Get Tag,Poor Communication,Inoperable";
                case 0xFB:
                    return "No Tag Operable";
                case 0xFC:
                    return "Tag Return ErrorCode";
                case 0xFD:
                    return "Command length wrong";
                case 0xFE:
                    return "Illegal command";
                case 0xFF:
                    return "Parameter Error";
                case 0x30:
                    return "Communication error";
                case 0x31:
                    return "CRC checksummat error";
                case 0x32:
                    return "Return data length error";
                case 0x33:
                    return "Communication busy";
                case 0x34:
                    return "Busy,command is being executed";
                case 0x35:
                    return "ComPort Opened";
                case 0x36:
                    return "ComPort Closed";
                case 0x37:
                    return "Invalid Handle";
                case 0x38:
                    return "Invalid Port";
                case 0xEE:
                    return "Return command error";
                default:
                    return "";
            }
        }
        private string GetErrorCodeDesc(int cmdRet)
        {
            switch (cmdRet)
            {
                case 0x00:
                    return "Other error";
                case 0x03:
                    return "Memory out or pc not support";
                case 0x04:
                    return "Memory Locked and unwritable";
                case 0x0b:
                    return "No Power,memory write operation cannot be executed";
                case 0x0f:
                    return "Not Special Error,tag not support special errorcode";
                default:
                    return "";
            }
        }

        private void CbTraduzirEPC_CheckedChanged(object sender, EventArgs e)
        {
            if(cbTraduzirEPC.Checked)
            {
                nudPosicaoFinal.Enabled = false;
                nudPosicaoFinal.Value = 24;
                nudPosicaoInicial.Value = 1;
                nudPosicaoInicial.Enabled = false;
                cbConvertHexDec.Checked = false;
                cbConvertHexDec.Enabled = false;
            }
            else
            {
                nudPosicaoFinal.Enabled = true;
                nudPosicaoFinal.Value = 24;
                nudPosicaoInicial.Value = 1;
                nudPosicaoInicial.Enabled = true;
                cbConvertHexDec.Enabled = true;
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            CarregarConfiguracoes();
        }

        private void StatusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void RadioButton_band1_CheckedChanged(object sender, EventArgs e)
        {
            int i;
            ComboBox_dmaxfre.Items.Clear();
            ComboBox_dminfre.Items.Clear();
            for (i = 0; i < 63; i++)
            {
                ComboBox_dminfre.Items.Add(Convert.ToString(902.6 + i * 0.4) + " MHz");
                ComboBox_dmaxfre.Items.Add(Convert.ToString(902.6 + i * 0.4) + " MHz");
            }
            ComboBox_dmaxfre.SelectedIndex = 62;
            ComboBox_dminfre.SelectedIndex = 0;
        }

        private void RadioButton_band2_CheckedChanged(object sender, EventArgs e)
        {
            int i;
            ComboBox_dmaxfre.Items.Clear();
            ComboBox_dminfre.Items.Clear();
            for (i = 0; i < 20; i++)
            {
                ComboBox_dminfre.Items.Add(Convert.ToString(920.125 + i * 0.25) + " MHz");
                ComboBox_dmaxfre.Items.Add(Convert.ToString(920.125 + i * 0.25) + " MHz");
            }
            ComboBox_dmaxfre.SelectedIndex = 19;
            ComboBox_dminfre.SelectedIndex = 0;
        }

        private void RadioButton_band3_CheckedChanged(object sender, EventArgs e)
        {
            int i;
            ComboBox_dmaxfre.Items.Clear();
            ComboBox_dminfre.Items.Clear();
            for (i = 0; i < 50; i++)
            {
                ComboBox_dminfre.Items.Add(Convert.ToString(902.75 + i * 0.5) + " MHz");
                ComboBox_dmaxfre.Items.Add(Convert.ToString(902.75 + i * 0.5) + " MHz");
            }
            ComboBox_dmaxfre.SelectedIndex = 49;
            ComboBox_dminfre.SelectedIndex = 0;
        }

        private void RadioButton_band4_CheckedChanged(object sender, EventArgs e)
        {
            int i;
            ComboBox_dmaxfre.Items.Clear();
            ComboBox_dminfre.Items.Clear();
            for (i = 0; i < 32; i++)
            {
                ComboBox_dminfre.Items.Add(Convert.ToString(917.1 + i * 0.2) + " MHz");
                ComboBox_dmaxfre.Items.Add(Convert.ToString(917.1 + i * 0.2) + " MHz");
            }
            ComboBox_dmaxfre.SelectedIndex = 31;
            ComboBox_dminfre.SelectedIndex = 0;
        }

        private void RadioButton_band5_CheckedChanged(object sender, EventArgs e)
        {
            int i;
            ComboBox_dminfre.Items.Clear();
            ComboBox_dmaxfre.Items.Clear();
            for (i = 0; i < 15; i++)
            {
                ComboBox_dminfre.Items.Add(Convert.ToString(865.1 + i * 0.2) + " MHz");
                ComboBox_dmaxfre.Items.Add(Convert.ToString(865.1 + i * 0.2) + " MHz");
            }
            ComboBox_dmaxfre.SelectedIndex = 14;
            ComboBox_dminfre.SelectedIndex = 0;
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            Timer_Test_.Enabled = false;
            btnReconectar.Text = "Reconectar";

            Properties.Settings.Default.ScanTime = ComboBox_scantime.SelectedIndex;
            Properties.Settings.Default.Save();
            //Timer_Test_.Interval = (ComboBox_scantime.SelectedIndex + 3) * 100;

            byte powerDbm, dminfre, dmaxfre, scantime, band = 0;
            string returninfo = "";
            string returninfoDlg = "";
            string setinfo;
            if (radioButton_band1.Checked)
                band = 0;
            if (radioButton_band2.Checked)
                band = 1;
            if (radioButton_band3.Checked)
                band = 2;
            if (radioButton_band4.Checked)
                band = 3;
            if (radioButton_band5.Checked)
                band = 4;

            progressBar1.Visible = true;
            progressBar1.Minimum = 0;
            dminfre = Convert.ToByte(((band & 3) << 6) | (ComboBox_dminfre.SelectedIndex & 0x3F));
            dmaxfre = Convert.ToByte(((band & 0x0c) << 4) | (ComboBox_dmaxfre.SelectedIndex & 0x3F));
            powerDbm = Convert.ToByte(ComboBox_PowerDbm.SelectedIndex);
            scantime = Convert.ToByte(ComboBox_scantime.SelectedIndex + 3);
            setinfo = "Write";
            progressBar1.Value = 10;
            progressBar1.Value = 25;
            fCmdRet = StaticClassReaderB.SetPowerDbm(ref fComAdr, powerDbm, frmcomportindex);
            if (fCmdRet == 0)
                returninfo = returninfo + ",Power Success";
            else if (fCmdRet == 0xEE)
                returninfo = returninfo + ",Power Response Command Error";
            else
            {
                returninfo = returninfo + ",Power Fail";
                returninfoDlg = returninfoDlg + " " + setinfo + "Power Fail Command Response=0x"
                     + Convert.ToString(fCmdRet) + "(" + GetReturnCodeDesc(fCmdRet) + ")";
            }

            progressBar1.Value = 40;
            fCmdRet = StaticClassReaderB.Writedfre(ref fComAdr, ref dmaxfre, ref dminfre, frmcomportindex);
            if (fCmdRet == 0)
                returninfo = returninfo + ",Frequency Success";
            else if (fCmdRet == 0xEE)
                returninfo = returninfo + ",Frequency Response Command Error";
            else
            {
                returninfo = returninfo + ",Frequency Fail";
                returninfoDlg = returninfoDlg + " " + setinfo + "Frequency Fail Command Response=0x"
                     + Convert.ToString(fCmdRet) + "(" + GetReturnCodeDesc(fCmdRet) + ")";
            }

            progressBar1.Value = 55;

            progressBar1.Value = 70;
            fCmdRet = StaticClassReaderB.WriteScanTime(ref fComAdr, ref scantime, frmcomportindex);
            if (fCmdRet == 0)
                returninfo = returninfo + ",InventoryScanTime Success";
            else if (fCmdRet == 0xEE)
                returninfo = returninfo + ",InventoryScanTime Response Command Error";
            else
            {
                returninfo = returninfo + ",InventoryScanTime Fail";
                returninfoDlg = returninfoDlg + " " + setinfo + "InventoryScanTime Fail Command Response=0x"
                     + Convert.ToString(fCmdRet) + "(" + GetReturnCodeDesc(fCmdRet) + ")";
            }

            progressBar1.Value = 100;

            progressBar1.Visible = false;
            statusLabel.Text = returninfo;
            if (returninfoDlg != "")
                MessageBox.Show(returninfoDlg, "Information");

            byte[] Parameter = new byte[6];
            Parameter[0] = Convert.ToByte(comboBox4.SelectedIndex);
            fCmdRet = StaticClassReaderB.SetWorkMode(ref fComAdr, Parameter, frmcomportindex);
            if (fCmdRet == 0)
            {
                statusLabel.Text = "Parâmetros gravados com sucesso.";
            }
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            string IPAddr = "";
            IPAddress newIpAddr;
            try
            {
                newIpAddr = IPAddress.Parse(txtNewIP.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Por favor, informe um endereço de IP Válido", "Viaonda RFID", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            try
            {

                IPEndPoint iep = new IPEndPoint(IPAddress.Parse(txtIpLeitor.Text), 65535);
                EndPoint ep = (EndPoint)iep;

                string request = "X";
                byte[] buffer = Encoding.ASCII.GetBytes(request);
                sock.SendTo(buffer, iep);
                Thread.Sleep(100);

                request = "L";
                buffer = Encoding.ASCII.GetBytes(request);
                sock.SendTo(buffer, iep);
                Thread.Sleep(50);

                request = "SIP" + IPAddr + "|34";
                buffer = Encoding.ASCII.GetBytes(request);
                sock.SendTo(buffer, iep);
                Thread.Sleep(10);

                request = "E|35";
                buffer = Encoding.ASCII.GetBytes(request);
                sock.SendTo(buffer, iep);
                Thread.Sleep(200);

                request = "L";
                buffer = Encoding.ASCII.GetBytes(request);
                sock.SendTo(buffer, iep);
                Thread.Sleep(50);

                request = "SIP" + IPAddr + "|34";
                buffer = Encoding.ASCII.GetBytes(request);
                sock.SendTo(buffer, iep);
                Thread.Sleep(100);

                request = "E|35";
                buffer = Encoding.ASCII.GetBytes(request);
                sock.SendTo(buffer, iep);

                MessageBox.Show("IP Alterado com sucesso.", "Viaonda RFID", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Falha ao alterar o IP. Tente novamente.", "Viaonda RFID", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sock.Close();
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string logFilePath = ViaondaClass.GetCurrentDirectory().Replace(@"file:\", "");
            Process.Start(@logFilePath);
        }

        private void CbSerialUsb_CheckedChanged(object sender, EventArgs e)
        {
            if (cbSerialUsb.Checked)
                cbEthernet.Checked = false;
        }

        private void CbEthernet_CheckedChanged(object sender, EventArgs e)
        {
            if (cbEthernet.Checked)
                cbSerialUsb.Checked = false;
        }

        private void txtLeitura_TextChanged(object sender, EventArgs e)
        {
            
        }
    }


}
