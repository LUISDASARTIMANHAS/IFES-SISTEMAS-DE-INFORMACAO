﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViaondaAgentEmuladorTeclado
{
    class ViaondaClass
    {        
        private static byte[] bIV = { 0x50, 0x08, 0xF1, 0xDD, 0xDE, 0x3C, 0xF2, 0x18, 0x44, 0x74, 0x19, 0x2C, 0x53, 0x49, 0xAB, 0xBC };

        private const string cryptoKey = "Q3JpcHRvZ3JhZmlhcyBjb20gUmluamRhZWwgLyBBRVM=";
        static readonly string[] Nybbles = { "0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111" };


        public static void WriteLog(string strLog, string sEnviadoEmulador)
        {
            StreamWriter log;
            FileStream fileStream = null;
            DirectoryInfo logDirInfo = null;
            FileInfo logFileInfo;
            string sLineHeader = "Data_Hora;Leitura;Enviado_Emulador;";
            bool bInsertHeader = false;

            string sTime = System.DateTime.Now.ToString("HH:mm:ss:ffff");

            string logFilePath = GetCurrentDirectory().Replace(@"file:\", "");
            logFilePath = logFilePath + @"\ViaondaRFID_Log-" + System.DateTime.Today.ToString("MM-dd-yyyy") + "." + "csv";
            logFileInfo = new FileInfo(logFilePath);
            logDirInfo = new DirectoryInfo(logFileInfo.DirectoryName);
            if (!logDirInfo.Exists) logDirInfo.Create();
            try
            {
                if (!logFileInfo.Exists)
                {
                    fileStream = logFileInfo.Create();
                    bInsertHeader = true;
                }
                else
                {
                    fileStream = new FileStream(logFilePath, FileMode.Append);
                }
            }
            catch
            {
                MessageBox.Show("Não foi possível gravar o arquivo, verifique se ele está aberto ou sendo utilizado por outro aplicativo.");
            }

            try
            {
                log = new StreamWriter(fileStream);
                if (bInsertHeader)
                    log.WriteLine(sLineHeader);
                log.WriteLine(sTime + ";" + strLog + ";" + sEnviadoEmulador + ";");
                log.Close();
            }
            catch
            { }

        }
        static string HexToBin(string input)
        {
            StringBuilder builder = new StringBuilder(input.Length * 4);
            foreach (char c in input)
            {
                if (c >= '0' && c <= '9')
                {
                    builder.Append(Nybbles[c - '0']);
                }
                else if (c >= 'a' && c <= 'f')
                {
                    builder.Append(Nybbles[c - 'a' + 10]);
                }
                else if (c >= 'A' && c <= 'F')
                {
                    builder.Append(Nybbles[c - 'A' + 10]);
                }
                else
                {
                    throw new FormatException("Invalid hex digit: " + c);
                }
            }
            return builder.ToString();
        }

        public string sConvertHexToBin(string sHexString)
        {
            return HexToBin(sHexString);
        }

        public string Bin2Hex(string sBin)
        {
            return Convert.ToString(Convert.ToUInt32(sBin, 2), 16).ToString();
        }

        public static string GetCurrentDirectory()
        {
            return Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase);
        }
             
        public ArrayList GetCurrentIPAddress()
        {
            LogErros("ViaondaClass", "Buscando IP Local");
            ArrayList sRetorno = new ArrayList();
            try
            {
                String strHostName = string.Empty;
                // Getting Ip address of local machine...
                // First get the host name of local machine.
                strHostName = Dns.GetHostName();
                Console.WriteLine("Local Machine's Host Name: " + strHostName);
                // Then using host name, get the IP address list..
                IPHostEntry ipEntry = Dns.GetHostEntry(strHostName);
                IPAddress[] addr = ipEntry.AddressList;

                for (int i = 0; i < addr.Length; i++)
                {
                    sRetorno.Add(addr[i].ToString());

                }
            }
            catch (Exception)
            {
                sRetorno = null;
            }
            return sRetorno;
        }

        public void LogErros(string sModulo, string sTexto)
        {
            try
            {
                string strFilePath = GetCurrentDirectory();
                string sNomeArquivo = "log_" + System.DateTime.Today.Year.ToString() +
                    System.DateTime.Today.Month.ToString() +
                    System.DateTime.Today.Day.ToString() + ".log";
                string ArquivoLog = @strFilePath + @"\" + sNomeArquivo;

                StreamWriter swLog = new StreamWriter(ArquivoLog, true);
                swLog.AutoFlush = true;
                swLog.WriteLine(System.DateTime.Now.ToShortDateString() + " " + System.DateTime.Now.ToLongTimeString() +
                    " - " + sModulo + " | " + sTexto);
                swLog.Flush();
                swLog.Close();
            }
            catch
            {

            }

        }

        public string sCarregarLogCompleto()
        {
            string sRetorno = "";
            try
            {
                string strFilePath = GetCurrentDirectory();
                string sNomeArquivo = "log_" + System.DateTime.Today.Year.ToString() +
                    System.DateTime.Today.Month.ToString() +
                    System.DateTime.Today.Day.ToString() + ".log";
                string ArquivoLog = @strFilePath + @"\" + sNomeArquivo;

                StreamReader swLog = new StreamReader(ArquivoLog);
                sRetorno = swLog.ReadToEnd();
                swLog.Close();
            }
            catch
            {
            }
            return sRetorno;
        }

        public void DeleteLog()
        {
            try
            {
                string strFilePath = GetCurrentDirectory();
                string sNomeArquivo = "log_" + System.DateTime.Today.Year.ToString() +
                    System.DateTime.Today.Month.ToString() +
                    System.DateTime.Today.Day.ToString() + ".log";
                string ArquivoLog = @strFilePath + @"\" + sNomeArquivo;

                File.Delete(ArquivoLog);
            }
            catch
            {
            }
        }

        public string Encrypt(string text)
        {
            byte[] Results;
            System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();
            MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
            byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(cryptoKey));
            TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();
            TDESAlgorithm.Key = TDESKey;
            TDESAlgorithm.Mode = CipherMode.ECB;
            TDESAlgorithm.Padding = PaddingMode.PKCS7;
            byte[] DataToEncrypt = UTF8.GetBytes(text);
            try
            {
                ICryptoTransform Encryptor = TDESAlgorithm.CreateEncryptor();
                Results = Encryptor.TransformFinalBlock(DataToEncrypt, 0, DataToEncrypt.Length);
            }
            finally
            {
                TDESAlgorithm.Clear();
                HashProvider.Clear();
            }
            return Convert.ToBase64String(Results);
        }

        /// <summary>     
        /// Pega um valor previamente criptografado e retorna o valor inicial 
        /// </summary>     
        /// <param name="text">texto criptografado</param>     
        /// <returns>valor descriptografado</returns>     
        public string Decrypt(string text)
        {
            byte[] Results;
            System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();
            MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
            byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(cryptoKey));
            TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();
            TDESAlgorithm.Key = TDESKey;
            TDESAlgorithm.Mode = CipherMode.ECB;
            TDESAlgorithm.Padding = PaddingMode.PKCS7;
            byte[] DataToDecrypt = Convert.FromBase64String(text);
            try
            {
                ICryptoTransform Decryptor = TDESAlgorithm.CreateDecryptor();
                Results = Decryptor.TransformFinalBlock(DataToDecrypt, 0, DataToDecrypt.Length);
            }
            finally
            {
                TDESAlgorithm.Clear();
                HashProvider.Clear();
            }
            return UTF8.GetString(Results, 0, Results.Length);

        }
        
        public Int32 Bin2Int32(String binaryNotation)
        {
            Double ans = 0;
            Int32 count = 0;
            for (Int32 i = binaryNotation.Length - 1; i > -1; i--)
            {
                if (binaryNotation[i] == '1')
                {
                    ans += Math.Pow(2, count);
                }
                count++;
            }


            return (Int32)ans;
        }

        public struct sRetornoEPC
        {
            public int iSaidaNegada { get; set; }
            public int iSaidaAutorizada { get; set; }
            public string sMensagem { get; set; }
            public bool bAcessoAutorizado { get; set; }
            public string sRetornoGenerico { get; set; }

            public sRetornoEPC(string sMensagem, int iSaidaNegada, int iSaidaAutorizada, bool bAcessoAutorizado, string sRetornoGenerico)
            {
                this.iSaidaAutorizada = iSaidaAutorizada;
                this.iSaidaNegada = iSaidaNegada;
                this.sMensagem = sMensagem;
                this.bAcessoAutorizado = bAcessoAutorizado;
                this.sRetornoGenerico = sRetornoGenerico;
            }


        }

        public cEPCClass cEPCDecode(string sEPCHex)
        {
            string sHeader, sFilter, sPartition;
            int company_prefix_bits = 0;
            int company_prefix_digits = 0;
            int item_reference_bits = 0;
            int item_reference_digists = 0;
            int iFilter = 0;
            string sEpcMgt = String.Empty;
            string sObjClass = String.Empty;
            string sSerial = String.Empty;

            cEPCClass cEPCTemp = new cEPCClass();
            cEPCPartition cEPCPartition = new cEPCPartition();

            cEPCTemp.sEPCHex = sEPCHex;
            cEPCTemp.sEPCBinary = HexToBin(sEPCHex);



            try
            {

                sHeader = cEPCTemp.sEPCBinary.Substring(0, 8);
                sFilter = cEPCTemp.sEPCBinary.Substring(8, 3);
                iFilter = Convert.ToInt32(sFilter, 2);
                sPartition = cEPCTemp.sEPCBinary.Substring(11, 3);


                switch (sHeader)
                {
                    case "00000000": //UNDEFINED
                        cEPCTemp.sErrorMessage = "EPC Não Reconhecido.";
                        break;
                    case "00101100": //gdti-96 - GDTI
                        cEPCTemp.sEPCScheme = "GDTI";
                        cEPCTemp.sEPCCodingScheme = "gdti-96";
                        cEPCTemp.sEPCHexHeader = "2C";
                        cEPCTemp.sEPCSchemeDescription = "Global Document Type Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:gdti:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:gdti-96:" + iFilter.ToString() + ".";
                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sGDTIDocumentType = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));
                        cEPCTemp.sGDTISerialNumber = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits + item_reference_bits, (cEPCTemp.sEPCBinary.Length - (14 + company_prefix_bits + item_reference_bits))), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGDTIDocumentType, ".", cEPCTemp.sGDTISerialNumber);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGDTIDocumentType, ".", cEPCTemp.sGDTISerialNumber);

                        break;
                    case "00111010": //gdti-113 - GDTI
                        cEPCTemp.sEPCScheme = "GDTI";
                        cEPCTemp.sEPCCodingScheme = "gdti-113";
                        cEPCTemp.sEPCHexHeader = "3A";
                        cEPCTemp.sEPCSchemeDescription = "Global Document Type Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:gdti:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:gdti-113:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sGDTIDocumentType = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));
                        cEPCTemp.sGDTISerialNumber = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits + item_reference_bits, (cEPCTemp.sEPCBinary.Length - (14 + company_prefix_bits + item_reference_bits))), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGDTIDocumentType, ".", cEPCTemp.sGDTISerialNumber);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGDTIDocumentType, ".", cEPCTemp.sGDTISerialNumber);
                        break;
                    case "00111110": //gdti-174 - GDTI
                        cEPCTemp.sEPCScheme = "GDTI";
                        cEPCTemp.sEPCCodingScheme = "gdti-174";
                        cEPCTemp.sEPCHexHeader = "3E";
                        cEPCTemp.sEPCSchemeDescription = "Global Document Type Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:gdti:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:gdti-174:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sGDTIDocumentType = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));
                        cEPCTemp.sGDTISerialNumber = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits + item_reference_bits, (cEPCTemp.sEPCBinary.Length - (14 + company_prefix_bits + item_reference_bits))), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)), ".", cEPCTemp.sGDTIDocumentType, ".", cEPCTemp.sGDTISerialNumber);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)), ".", cEPCTemp.sGDTIDocumentType, ".", cEPCTemp.sGDTISerialNumber);
                        break;
                    case "00110000": //sgtin-96 - GTIN
                        cEPCTemp.sEPCScheme = "GTIN";
                        cEPCTemp.sEPCCodingScheme = "gtin-96";
                        cEPCTemp.sEPCHexHeader = "30";
                        cEPCTemp.sEPCSchemeDescription = "Global Trade Item Number";
                        cEPCTemp.sEPCUri = "urn:epc:id:sgtin:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:sgtin-96:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sGTINItemRef = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));
                        cEPCTemp.sGTINSerialNumber = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits + item_reference_bits, (cEPCTemp.sEPCBinary.Length - (14 + company_prefix_bits + item_reference_bits))), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri + Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGTINItemRef, ".", cEPCTemp.sGTINSerialNumber);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGTINItemRef, ".", cEPCTemp.sGTINSerialNumber);
                        break;
                    case "00110110": //sgtin-198 - GTIN
                        cEPCTemp.sEPCScheme = "GTIN";
                        cEPCTemp.sEPCCodingScheme = "gtin-198";
                        cEPCTemp.sEPCHexHeader = "36";
                        cEPCTemp.sEPCSchemeDescription = "Global Trade Item Number";
                        cEPCTemp.sEPCUri = "urn:epc:id:sgtin:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:sgtin-198:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);


                        cEPCTemp.sGTINItemRef = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));

                        cEPCTemp.sGTINSerialNumber = Convert.ToString(
                            Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits + item_reference_bits, (cEPCTemp.sEPCBinary.Length - (14 + company_prefix_bits + item_reference_bits))), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri + Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGTINItemRef, ".", cEPCTemp.sGTINSerialNumber);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGTINItemRef, ".", cEPCTemp.sGTINSerialNumber);
                        break;
                    case "00110001": //sscc-96 - SSCC
                        cEPCTemp.sEPCScheme = "SSCC";
                        cEPCTemp.sEPCCodingScheme = "sscc-96";
                        cEPCTemp.sEPCHexHeader = "31";
                        cEPCTemp.sEPCSchemeDescription = "Serial Shipping Container Code";
                        cEPCTemp.sEPCUri = "urn:epc:id:sscc:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:sscc-96:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sSSCCSerialRef = Convert.ToString(
                            Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sSSCCSerialRef);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sSSCCSerialRef);
                        cEPCTemp.sGTINSerialNumber = cEPCTemp.sSSCCSerialRef;

                        break;
                    case "00110010": //gln-96 - GLN
                        cEPCTemp.sEPCScheme = "GLN";
                        cEPCTemp.sEPCCodingScheme = "sgln-96";
                        cEPCTemp.sEPCHexHeader = "32";
                        cEPCTemp.sEPCSchemeDescription = "Global Location Number";
                        cEPCTemp.sEPCUri = "urn:epc:id:gln:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:sgln-96:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sSGLNLocationRef = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));
                        cEPCTemp.sSGLNExtensionComp = Convert.ToString(
                            Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits + item_reference_bits, (cEPCTemp.sEPCBinary.Length - (14 + company_prefix_bits + item_reference_bits))), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sSGLNLocationRef, ".", cEPCTemp.sSGLNExtensionComp);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sSGLNLocationRef, ".", cEPCTemp.sSGLNExtensionComp);

                        break;
                    case "00111001": //gln-195 - GLN
                        cEPCTemp.sEPCScheme = "GLN";
                        cEPCTemp.sEPCCodingScheme = "sgln-195";
                        cEPCTemp.sEPCHexHeader = "39";
                        cEPCTemp.sEPCSchemeDescription = "Global Location Number";
                        cEPCTemp.sEPCUri = "urn:epc:id:gln:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:sgln-96:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sSGLNLocationRef = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));
                        cEPCTemp.sSGLNExtensionComp = Convert.ToString(
                            Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits + item_reference_bits, (cEPCTemp.sEPCBinary.Length - (14 + company_prefix_bits + item_reference_bits))), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sSGLNLocationRef, ".", cEPCTemp.sSGLNExtensionComp);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sSGLNLocationRef, ".", cEPCTemp.sSGLNExtensionComp);

                        break;
                    case "00110011": //grai-96 - GRAI
                        cEPCTemp.sEPCScheme = "GRAI";
                        cEPCTemp.sEPCCodingScheme = "grai-96";
                        cEPCTemp.sEPCHexHeader = "33";
                        cEPCTemp.sEPCSchemeDescription = "Global Returnable Asset Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:grai:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:grai-96:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sGRAIAssetType = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));
                        cEPCTemp.sGRAISerialNumber = Convert.ToString(
                            Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits + item_reference_bits, (cEPCTemp.sEPCBinary.Length - (14 + company_prefix_bits + item_reference_bits))), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGRAIAssetType, ".", cEPCTemp.sGRAISerialNumber);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGRAIAssetType, ".", cEPCTemp.sGRAISerialNumber);

                        break;
                    case "00110111": //grai-170 - GRAI
                        cEPCTemp.sEPCScheme = "GRAI";
                        cEPCTemp.sEPCCodingScheme = "grai-170";
                        cEPCTemp.sEPCHexHeader = "37";
                        cEPCTemp.sEPCSchemeDescription = "Global Returnable Asset Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:grai:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:grai-170:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sGRAIAssetType = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));
                        cEPCTemp.sGRAISerialNumber = Convert.ToString(
                            Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits + item_reference_bits, (cEPCTemp.sEPCBinary.Length - (14 + company_prefix_bits + item_reference_bits))), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGRAIAssetType, ".", cEPCTemp.sGRAISerialNumber);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGRAIAssetType, ".", cEPCTemp.sGRAISerialNumber);
                        break;
                    case "00110100": //giai-96 - GIAI
                        cEPCTemp.sEPCScheme = "GIAI";
                        cEPCTemp.sEPCCodingScheme = "giai-96";
                        cEPCTemp.sEPCHexHeader = "34";
                        cEPCTemp.sEPCSchemeDescription = "Global Individual Asset Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:giai:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:giai-96:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sGRAISerialNumber = Convert.ToString(
                            Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGRAISerialNumber);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGRAISerialNumber);

                        break;
                    case "00111000": //giai-202 - GIAI
                        cEPCTemp.sEPCScheme = "GIAI";
                        cEPCTemp.sEPCCodingScheme = "giai-202";
                        cEPCTemp.sEPCHexHeader = "38";
                        cEPCTemp.sEPCSchemeDescription = "Global Individual Asset Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:giai:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:giai-202:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sGRAISerialNumber = Convert.ToString(
                            Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ":", cEPCTemp.sGRAISerialNumber);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ":", cEPCTemp.sGRAISerialNumber);

                        break;
                    case "00111111": //sgcn-96 - SGCN
                        cEPCTemp.sEPCScheme = "SGCN";
                        cEPCTemp.sEPCCodingScheme = "sgcn-96";
                        cEPCTemp.sEPCHexHeader = "3F";
                        cEPCTemp.sEPCSchemeDescription = "Global Coupon Number";
                        cEPCTemp.sEPCUri = "urn:epc:id:sgcn:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:sgcn-96:" + iFilter.ToString() + ".";
                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);
                        break;
                    case "00101101": //gsrn-96 - GSRN
                        cEPCTemp.sEPCScheme = "GSRN";
                        cEPCTemp.sEPCCodingScheme = "gsrn-96";
                        cEPCTemp.sEPCHexHeader = "2D";
                        cEPCTemp.sEPCSchemeDescription = "Global Service Relation Number";
                        cEPCTemp.sEPCUri = "urn:epc:id:gsrn:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:gsrn-96:" + iFilter.ToString() + ".";

                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);

                        company_prefix_bits = cEPCPartition.iEPCCompanyPrefixBits;
                        company_prefix_digits = cEPCPartition.iEPCCompanyPrefixDigits;
                        item_reference_bits = cEPCPartition.iEPCItemReferenceBits;
                        item_reference_digists = cEPCPartition.iEPCItemReferenceDigits;

                        sEpcMgt = cEPCTemp.sEPCBinary.Substring(14, company_prefix_bits);

                        cEPCTemp.sGSRNServiceRef = Convert.ToString(Convert.ToInt64(cEPCTemp.sEPCBinary.Substring(14 + company_prefix_bits, item_reference_bits), 2));

                        cEPCTemp.sEPCTagUri = String.Concat(cEPCTemp.sEPCTagUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGSRNServiceRef);
                        cEPCTemp.sEPCUri = String.Concat(cEPCTemp.sEPCUri, Convert.ToString(Convert.ToInt64(sEpcMgt, 2)).PadLeft(company_prefix_digits, '0'), ".", cEPCTemp.sGSRNServiceRef);

                        break;
                    case "00101110": //gsrnp-96 - GSRNP
                        cEPCTemp.sEPCScheme = "GSRNP";
                        cEPCTemp.sEPCCodingScheme = "gsrnp-96";
                        cEPCTemp.sEPCHexHeader = "2E";
                        cEPCTemp.sEPCSchemeDescription = "Global Service Relation Number";
                        cEPCTemp.sEPCUri = "urn:epc:id:gsrnp:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:gsrnp-96:" + iFilter.ToString() + ".";
                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);
                        break;
                    case "00111100": //cpi-96 - CPI
                        cEPCTemp.sEPCScheme = "CPI";
                        cEPCTemp.sEPCCodingScheme = "cpi-96";
                        cEPCTemp.sEPCHexHeader = "3C";
                        cEPCTemp.sEPCSchemeDescription = "CPI Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:cpi:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:cpi-96:" + iFilter.ToString() + ".";
                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);
                        break;
                    case "00111101": //cpi-var - CPI
                        cEPCTemp.sEPCScheme = "CPI";
                        cEPCTemp.sEPCCodingScheme = "cpi-var";
                        cEPCTemp.sEPCHexHeader = "2D";
                        cEPCTemp.sEPCSchemeDescription = "CPI Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:cpi:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:cpi-var:" + iFilter.ToString() + ".";
                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);
                        break;
                    case "00110101": //gid-96 - GID
                        cEPCTemp.sEPCScheme = "GID";
                        cEPCTemp.sEPCCodingScheme = "gid-96";
                        cEPCTemp.sEPCHexHeader = "35";
                        cEPCTemp.sEPCSchemeDescription = "General Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:gid:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:gid-96:" + iFilter.ToString() + ".";
                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);
                        break;
                    case "00111011": //adi-96 - ADI
                        cEPCTemp.sEPCScheme = "ADI";
                        cEPCTemp.sEPCCodingScheme = "adi-96";
                        cEPCTemp.sEPCHexHeader = "3B";
                        cEPCTemp.sEPCSchemeDescription = "ADI Identifier";
                        cEPCTemp.sEPCUri = "urn:epc:id:adi:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:adi-var:" + iFilter.ToString() + ".";
                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);
                        break;
                    case "00101111": //USDoD-96 - USDOD
                        cEPCTemp.sEPCScheme = "USDOD";
                        cEPCTemp.sEPCCodingScheme = "USDoD-96";
                        cEPCTemp.sEPCHexHeader = "2F";
                        cEPCTemp.sEPCSchemeDescription = "US Dept of Defense supply chain";
                        cEPCTemp.sEPCUri = "urn:epc:id:usdod:";
                        cEPCTemp.sEPCTagUri = "urn:epc:tag:usdod-96:" + iFilter.ToString() + ".";
                        cEPCPartition = cEPCPartition.cEPCGetPartitionInfo(cEPCTemp.sEPCCodingScheme, sPartition);
                        break;
                    default:
                        cEPCTemp.sEPCScheme = "";
                        cEPCTemp.sEPCCodingScheme = "";
                        cEPCTemp.sEPCHexHeader = "";
                        cEPCTemp.sEPCSchemeDescription = "";
                        cEPCTemp.sEPCUri = "";
                        cEPCTemp.sEPCTagUri = "";
                        cEPCTemp.sErrorMessage = "EPC Não Reconhecido.";
                        break;
                }
            }
            catch (Exception ex)
            {
                cEPCTemp.sErrorMessage = "Erro Convertendo o EPC [" + ex.Message + "]";
            }

            return cEPCTemp;
        }
    }


    class cEPCClass
    {
        public string sEPCScheme { get; set; }
        public string sEPCHex { get; set; }
        public string sEPCBinary { get; set; }
        public string sEPCCodingScheme { get; set; }
        public string sEPCHexHeader { get; set; }
        public string sEPCSchemeDescription { get; set; }
        public string sEPCUri { get; set; }
        public string sEPCTagUri { get; set; }
        public string sSGLNExtensionComp { get; set; }
        public string sSGLNLocationRef { get; set; }
        public string sGIAIIndAssetRef { get; set; }
        public string sGRAIAssetType { get; set; }
        public string sGRAISerialNumber { get; set; }
        public string sGDTIDocumentType { get; set; }
        public string sGDTISerialNumber { get; set; }
        public string sGSRNServiceRef { get; set; }
        public string sGTINItemRef { get; set; }
        public string sGTINSerialNumber { get; set; }
        public string sSSCCSerialRef { get; set; }
        public string sSGCNEpcCouponReference { get; set; }
        public string sSGIDEpcGeneralManagerNum { get; set; }
        public string sSGIDEpcObjectClass { get; set; }
        public string sSDODEpcCageDodaac { get; set; }
        public string sSDODEpcPartNumber { get; set; }
        public string sErrorMessage { get; set; }


        public cEPCClass()
        {
            this.sEPCScheme = String.Empty;
            this.sEPCHex = String.Empty;
            this.sEPCBinary = String.Empty;
            this.sEPCCodingScheme = String.Empty;
            this.sEPCHexHeader = String.Empty;
            this.sEPCSchemeDescription = String.Empty;
            this.sEPCUri = String.Empty;
            this.sEPCTagUri = String.Empty;
            this.sSGLNExtensionComp = String.Empty;
            this.sSGLNLocationRef = String.Empty;
            this.sGIAIIndAssetRef = String.Empty;
            this.sGRAIAssetType = String.Empty;
            this.sGRAISerialNumber = String.Empty;
            this.sGDTIDocumentType = String.Empty;
            this.sGDTISerialNumber = String.Empty;
            this.sGSRNServiceRef = String.Empty;
            this.sGTINItemRef = String.Empty;
            this.sGTINSerialNumber = String.Empty;
            this.sSSCCSerialRef = String.Empty;
            this.sSGCNEpcCouponReference = String.Empty;
            this.sSGIDEpcGeneralManagerNum = String.Empty;
            this.sSGIDEpcObjectClass = String.Empty;
            this.sSDODEpcCageDodaac = String.Empty;
            this.sSDODEpcPartNumber = String.Empty;
            this.sErrorMessage = String.Empty;
        }


    }

    class cEPCPartition
    {
        public string sEPCScheme { get; set; }
        public string sEPCBinaryPart { get; set; }
        public int iEPCDecimalPart { get; set; }
        public int iEPCCompanyPrefixBits { get; set; }
        public int iEPCCompanyPrefixDigits { get; set; }
        public int iEPCItemReferenceBits { get; set; }
        public int iEPCItemReferenceDigits { get; set; }

        public cEPCPartition()
        {
            this.sEPCScheme = String.Empty;
            this.sEPCBinaryPart = String.Empty;
            this.iEPCDecimalPart = 0;
            this.iEPCCompanyPrefixBits = 0;
            this.iEPCCompanyPrefixDigits = 0;
            this.iEPCItemReferenceBits = 0;
            this.iEPCItemReferenceDigits = 0;

        }

        public cEPCPartition cEPCGetPartitionInfo(string sEPCCodingScheme, string sEPCBinaryPartition)
        {
            cEPCPartition cPartitionReturn = new cEPCPartition();

            switch (sEPCCodingScheme)
            {
                case "gtin-96":
                    cPartitionReturn.sEPCScheme = "GTIN";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 10;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 20;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 24;
                            cPartitionReturn.iEPCItemReferenceDigits = 7;
                            break;
                    }
                    break;
                case "gtin-198":
                    cPartitionReturn.sEPCScheme = "GTIN";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 10;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 20;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 24;
                            cPartitionReturn.iEPCItemReferenceDigits = 7;
                            break;
                    }
                    break;
                case "sscc-96":
                    cPartitionReturn.sEPCScheme = "SSCC";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 18;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 24;
                            cPartitionReturn.iEPCItemReferenceDigits = 7;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 28;
                            cPartitionReturn.iEPCItemReferenceDigits = 8;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 31;
                            cPartitionReturn.iEPCItemReferenceDigits = 9;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 34;
                            cPartitionReturn.iEPCItemReferenceDigits = 10;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 38;
                            cPartitionReturn.iEPCItemReferenceDigits = 11;
                            break;
                    }
                    break;
                case "sgln-96":
                    cPartitionReturn.sEPCScheme = "GLN";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 1;
                            cPartitionReturn.iEPCItemReferenceDigits = 0;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 11;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                    }
                    break;
                case "sgln-195":
                    cPartitionReturn.sEPCScheme = "GLN";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 1;
                            cPartitionReturn.iEPCItemReferenceDigits = 0;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 11;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                    }
                    break;
                case "grai-96":
                    cPartitionReturn.sEPCScheme = "GRAI";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 0;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 10;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 20;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 24;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                    }
                    break;
                case "grai-170":
                    cPartitionReturn.sEPCScheme = "GRAI";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 0;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 10;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 20;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 24;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                    }
                    break;
                case "giai-96":
                    cPartitionReturn.sEPCScheme = "GIAI";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 42;
                            cPartitionReturn.iEPCItemReferenceDigits = 13;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 45;
                            cPartitionReturn.iEPCItemReferenceDigits = 14;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 48;
                            cPartitionReturn.iEPCItemReferenceDigits = 15;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 52;
                            cPartitionReturn.iEPCItemReferenceDigits = 16;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 55;
                            cPartitionReturn.iEPCItemReferenceDigits = 17;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 58;
                            cPartitionReturn.iEPCItemReferenceDigits = 18;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 62;
                            cPartitionReturn.iEPCItemReferenceDigits = 19;
                            break;
                    }
                    break;
                case "giai-202":
                    cPartitionReturn.sEPCScheme = "GIAI";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 148;
                            cPartitionReturn.iEPCItemReferenceDigits = 18;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 151;
                            cPartitionReturn.iEPCItemReferenceDigits = 19;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 154;
                            cPartitionReturn.iEPCItemReferenceDigits = 20;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 158;
                            cPartitionReturn.iEPCItemReferenceDigits = 21;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 161;
                            cPartitionReturn.iEPCItemReferenceDigits = 22;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 164;
                            cPartitionReturn.iEPCItemReferenceDigits = 23;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 168;
                            cPartitionReturn.iEPCItemReferenceDigits = 24;
                            break;
                    }
                    break;
                case "gsrn-96":
                    cPartitionReturn.sEPCScheme = "GSRN";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 18;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 24;
                            cPartitionReturn.iEPCItemReferenceDigits = 7;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 28;
                            cPartitionReturn.iEPCItemReferenceDigits = 8;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 31;
                            cPartitionReturn.iEPCItemReferenceDigits = 9;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 34;
                            cPartitionReturn.iEPCItemReferenceDigits = 10;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 38;
                            cPartitionReturn.iEPCItemReferenceDigits = 11;
                            break;
                    }
                    break;
                case "gsrnp-96":
                    cPartitionReturn.sEPCScheme = "GSRNP";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 18;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 24;
                            cPartitionReturn.iEPCItemReferenceDigits = 7;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 28;
                            cPartitionReturn.iEPCItemReferenceDigits = 8;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 31;
                            cPartitionReturn.iEPCItemReferenceDigits = 9;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 34;
                            cPartitionReturn.iEPCItemReferenceDigits = 10;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 38;
                            cPartitionReturn.iEPCItemReferenceDigits = 11;
                            break;
                    }
                    break;
                case "gdti-96":
                    cPartitionReturn.sEPCScheme = "GDTI";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 1;
                            cPartitionReturn.iEPCItemReferenceDigits = 0;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 11;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                    }
                    break;
                case "gdti-113":
                    cPartitionReturn.sEPCScheme = "GDTI";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 1;
                            cPartitionReturn.iEPCItemReferenceDigits = 0;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 11;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                    }
                    break;
                case "gdti-174":
                    cPartitionReturn.sEPCScheme = "GDTI";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 1;
                            cPartitionReturn.iEPCItemReferenceDigits = 0;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 11;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                    }
                    break;
                case "gcn-96":
                    cPartitionReturn.sEPCScheme = "GCN";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 1;
                            cPartitionReturn.iEPCItemReferenceDigits = 0;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 4;
                            cPartitionReturn.iEPCItemReferenceDigits = 1;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 7;
                            cPartitionReturn.iEPCItemReferenceDigits = 2;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 11;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                    }
                    break;
                case "cpi-96":
                    cPartitionReturn.sEPCScheme = "CPI";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 11;
                            cPartitionReturn.iEPCItemReferenceDigits = 3;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 14;
                            cPartitionReturn.iEPCItemReferenceDigits = 4;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 17;
                            cPartitionReturn.iEPCItemReferenceDigits = 5;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 21;
                            cPartitionReturn.iEPCItemReferenceDigits = 6;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 24;
                            cPartitionReturn.iEPCItemReferenceDigits = 7;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 27;
                            cPartitionReturn.iEPCItemReferenceDigits = 8;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 31;
                            cPartitionReturn.iEPCItemReferenceDigits = 9;
                            break;
                    }
                    break;
                case "cpi-var":
                    cPartitionReturn.sEPCScheme = "CPI";
                    cPartitionReturn.sEPCBinaryPart = sEPCBinaryPartition;
                    switch (sEPCBinaryPartition)
                    {
                        case "000":
                            cPartitionReturn.iEPCDecimalPart = 0;
                            cPartitionReturn.iEPCCompanyPrefixBits = 40;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 12;
                            cPartitionReturn.iEPCItemReferenceBits = 114;
                            cPartitionReturn.iEPCItemReferenceDigits = 18;
                            break;
                        case "001":
                            cPartitionReturn.iEPCDecimalPart = 1;
                            cPartitionReturn.iEPCCompanyPrefixBits = 37;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 11;
                            cPartitionReturn.iEPCItemReferenceBits = 120;
                            cPartitionReturn.iEPCItemReferenceDigits = 19;
                            break;
                        case "010":
                            cPartitionReturn.iEPCDecimalPart = 2;
                            cPartitionReturn.iEPCCompanyPrefixBits = 34;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 10;
                            cPartitionReturn.iEPCItemReferenceBits = 126;
                            cPartitionReturn.iEPCItemReferenceDigits = 20;
                            break;
                        case "011":
                            cPartitionReturn.iEPCDecimalPart = 3;
                            cPartitionReturn.iEPCCompanyPrefixBits = 30;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 9;
                            cPartitionReturn.iEPCItemReferenceBits = 132;
                            cPartitionReturn.iEPCItemReferenceDigits = 21;
                            break;
                        case "100":
                            cPartitionReturn.iEPCDecimalPart = 4;
                            cPartitionReturn.iEPCCompanyPrefixBits = 27;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 8;
                            cPartitionReturn.iEPCItemReferenceBits = 138;
                            cPartitionReturn.iEPCItemReferenceDigits = 22;
                            break;
                        case "101":
                            cPartitionReturn.iEPCDecimalPart = 5;
                            cPartitionReturn.iEPCCompanyPrefixBits = 24;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 7;
                            cPartitionReturn.iEPCItemReferenceBits = 144;
                            cPartitionReturn.iEPCItemReferenceDigits = 23;
                            break;
                        case "110":
                            cPartitionReturn.iEPCDecimalPart = 6;
                            cPartitionReturn.iEPCCompanyPrefixBits = 20;
                            cPartitionReturn.iEPCCompanyPrefixDigits = 6;
                            cPartitionReturn.iEPCItemReferenceBits = 150;
                            cPartitionReturn.iEPCItemReferenceDigits = 24;
                            break;
                    }
                    break;


            }






            return cPartitionReturn;
        }
    }

}
