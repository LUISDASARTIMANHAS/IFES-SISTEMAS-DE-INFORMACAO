/*
	LISTA 2 - Exercício 10: dia da semana
*/

#include <stdio.h>

int main() {
	int dia;

	printf("\n\tInforme um número inteiro: ");
	scanf("%d", &dia);

	switch(dia){
		case 1:
			printf("\n\tVocê digitou o número correspondente ao Domingo.\n\n");
            break;
		case 2:
			printf("\n\tVocê digitou o número correspondente a Segunda-feira.\n\n");
            break;
		case 3:
			printf("\n\tVocê digitou o número correspondente a Terca-feira.\n\n");
            break;
		case 4:
			printf("\n\tVocê digitou o número correspondente a Quarta-feira.\n\n");
            break;
		case 5:
			printf("\n\tVocê digitou o número correspondente a Quinta-feira.\n\n");
            break;
		case 6:
			printf("\n\tVocê digitou o número correspondente a Sexta-feira.\n\n");
            break;
		case 7:
			printf("\n\tVocê digitou o número correspondente ao Sábado.\n\n");
            break;
		default:
			printf("\n\tVocê digitou um número que não corresponde a um dia da semana.\n\n");
            break;
	}

	return 0;
}
