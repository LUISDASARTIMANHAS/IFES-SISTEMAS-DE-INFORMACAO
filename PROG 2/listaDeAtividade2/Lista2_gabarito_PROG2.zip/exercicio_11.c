/*
	LISTA 2 - Exercício 11: nome do mês
*/


#include <stdio.h>

int main() {
	int mes;

	printf("\n\tInforme um número inteiro: ");
	scanf("%d", &mes);

	switch(mes){
		case 1:
			printf("\n\tVocê digitou o número correspondente ao mês de Janeiro.\n\n");
            break;
		case 2:
			printf("\n\tVocê digitou o número correspondente ao mês de Fevereiro.\n\n");
            break;
		case 3:
			printf("\n\tVocê digitou o número correspondente ao mês de Marco.\n\n");
            break;
		case 4:
			printf("\n\tVocê digitou o número correspondente ao mês de Abril.\n\n");
            break;
		case 5:
			printf("\n\tVocê digitou o número correspondente ao mês de Maio.\n\n");
            break;
		case 6:
			printf("\n\tVocê digitou o número correspondente ao mês de Junho.\n\n");
            break;
		case 7:
			printf("\n\tVocê digitou o número correspondente ao mês de Julho\n\n");
            break;
		case 8:
			printf("\n\tVocê digitou o número correspondente ao mês de Agosto\n\n");
            break;
		case 9:
			printf("\n\tVocê digitou o número correspondente ao mês de Setembro\n\n");
            break;
		case 10:
			printf("\n\tVocê digitou o número correspondente ao mês de Outubro\n\n");
            break;
		case 11:
			printf("\n\tVocê digitou o número correspondente ao mês de Novembro\n\n");
            break;
		case 12:
			printf("\n\tVocê digitou o número correspondente ao mês de Dezembro\n\n");
            break;
		default:
			printf("\n\tVocê digitou um número que não corresponde a um mês do ano.\n\n");
            break;
	}

	return 0;
}
