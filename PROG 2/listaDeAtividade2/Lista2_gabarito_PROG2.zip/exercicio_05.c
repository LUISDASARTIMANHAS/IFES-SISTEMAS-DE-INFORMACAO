/*
	LISTA 2 - Exercício 5: idade
*/

#include <stdio.h>

int main() {
	int idade;

	printf("\n\tInforme sua idade: ");
	scanf("%d", &idade);

	// verifica em qual categoria encaixa a idade da pessoa
	if ( idade <= 0 ) {
        printf("\n\tA idade digitada é inválida!\n\n");
	}
	else if ( idade < 18 ) {
		printf("\n\tVoce é menor de idade!\n\n");
	}
	else if ( idade < 65 ) {
        printf("\n\tVoce é maior de idade!\n\n");
	}
	else {
        printf("\n\tVoce é uma pessoa idosa!\n\n");
	}

	return 0;
}
