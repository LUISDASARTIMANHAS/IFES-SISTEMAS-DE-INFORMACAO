/*
	LISTA 2 - Exercício 13: valor a pagar de um produto
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
    int codigo, qtde;
	float preco, totalSem, totalDesc, desconto, porc;

	printf("\n\tInforme o código do produto: ");
	scanf("%d", &codigo);

	if ( codigo < 1 || codigo > 40) {
        printf("\n\n\tCódigo inválido!\n\n");
        exit(0);    // Para não continuar a execução
	}
	else if ( codigo <= 10 ) {
            preco = 10.00;
    }
    else if ( codigo <= 20) {
        preco = 15.00;
    }
    else if ( codigo <= 30) {
        preco = 20.00;
    }
    else {
        preco = 30.00;
    }

    printf("\n\tInforme a quantidade do produto: ");
    scanf("%d", &qtde);
    if ( qtde <= 0 ) {
        printf("\n\n\tQuantidade inválida!\n\n");
        exit(0);    // Para não continuar a execução
	}

    // Cálculo do total a pagar SEM o desconto
    totalSem = preco * qtde;

    if ( totalSem <= 250 ) {
        porc = 0.05;
    }
    else if ( totalSem <= 500 ) {
        porc = 0.10;
    }
    else {
        porc = 0.15;
    }

    // Cálculo do total a pagar COM o desconto
    desconto = totalSem * porc;
    totalDesc = totalSem - desconto;

    // Impressão dos resultados
    printf ("\n\n\tPreço do produto:   \tR$ %.2f", preco);
    printf ("\n\n\tTotal sem desconto: \tR$ %.2f", totalSem);
    printf ("\n\n\tDesconto:          \t-R$ %.2f", desconto);
    printf ("\n\n\t              \t---------------------");
    printf ("\n\n\tTotal a pagar:      \tR$ %.2f\n\n", totalDesc);

    return 0;
}
