/*
	LISTA 2 - Exercício 9: Raízes de uma equação
*/

#include <stdio.h>
#include <math.h>

int main() {
	float a, b, c, delta, x1, x2;

	printf("\n\tInforme o valor do coeficiente A: ");
	scanf("%f", &a);

	if ( a == 0 ) {
        printf("\n\tIsso nao é uma equação de segundo grau!\n\n");
	}
    else {
        printf("\n\tInforme o valor do coeficiente B: ");
        scanf("%f", &b);

        printf("\n\tInforme o valor do coeficiente C: ");
        scanf("%f", &c);

        // Calcular o delta
        delta = pow(b,2) - 4 * a * c;

        if ( delta < 0 ) {
            printf("\n\tEssa equação não possui raízes!");
        }
        else {
            x1 = ( -1 * b + sqrt(delta) ) / (2 * a) ;
            x2 = ( -1 * b - sqrt(delta) ) / (2 * a) ;
            printf("\n\tX1 = %.3f \tX2 = %.3f\n", x1, x2);
        }

        if ( a > 0) {
            printf("\n\tConcavidade voltada para cima\n\n");
        } else {
            printf("\n\tConcavidade voltada para baixo\n\n");
        }
    }

    return 0;
}
