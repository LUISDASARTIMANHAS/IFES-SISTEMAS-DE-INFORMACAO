/*
	LISTA 2 - Exercício 2: raiz quadrada ou quadrado de um número
*/

#include <stdio.h>
#include <math.h>

int main(){
	float num;

	printf("\n\tInforme um número: ");
	scanf("%f", &num);

	// verifica o valor de num e apresenta a mensagem relacionada
	if (num >= 0) {
		printf("\n\t%0.1f é positivo ou igual a zero, então sua raiz quadrada é %0.1f\n\n", num, sqrt(num));
	}
	else {
		printf("\n\t%0.1f é negativo, entao o seu quadrado é %0.1f\n\n", num, pow(num,2));
	}

	return 0;
}
