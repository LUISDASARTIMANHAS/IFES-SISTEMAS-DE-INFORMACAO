/*
	LISTA 2 - Exercício 3: ordem decrescente
*/

#include <stdio.h>

int main(){
	int A, B, C;
	int maior, meio, menor;

	printf("\n\tInforme o valor de A: ");
	scanf("%d", &A);
	printf("\n\tInforme o valor de B: ");
	scanf("%d", &B);
	printf("\n\tInforme o valor de C: ");
	scanf("%d", &C);

	// verifica se A é o maior
	if ( (A >= B) && (A >= C) ) {
		maior = A;
		// verifica quem é o do meio e o menor
		if (B >= C) {
			meio = B;
			menor = C;
		}
		else {
			meio = C;
			menor = B;
		}
	}
	// verifica se B é o maior, pois já sei que o A não é o MAIOR
	else if ( B >= C ) {
		maior = B;
		// verifica quem é o do meio e o menor
		if (A >= C) {
			meio = A;
			menor = C;
		}
		else {
			meio = C;
			menor = A;
		}
	}
	else {
		maior = C;
		// verifica quem é o do meio e o menor
		if (A >= B) {
			meio = A;
			menor = B;
		}
		else {
			meio = B;
			menor = A;
		}
	}
	printf("\n\tOs valores em ordem descendente: %d %d %d\n\n", maior, meio, menor);

	return 0;	
}