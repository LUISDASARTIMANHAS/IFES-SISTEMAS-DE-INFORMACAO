/*
	LISTA 2 - Exercício 12: competição de ginástica
*/


#include <stdio.h>

int main() {
	float n1, n2, n3, n4, n5, maior, menor, media;

	// Inicializaçãoo das variáveis
	maior = -9999;  // muito pequeno
	menor = 9999;   // muito grande
	media = 0;

	// Leitura das notas.
	// Por enquanto não estou preocupado com a validação das notas.
	// Sem usar WHILE, porque ainda não vimos.

	// NOTA 1
	printf("\n\tInforme a nota 1: ");
	scanf("%f", &n1);
    if ( n1 > maior) {
        maior = n1;
    }
    if ( n1 < menor ) {
        menor = n1;
    }

    // NOTA 2
    printf("\n\tInforme a nota 2: ");
	scanf("%f", &n2);
    if ( n2 > maior) {
        maior = n2;
    }
    if ( n2 < menor ) {
        menor = n2;
    }

    // NOTA 3
    printf("\n\tInforme a nota 3: ");
	scanf("%f", &n3);
    if ( n3 > maior) {
        maior = n3;
    }
    if ( n3 < menor ) {
        menor = n3;
    }

    // NOTA 4
    printf("\n\tInforme a nota 4: ");
	scanf("%f", &n4);
    if ( n4 > maior) {
        maior = n4;
    }
    if ( n4 < menor ) {
        menor = n4;
    }

    // NOTA 5
    printf("\n\tInforme a nota 5: ");
	scanf("%f", &n5);
    if ( n5 > maior) {
        maior = n5;
    }
    if ( n5 < menor ) {
        menor = n5;
    }

    // Cálculo da média, retirando o maior e o menor
    media = ( n1 + n2 + n3 + n4 + n5 - maior - menor ) / 3;

    printf ("\n\n\tA média das notas é: %.2f", media);
    printf ("\n\n\tA maior nota é: %.2f", maior);
    printf ("\n\n\tA menor nota é: %.2f\n\n", menor);

    return 0;
}
