/*
	LISTA 2 - Exercício 7: média final
*/

#include <stdio.h>

int main() {
	float n1, n2, n3, media;

	printf("\n\tInforme a 1a nota semestral: ");
	scanf("%f", &n1);

	printf("\n\tInforme a 2a nota semestral: ");
	scanf("%f", &n2);

    printf("\n\tInforme a 3a nota semestral: ");
	scanf("%f", &n3);
	
	// calcula a média bimestral
	media = (n1 + n2 + n3)/3;

	// verifica a situação do aluno
	if ( media < 0 || media > 10) {
        printf("\n\tMédia inválida ");
	}
	else if ( media < 3 ) {
        printf("\n\tVocê foi REPROVADO ");
	}
	else if ( media < 7 ) {
		printf("\n\tVocê deve fazer a PROVA FINAL ");
	}
	else {
	    printf("\n\tVocê foi APROVADO ");
	}

	printf("pois sua média é %0.1f!\n\n", media);
	return 0;
}
