/*
	LISTA 2 - Exercício 1: soma de valores
*/

#include <stdio.h>

int main(){
	int A, B, S;

	printf("\n\tInforme um valor inteiro: ");
	scanf("%d", &A);
	printf("\n\tInforme outro valor inteiro: ");
	scanf("%d", &B);

	// efetua a soma
	S = A + B;

	// checa o resultado da soma
	if (S > 20) {
		printf("\n\t%d é maior que 20, então ele passa a valer %d\n\n", S, S+8);
	}
	else {
		printf("\n\t%d é menor ou igual a 20, então ele passa a valer %d\n\n", S, S-5);
	}

	return 0;
}
