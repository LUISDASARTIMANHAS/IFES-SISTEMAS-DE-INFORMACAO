/*
	LISTA 2 - Exercício 8: f(x)
*/

#include <stdio.h>
#include <math.h>

int main() {
	float x;

	printf("\n\tInforme o valor de X: ");
	scanf("%f", &x);

	if (x <= 1){
		printf("\n\tf(x) = 1 pois X é menor ou igual a 1\n\n");
	}
	else if (x <= 2) {
		printf("\n\tf(x) =  2 pois X é maior que 1 e menor ou igual a 2\n\n");
	}
	else if (x <= 3) {
		printf("\n\tf(x) =  %0.1f pois X é maior que 2 e menor ou igual a 3\n\n", pow(x,2));
	}
	else {
		printf("\n\tf(x) =  %0.1f pois X é maior que 3\n\n", pow(x,3));
    }

	return 0;
}
