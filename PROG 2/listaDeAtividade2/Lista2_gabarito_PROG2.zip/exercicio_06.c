/*
	LISTA 2 - Exercício 6: eleitor
*/

#include <stdio.h>

int main() { 
	int idade;

	printf("\n\tInforme a sua idade: ");
	scanf("%d", &idade);

	//verifica qual a classe eleitoral do usuário
	if ( idade <= 0 ) {
        printf("\n\tA idade informada é inválida!\n\n");
    }
    else if ( idade < 16 ) {
		printf("\n\tVocê não é eleitor!\n\n");
	}
    else if ( idade < 18 ) {
        printf("\n\tVocê é um eleitor facultativo!\n\n");
	}
	else if ( idade < 65 ) {
		printf("\n\tVocê é um eleitor obrigatório!\n\n");
	}
	else {
	    printf("\n\tVocê é um eleitor facultativo!\n\n");
	}

	return 0;
}
