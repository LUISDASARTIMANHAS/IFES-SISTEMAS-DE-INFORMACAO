/*
	LISTA 2 - Exercício 4: divisível por 10, 5 ou 2
*/

#include <stdio.h>

int main() {
	int x;

	printf("\n\tInforme um valor inteiro: ");
	scanf("%d", &x);

	if ( (x % 2) == 0 ) {
		printf("\n\t%d é divisível por 2", x);
		// se é divisível por 2 e por 5, será também por 10
		if ( (x % 5) == 0) {
			printf(", por 5 ou por 10");
		}

		printf("\n\n");
	}
	else if ( (x % 5) == 0) {
		printf("\n\t%d é divisível por 5\n\n", x);
	}
	else {
		printf("\n\t%d não é divisível por 2, 5 ou 10\n\n", x);
	}

	return 0;
}
