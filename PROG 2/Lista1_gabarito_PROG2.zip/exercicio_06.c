/*
	LISTA 1 - Exercício 6: converter temperatura de Fahrenheit para Celsius
*/

#include<stdio.h>

int main(){
	float C, F;

	printf("\n\tInforme a temperatura em graus Fahrenheit: ");
	scanf("%f", &F);

	// Faz a conversão para Celsius
	C = (5*F - 160) / 9;

	printf("\n\t%0.1f graus Fahrenheit corresponde a %0.1f graus Celsius\n\n", F, C);

	return 0;
}
