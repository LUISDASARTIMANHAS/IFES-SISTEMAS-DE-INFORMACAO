/*
	LISTA 1 - Exercício 8: salário mínimo
*/

#include<stdio.h>

int main(){
	float valor_SM, valor_SP;
	float qtde_S;

	printf("\n\tInforme o valor do salario mínimo: ");
	scanf("%f", &valor_SM);

	printf("\n\tInforme o valor de seu salário: ");
	scanf("%f", &valor_SP);

	// Calcula a quantidade de salários que a pessoa ganha
	qtde_S = valor_SP / valor_SM;

	printf("\n\tVocê ganha %0.1f salários mínimos\n\n", qtde_S);

	return 0;
}