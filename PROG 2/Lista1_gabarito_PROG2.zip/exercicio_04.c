/*
	LISTA 1 - Exercício 4: valor com desconto, lendo o desconto
*/

#include <stdio.h>

int main(){
	float valor_produto, novo_valor, desconto, porc;
	
	printf("\n\tInforme o valor do produto: ");
	scanf("%f", &valor_produto);

	printf("\n\tInforme o desconto em %%: ");
	scanf("%f", &porc);

	desconto = (valor_produto * (porc/100) );
	novo_valor = valor_produto - desconto;

	printf("\n\tValor antigo = %10.2f", valor_produto);
	printf("\n\tDesconto em R$ = %8.2f", desconto);
	printf("\n\t                ----------");
	printf("\n\tValor com desconto = %0.2f\n\n", novo_valor);

	return 0;
}
