/*
	LISTA 1 - Exercício 2: Progressão geométrica
*/

#include <stdio.h>
#include <math.h>

int main(){
	float a1, an, q, n;

	printf("\n\tInforme o 1o termo: ");
	scanf("%f", &a1);

	printf("\n\tInforme o número de termos: ");
	scanf("%f", &n);

	printf("\n\tInforme a razão da P.G.: ");
	scanf("%f", &q);

	// Encontra o an, com auxílio da função pow()
	an = a1 * pow(q, (n-1));

	printf("\n\tO valor de an é %0.1f\n\n", an);

	return 0;
}