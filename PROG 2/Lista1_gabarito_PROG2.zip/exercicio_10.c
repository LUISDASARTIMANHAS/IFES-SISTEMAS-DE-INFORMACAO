/*
	LISTA 1 - Exercício 10: vida de um fumante
*/
#include<stdio.h>

int main(){
	int qtdeCigarros, anos, dias;
	float tempoPerdido;

	printf("\n\tInforme quantos cigarros fuma por dia: ");
	scanf("%d", &qtdeCigarros);

	printf("\n\tInforme quantos anos que fuma: ");
	scanf("%d", &anos);

	// Converter anos em dias. Considerando o ano INTEIRO
	dias = 365 * anos;

	// Calcula quantos minutos foram perdidos
	tempoPerdido = qtdeCigarros * dias * 10;  // em minutos

	// Converter minutos em dias
	tempoPerdido = tempoPerdido / 60 / 24;

	printf("\n\tForam perdido: %0.1f dias\n\n", tempoPerdido);

	return 0;
}
