/*
	LISTA 1 - Exercício 5: converter temperatura de Celsius para Fahrenheit
*/

#include <stdio.h>

int main(){
	float C, F;

	printf("\n\tInforme a temperatura em graus Celsius: ");
	scanf("%f", &C);

	// Faz a conversão para Fahrenheit
	F = (9 * C + 160) / 5;

	printf("\n\t%0.1f graus Celsius corresponde a %0.1f graus Fahrenheit\n\n", C, F);

	return 0;
}
