/*
	LISTA 1 - Exercício 1: Progressão aritmética
*/

#include <stdio.h>

int main(){
	int an, a1, n, r;

	printf("\n\tInforme o 1º termo: ");
	scanf("%d", &a1);

	printf("\n\tInforme o número de termos: ");
	scanf("%d", &n);

	printf("\n\tInforme a razão da P.A.: ");
	scanf("%d", &r);

	// Efetua o cálculo
	an = a1 + (n - 1) * r;

	printf("\n\tO valor de an é %d\n\n", an);

	return 0;
}