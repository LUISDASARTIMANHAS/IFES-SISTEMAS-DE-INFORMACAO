/*
	LISTA 1 - Exercício 7: troca de variáveis
*/

#include <stdio.h>

int main(){
	int A, B, aux;

	printf("\n\tInforme o valor de A: ");
	scanf("%d", &A);

	printf("\n\tInforme o valor de B: ");
	scanf("%d", &B);

	// mostra os valores antes da troca
	printf("\n\t====== Antes ======");
	printf("\n\t A = %d\t  B = %d\n", A, B);

	// efetua a troca com a vari�vel auxiliar
	aux = A;
	A = B;
	B = aux;

	// mostra os valores depois da troca
	printf("\n\t====== Depois ======");
	printf("\n\t A = %d\t  B = %d\n\n", A, B);

	return 0;
}