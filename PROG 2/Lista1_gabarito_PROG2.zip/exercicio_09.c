/*
	LISTA 1 - Exercício 9: aluguel de carro
*/

#include<stdio.h>

int main(){
	float km, valor, diaria, precoKm;
	int dias;

	diaria = 60;
	precoKm = 0.15;

	printf("\n\tInforme quantos KM foram percorridos: ");
	scanf("%f", &km);

	printf("\n\tInforme quantos dia está com o carro: ");
	scanf("%d", &dias);

	// Calcula o valor a pagar, sem considerar dia quebrado
	valor = dias * diaria + precoKm * km;

	printf("\n\tO valor a pagar: R$ %0.2f \n\n", valor);

	return 0;
}
