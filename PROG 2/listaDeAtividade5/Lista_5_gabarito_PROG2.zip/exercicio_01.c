#include <stdio.h>
#define TAM 100

void lerDados(int * pvet, int tot) {
	int i, num;
	num = tot;
	for(i=0; i < tot; i++) {
		pvet[i] = num;
		num--;
	}	
}


void imprimir (int * pvet, int tot) {
	int i;
	for(i=0; i < tot; i++) {
		printf("%d\t", pvet[i] );
	}

}


int main() {
	
	int vet[TAM];
	int total;
	
	total = 100;
	lerDados(vet, total);	
	imprimir(vet,total);
	
	return 0;
}
