#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define TAM 100

int aleatorio() {
    return ( rand() % 1000) + 1;
}


int pesquisar(int *pvet, int tot, int pesq ) {
	int i;
	for(i=0; i < tot; i++) {
		if ( pvet[i] == pesq ) {
			return i;
		} 
	}
    return -1;

}


void lerDados(int * pvet, int tot) {
	int i = 0;
    int num;
	while ( i < tot ) {
		num = aleatorio();
        if ( pesquisar(pvet, tot, num) == -1 ) {   // NÃO ACHOU
            pvet[i] = num;
            i++;
        }
	}
}


void imprimir (int * pvet, int tot) {
	int i;
	for(i=0; i < tot; i++) {
		printf("%d\t", pvet[i] );
	}

}


int main() {

	int vet[TAM];
	int total = 100;

	// SEMENTE DOS NUMEROS ALEATÓRIOS. Usa a hora local
    srand( (unsigned) time(NULL) );

	lerDados(vet,total);	
	imprimir(vet,total);

	return 0;
}
