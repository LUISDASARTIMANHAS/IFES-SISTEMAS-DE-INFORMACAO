#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define TAM 20

int aleatorio() {
    return ( rand() % 100) + 1;
}

void lerDados(int * pvet, int tot) {
	int i;
	for(i=0; i < tot; i++) {
		pvet[i] = aleatorio();
	}
}

void separar(int *pvet, int tot, int *pvetPar, int *totPar, int *pvetImpar, int *totImpar ) {
	int i;
	for(i=0; i < tot; i++) {
		if (pvet[i]%2 == 0){
			pvetPar[*totPar] = pvet[i];
			(*totPar)++;
		} else {
			pvetImpar[*totImpar] = pvet[i];
			(*totImpar)++;
		}
	}

}

void imprimir (int * pvet, int tot) {
	int i;
	for(i=0; i < tot; i++) {
		printf("%d\t", pvet[i] );
	}

}


int main() {

	int vet[TAM], vetPar[TAM], vetImpar[TAM];
	int total, totPar, totImpar;

	total = 20;
	totPar = 0;
	totImpar = 0;

	// SEMENTE DOS NUMEROS ALEAT�RIOS. Usa a hora local
    srand( (unsigned)time(NULL) );

	lerDados(vet, total);

	separar(vet, total, vetPar, &totPar, vetImpar, &totImpar);

	printf("\n\nVETOR ORIGINAL: \n");
	imprimir(vet,total);

	printf("\n\nVETOR PARES: \n");
	imprimir(vetPar,totPar);

    printf("\n\nVETOR IMPARES: \n");
	imprimir(vetImpar,totImpar);

	return 0;
}
