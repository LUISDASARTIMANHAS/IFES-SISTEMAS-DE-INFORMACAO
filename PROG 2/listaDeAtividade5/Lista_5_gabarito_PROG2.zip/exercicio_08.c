#include <stdio.h>
#define TAM 10

void showsDisponiveis(int * vendas, int * maxShow, int qtde) {
	int i;
	printf("\n\n\t| SHOW\t| INGRESSOS DISPONIVEIS |\n");
    for (i = 0; i < qtde; i++){
    	if ( vendas[i] < maxShow[i] ) {
	    	printf("\t| %2d\t| %10d\t\t|\n", i+1, maxShow[i] - vendas[i]) ;
	    }
    }
	
}

int lerNumShow(int totalShow) {
    int num;
    do {
        printf("\n\tInforme o código do show (1 a %d): ", totalShow);	
        scanf("%d", &num);				
    } while ( num <= 0 || num > totalShow);
    
    return num-1;
}


int lerQtde() {
    int qtde;
    do {
        printf("\n\tInforme a quantidade de ingressos: ");	
        scanf("%d", &qtde);				
    } while ( qtde <= 0 );
    
    return qtde;
}


void realizarVenda(int * vendas, int * maxShow, int totalShow) {
	int num, qtde, disp;
	do {
        num = lerNumShow(totalShow);
        qtde = lerQtde();
				
		if ( vendas[num] + qtde <= maxShow[num] ) {
			vendas[num] = vendas[num] + qtde;
			disp = maxShow[num] - vendas[num];
		} else {
			printf("\n\n\tQtde de ingressos acima do limite.\n");
			disp = -1;
		}
		
	} while ( disp == -1);
	
}

void imprimir( int * vendas, int qtde) {
    int i;
	printf("\n\n\t| SHOW\t|  INGRESSOS VENDIDOS   |\n");
    for (i = 0; i < qtde; i++) {
    	if ( vendas[i] > 0 ) {	
        	printf("\t| %2d\t| %10d\t\t|\n", i+1, vendas[i]) ;
        }
    }
}

int main() {
    int maxShow[TAM] = {100,110,120,120,130,130,140,140,150,150};
    int vendas[TAM] = {0,0,0,0,0,0,0,0,0,0};
    int op, tamanho=TAM;

    do {
        printf("\n\t1 - Vender ingresso");
        printf("\n\t2 - Listar vendidos");
        printf("\n\t0 - Sair");
        printf("\n\tSua opção: ");
        scanf("%d", &op);
        switch (op){
            case 0 : break;
            case 1 : showsDisponiveis(vendas, maxShow, tamanho);
                     realizarVenda(vendas, maxShow, tamanho);
                     break;

            case 2 : imprimir(vendas,tamanho);
                     break;

            default: printf("\n\n\tOpção inválida!\n");
        }
    } while ( op != 0 );

    return 0;
}
