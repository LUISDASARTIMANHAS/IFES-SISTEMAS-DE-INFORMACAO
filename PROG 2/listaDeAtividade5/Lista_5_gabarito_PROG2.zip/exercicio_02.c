#include <stdio.h>
#define TAM 200

void lerDados(int * pvet, int tot) {
	int i;
	for(i=0; i < tot; i++) {
		pvet[i] = i + 100;
	}	
}


void imprimir (int * pvet, int tot) {
	int i;
	for(i=0; i < tot; i++) {
		if ( pvet[i] % 5 == 0 ){
			printf("%d\t", pvet[i] );
		}
	}

}


int main() {
	
	int vet[TAM];
	int total;
	
	total = 101;	// De 100 a 200 eu tenho 101 números
	lerDados(vet,total);	
	imprimir(vet,total);
	
	return 0;
}
