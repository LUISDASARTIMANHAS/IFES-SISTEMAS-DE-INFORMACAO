#include <stdio.h>
#include <math.h>

#define TAM 20

void lerDados(int * pvet, int tot) {
	int i;
	for(i=0; i < tot; i++) {
		if ( i%2 == 0) {
			pvet[i] = pow(i+1,2);
		} else {
			pvet[i] = pow(i+1,3);
		}
	}	
}


void imprimir (int * pvet, int tot) {
	int i;
	for(i=0; i < tot; i++) {
		printf("%d\t", pvet[i] );
	}

}


int main() {
	
	int vet[TAM];
	int total;
	
	total = 20;
	lerDados(vet,total);	
	imprimir(vet,total);

	return 0;
	
}
