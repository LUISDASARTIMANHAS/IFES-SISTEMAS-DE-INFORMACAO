#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

float lerAltura(int p){
    float alt;
    do {
        printf("Informe a altura do %dº atleta: ", p+1);
        scanf("%f", &alt);
    } while ( alt <= 0.0 || alt > 2.5);
    return alt;
}

// Como vou realocar a memória do vetor dentro da função,
// preciso passar o vetor por referência
void lerVetDados(float * *pvet, int *tot, int *max) {
	char cont;
	do {

		// Verifico se atingiu o máximo
		// Se sim, então realoco mais memória

		if ( *tot == *max) {
			(*max) = (*max) * 2;
			*pvet = (float *) realloc (*pvet, (*max) * sizeof(float));
			printf("\n\nREALOCOU\n\n");
		}

		(*pvet)[*tot] = lerAltura(*tot);
		(*tot)++;
		printf("\nDESEJA CONTINUAR? ");
		scanf(" %c", &cont);
	} while ( toupper(cont) =='S');

}


void imprimirAcima (float * pvet, int tot, float media) {
	int i;
	for(i=0; i < tot; i++) {
        if ( pvet[i] >= media ) {
            printf("%2dº: %.1f\n", i+1, pvet[i] );
        }
	}
}


float calcMedia (float * pvet, int tot) {
	int i;
	float media = 0;

	for(i=0; i < tot; i++) {
		media = media + pvet[i];
	}
	return media/tot;
}


// Retorna a POSIÇÃO onde está a MAIOR altura
int maiorAltura(float * pvet, int tot){
    int i, pos;
    pos = 0;    // Considero a primeira posicao como a MAIOR
                //    por isso que o FOR comeca de 1.
    for(i=1; i < tot; i++) {
		if ( pvet[i] > pvet[pos]) {
            pos = i;
		}
	}
	return pos;
}


// Retorna a POSIÇÃO onde está a MENOR altura
int menorAltura(float * pvet, int tot){
    int i, pos;
    pos = 0;    // Considero a primeira posicao como a MENOR
                //    por isso que o FOR comeca de 1.
    for(i=1; i < tot; i++) {
		if ( pvet[i] < pvet[pos]) {
            pos = i;
		}
	}
	return pos;

}

int main() {

	float * vet, media;
	int total, posMaior, posMenor;
	int maximo = 3;

	total = 0;
	vet = (float *) malloc( maximo * sizeof(float) );

	lerVetDados(&vet, &total, &maximo);

	posMaior = maiorAltura(vet,total);
	posMenor = menorAltura(vet,total);
	media = calcMedia(vet,total);

	printf("MAIOR altura: %dº: %.1f\n", posMaior+1, vet[posMaior]);
	printf("MENOR altura: %dº: %.1f\n", posMenor+1, vet[posMenor]);
	printf("MÉDIA das alturas: %.2f\n", media);

	printf("\n\nACIMA da MÉDIA: \n");
	imprimirAcima(vet,total,media);

	return 0;
}
