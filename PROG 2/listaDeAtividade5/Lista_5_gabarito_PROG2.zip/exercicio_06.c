#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define TAM 100

int aleatorio() {
    return ( rand() % 100) + 1;
}


int pesquisar(int *pvet, int tot, int pesq ) {
	int i;
	for(i=0; i < tot; i++) {
		if ( pvet[i] == pesq ) {
			return i;
		} 
	}
    return -1;

}


void lerDados(int * pvet, int tot) {
	int i = 0;
    int num;
	while ( i < tot ) {
		num = aleatorio();
        if ( pesquisar(pvet, tot, num) == -1 ) {   // NÃO ACHOU
            pvet[i] = num;
            i++;
        }
	}
}


void remover (int *vetor, int *qtde, int pos) {
	int i;
	for (i = pos; i < *qtde- 1; i++) {
		vetor[i] = vetor[i+1];
	}
	(*qtde)--;
}


void imprimir (int * pvet, int tot) {
	int i;
	for(i=0; i < tot; i++) {
		printf("%d\t", pvet[i] );
	}

}


void retirar (int * pvet1, int tot1, int * pvet2, int *tot2) {
	int vRet[TAM];	// Para guardar os retirados
	int totR = 0;
	int i, pos;

	for ( i=0; i < *tot2; i++) {
		pos = pesquisar(pvet1, tot1, pvet2[i] ); 
		if ( pos >= 0  ) {  // ACHOU
			vRet[totR] = pvet2[i];
			totR++;
			remover(pvet2, tot2, i);
		}
	}
	printf("\n\nRETIRADOS: ");
	imprimir(vRet, totR);
	printf("\n");

}


int main() {

	int vet1[TAM], vet2[TAM];
	int total1 = 10;
	int total2 = 10;

	// SEMENTE DOS NUMEROS ALEATÓRIOS. Usa a hora local
    srand( (unsigned) time(NULL) );

	lerDados(vet1,total1);	
	lerDados(vet2,total2);	

	printf("\nANTES: \n");
	
	printf("\tVETOR 1: \n\t");
	imprimir(vet1,total1);

	printf("\n\tVETOR 2: \n\t");
	imprimir(vet2,total2);


	retirar(vet1, total1, vet2, &total2);


	printf("\n\nDEPOIS: \n");
	
	printf("\tVETOR 1: \n\t");
	imprimir(vet1,total1);

	printf("\n\tVETOR 2: \n\t");
	imprimir(vet2,total2);

	return 0;
}
