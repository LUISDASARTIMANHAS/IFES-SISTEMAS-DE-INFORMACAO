#define MAX 100

struct Lanche {
    char nomeLanche[MAX];
    char ingredientes[20][MAX];    // Teremos no máximo 20 ingredientes. Cada um com no máximo MAX caracteres
    float preco;
};
typedef struct Lanche Lanche;


struct Cliente {
    char nomeCliente[MAX];
    char telefone[20];
};
typedef struct Cliente Cliente;


struct Data {
    int dia;
    int mes;
    int ano;
};
typedef struct Data Data;


struct Pedido {
    Cliente cliente;
    Data dtPedido;
    float total;
    Lanche lanches[20];     // Teremos no máximo 20 lanches por pedido
};
typedef struct Pedido Pedido;
