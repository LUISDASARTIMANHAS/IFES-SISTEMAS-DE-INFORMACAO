#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE * abrirArquivo(char * nomeArq, char * modo) {
    // ABRIR o arquivo
    FILE * arq;
    arq = fopen( nomeArq, modo );
    if ( arq == NULL) {
        printf("ERRO ao abrir o arquivo.");
        exit(-1);
    }
    return arq;
}

void lerProducao(FILE * arqProducao, int * prodM1, int * prodM2) {
    int i = 0;
    int quant;
    while ( !feof(arqProducao) ) {
        fscanf(arqProducao, "%d", &quant);
        prodM1[i] = quant;

        fscanf(arqProducao, "%d", &quant);
        prodM2[i] = quant;
        i++;
    }

}

void lerVendas(FILE * arqVendas, float * custo, float * lucro) {
    fscanf(arqVendas, "%f", custo);
    fscanf(arqVendas, "%f", lucro);
}


void calcularTotal(FILE * arqFinal, int * prodM1, int * prodM2, float custoM1, float lucroM1, float custoM2, float lucroM2 ) {
    int i;
    float custoTotal = 0;
    float lucroTotal = 0;
    // Percorre os 12 meses
    for (i = 0; i < 12; i++) {
        custoTotal = prodM1[i] * custoM1 + prodM2[i] * custoM2;
        fprintf(arqFinal, "%.2f ", custoTotal );
        
        lucroTotal = prodM1[i] * lucroM1 + prodM2[i] * lucroM2;
        fprintf(arqFinal, "%.2f\n", lucroTotal );
    }

}

int main () {
    FILE * arqProducao; 
    FILE * arqVendas; 
    FILE * arqFinal; 
    
    int prodM1[12];  // Vetor para armazenar a produção do MOTOR M1, por mês
    int prodM2[12];  // Vetor para armazenar a produção do MOTOR M1, por mês
    float custoM1, custoM2, lucroM1, lucroM2;
        
    arqProducao = abrirArquivo("ex2_producao.txt", "r");
    arqVendas = abrirArquivo("ex2_vendas.txt", "r");
    arqFinal = abrirArquivo("ex2_output.txt", "w");

    lerProducao(arqProducao, prodM1, prodM2);

    lerVendas(arqVendas, &custoM1, &lucroM1);
    lerVendas(arqVendas, &custoM2, &lucroM2);

    calcularTotal(arqFinal, prodM1, prodM2, custoM1, lucroM1, custoM2, lucroM2 );
    
    fclose(arqProducao);
    fclose(arqVendas);
    fclose(arqFinal);
    return 0;
}