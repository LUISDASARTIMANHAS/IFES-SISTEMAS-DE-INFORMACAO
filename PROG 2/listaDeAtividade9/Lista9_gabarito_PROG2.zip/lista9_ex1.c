#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE * abrirArquivo(char * nomeArq, char * modo) {
    // ABRIR o arquivo
    FILE * arq;
    arq = fopen( nomeArq, modo );
    if ( arq == NULL) {
        printf("ERRO ao abrir o arquivo.");
        exit(-1);
    }
    return arq;
}

int pesquisar (char vetor[][50], int quant , char * pesq) {
    int i;
    for (i = 0; i < quant; i++) {
        if ( strcmp (vetor[i], pesq) == 0 ) {
            return i;
        }
    }
    return -1;
}

void imprimirCensura(FILE * arqOut, char * palavra) {
    int tam = strlen(palavra);
    int i;
    fprintf(arqOut, " ");   // para separar as palavras
    for (i = 0; i < tam; i++) {
        fprintf(arqOut, "*");
    }

}

int censurarArquivo(FILE * arqIn, FILE * arqOut, char palavrasProibidas[][50]) {
    int cont = 0;
    char palavra[51];

    while ( !feof(arqIn) ) {
        fscanf(arqIn, "%s", palavra);

        if ( pesquisar(palavrasProibidas, 11, palavra) >= 0 ) {
            // Achou no vetor
            imprimirCensura(arqOut, palavra);
            cont++;
        } else {
            // Não achou. Não é uma palavra proibida
            fprintf(arqOut, " %s", palavra);
        }        
    }
    return cont;
} 

int main () {
    FILE * arqIn; 
    FILE * arqOut; 
    int total;
    char palavrasProibidas[100][50] = {"sexo", "erótico", "golpe", "ladrão", "rapariga", 
                                        "Rebelião", "Darth", "Vader", "Skywalker", "Jedi", "Flamengo"};
    
    arqIn = abrirArquivo("ex1_input.txt", "r");
    arqOut = abrirArquivo("ex1_output.txt", "w");

    total = censurarArquivo(arqIn, arqOut, palavrasProibidas);
    printf("\n\n\tForam censuradas %d palavras.\n\n", total);

    fclose(arqIn);
    fclose(arqOut);
    return 0;
}
