#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

#define MAX 500

FILE * abrirArquivo(char * nomeArq, char * modo) {
    // ABRIR o arquivo
    FILE * arq;
    arq = fopen( nomeArq, modo );
    if ( arq == NULL) {
        printf("ERRO ao abrir o arquivo.");
        exit(-1);
    }
    return arq;
}

void insereNoVetor(int mat, char * projeto, int * leds, int * tamLeds, int * leter, int * tamLeter, int * robotica, int * tamRobo) {
    if ( strcmp(projeto, "LEDS") == 0 ){
        leds[*tamLeds] = mat;
        (*tamLeds)++;
    } else if ( strcmp(projeto, "LETER") == 0 ){
        leter[*tamLeter] = mat;
        (*tamLeter)++;
        
    } else if ( strcmp(projeto, "Robótica") == 0 ){
        robotica[*tamRobo] = mat;
        (*tamRobo)++;        
    }    
}


void lerProjetos(FILE * arqAlunos, int mat, int * leds, int * tamLeds, int * leter, int * tamLeter, int * robotica, int * tamRobo) {
    char projeto[50];
    char linha[100];
    int i, p = 0;
    
    // Lê toda uma linha até encontrar o \n
    fgets(linha, 100, arqAlunos);

    // Separar cada palavra
    projeto[0] = '\0';
    for (i = 0; linha[i] != '\0'; i++) {
        
        // Pular os espaços em branco
        while ( linha[i] == ' ') {
            i++;
        }

        if ( ( linha[i] == '\n') || (linha[i] == '\0')  ) {
            break;
        } else {
            // É uma palavra. Copia até achar outro ' ' ou '\0' ou '\n'
            do {
                projeto[p] = linha[i];
                p++;
                i++;
            } while ( ( linha[i] != ' ') && ( linha[i] != '\n') && ( linha[i] != '\0') ) ;
            projeto[p] = '\0';

            insereNoVetor(mat, projeto, leds, tamLeds, leter, tamLeter, robotica, tamRobo);

            // ZERA para a proxima palavra
            p = 0;   
            projeto[0] = '\0';

        }
    }    

}

void carregarVetores(FILE * arqAlunos, int * leds, int * tamLeds, int * leter, int * tamLeter, int * robotica, int * tamRobo) {
    int matricula;
    while (!feof(arqAlunos) ) {
        fscanf(arqAlunos, "%d", &matricula);
        lerProjetos(arqAlunos, matricula, leds, tamLeds, leter, tamLeter, robotica, tamRobo);
    }

}

void listar(int vetor[], int qtde) {
    int i;

    for( i = 0; i < qtde; i++) {
        printf("%d   ", vetor[i] );
    }
    printf("\n\n\n");
}


void gravarVetorNoArquivo(char * nomeArq, int * vetor, int tam) {
    FILE * arq;
    int i;
    arq = abrirArquivo(nomeArq, "w");
    for (i = 0; i < tam; i++) {
        fprintf(arq, "%d\n", vetor[i] );
    }
    fclose(arq);

}

int main () {

   // setlocale(LC_ALL, "Portuguese");

    FILE * arqAlunos; 
    
    int leds[MAX];
    int leter[MAX];
    int robotica[MAX];
    int tamLeds=0, tamLeter=0, tamRobo=0;

        
    arqAlunos = abrirArquivo("ex3_alunos.txt", "r");
    carregarVetores(arqAlunos, leds, &tamLeds, leter, &tamLeter, robotica, &tamRobo);
    
    // Grava cada arquivo somente com os alunos daquele projeto
    gravarVetorNoArquivo("ex3_leds.txt", leds, tamLeds);
    gravarVetorNoArquivo("ex3_leter.txt", leter, tamLeter);
    gravarVetorNoArquivo("ex3_robotica.txt", robotica, tamRobo);

    printf("LEDS: \n");
    listar(leds,tamLeds);

    printf("LETER: \n");
    listar(leter,tamLeter);

    printf("Robótica: \n");
    listar(robotica,tamRobo);

    fclose(arqAlunos);
    return 0;
}