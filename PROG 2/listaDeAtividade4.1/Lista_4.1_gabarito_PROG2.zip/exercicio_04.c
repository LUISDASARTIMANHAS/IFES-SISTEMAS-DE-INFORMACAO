#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// ########## JOGO DE CRAPS  ###################

// Jogar os dados. O resto da divisão por 6 é
//    um número de entre 0 e 5, por isso soma-se 1
int lancarDado() {
    return ( rand() % 6) + 1;
}


int jogarDados() {
    int d1, d2, soma;
    printf("\n\nVamos jogar os dados\n");
	system("PAUSE");

    d1 = lancarDado();
    d2 = lancarDado();
    soma = d1 + d2;

    printf("Dado 1: %d\nDado 2: %d\n\n", d1, d2);
    printf("SOMA: %d\n", soma);
    printf("---------------------\n");
    return soma;
}

// DEMAIS RODADAS
// Retorna:  1 - GANHOU
//           0 - PERDEU
int ponto(int pt) {
    int soma;
    do {
        soma = jogarDados();

        if (soma == pt) {
            return 1;   // GANHOU
        } else if ( soma == 7) {
            return 0;   // PERDEU
        }
    } while ( ( soma != 7 ) && ( soma != pt ) );
}

// Primeira RODADA.
// Retorna:  1 - GANHOU
//           0 - PERDEU
int jogar() {
    int soma;

    soma = jogarDados();

    switch ( soma ) {
        case 7: case 11:
            return 1;   // GANHOU
            break;
        case 2: case 3: case 12:
            return 0;   // PERDEU
            break;
        default:
            printf ("\n\tSeu ponto: %d \n", soma);
            return ponto(soma);
            break;
    }
}


int main()
{
    // SEMENTE DOS NUMEROS ALEATÁRIOS. Usa a hora local
    srand( (unsigned) time(NULL) );

	printf("#### JOGO DE CRAPS ####\n");

	if ( jogar() == 1) {
        printf ("\n\t***** GANHOU *****\n");
    }
    else {
        printf ("\n\t***** PERDEU *****\n");
    }

	printf("\n\n\t----- FIM DO JOGO ------- \n\n");
}
