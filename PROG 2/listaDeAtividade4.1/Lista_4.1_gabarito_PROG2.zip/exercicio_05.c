#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// ########## JOGO DE CRAPS  ###################

// Jogar os dados. O resto da divisão por 6 é
//    um número de entre 0 e 5, por isso soma-se 1
int lancarDado() {
    return ( rand() % 6) + 1;
}


int jogarDados() {
    int d1, d2, soma;
    printf("\n\nVamos jogar os dados\n");
	system("PAUSE");

    d1 = lancarDado();
    d2 = lancarDado();
    soma = d1 + d2;

    printf("Dado 1: %d\nDado 2: %d\n\n", d1, d2);
    printf("SOMA: %d\n", soma);
    printf("---------------------\n");
    return soma;
}


// DEMAIS RODADAS
// Retorna:  1 - GANHOU
//           0 - PERDEU
int ponto(int pt) {
    int soma;
    do {
        soma = jogarDados();

        if (soma == pt) {
            return 1;   // GANHOU
        } else if ( soma == 7) {
            return 0;   // PERDEU
        }
    } while ( ( soma != 7 ) && ( soma != pt ) );
}


// Primeira RODADA.
// Retorna:  1 - GANHOU
//           0 - PERDEU
int jogar() {
    int soma;

    soma = jogarDados();

    switch ( soma ) {
        case 7: case 11:
            return 1;   // GANHOU
            break;
        case 2: case 3: case 12:
            return 0;   // PERDEU
            break;
        default:
            printf ("\n\tSeu ponto: %d \n", soma);
            return ponto(soma);
            break;
    }
}


float lerAposta(float saldo) {
	float aposta;
	do {
        printf("\n\tInforme sua aposta: ");
        scanf("%f", &aposta);
	} while ( ( aposta <= 0 ) || ( aposta > saldo) );
	return aposta;
}


int main()
{
    float aposta, saldo;
    char continuar;

    // SEMENTE DOS NUMEROS ALEATÓRIOS. Usa a hora local
    srand( (unsigned) time(NULL) );

	printf("#### JOGO DE CRAPS ####\n");

	saldo = 100;
	do {

        printf("\n\tSeu SALDO: R$ %.2f\n", saldo);
        aposta = lerAposta(saldo);
        if ( jogar() == 1) {
            printf ("\n\t***** GANHOU R$ %.2f *****\n", (2 * aposta) );
            saldo = saldo + aposta;
        }
        else {
            printf ("\n\t***** PERDEU R$ %.2f *****\n", aposta);
            saldo = saldo - aposta;
        }

        printf("\nDeseja continuar jogando? (S ou N)");
        scanf(" %c", &continuar);
	} while ( ( continuar == 'S' || continuar == 's' ) && ( saldo > 0 ) );

	printf("\n\n\t----- FIM DO JOGO ------- \n\n");
	printf("\n\tSaldo FINAL: R$ %.2f\n", saldo);
}
