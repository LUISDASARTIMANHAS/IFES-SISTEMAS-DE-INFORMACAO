#include <stdio.h>
#include <stdlib.h>
#define _USE_MATH_DEFINES
#include <math.h>

int lerOpcao() {
    int op;
    do {
        printf("\n\nCALCULAR A ÁREA:\n");
        printf("1-Retângulo\n");
        printf("2-Círculo\n");
        printf("0-Sair\n");
        printf("Informe sua opção: ");
        scanf("%d", &op);
    } while ( (op < 0 ) || ( op > 2) );

    return op;
}

// UMA ÚNICA FUNÇÃO para ler um número real maior que zero
float lerFloat() {
    float num;

    do {
        printf("\n\tValor: ");
        scanf("%f", &num);
    } while ( num <= 0.0 ) ;
    
    return num;
}

float areaRetangulo (float base, float alt) {

    return (base * alt);

}

float areaCirculo (float raio) {

    return ( M_PI * pow(raio,2) );

}

int main() {

    int opcao;
    float base, altura, raio, area;
    do {
        opcao = lerOpcao();

        switch(opcao) {
            case 1:
                printf("\n\tÁREA DO RETÂNGULO\n");

                // Ler e validar os dados para calcular a área do RETANGULO
                printf("\n\tInforme a base do retângulo: ");
                base = lerFloat();

                printf("\n\tInforme a altura do retângulo: ");
                altura = lerFloat();
                
                // Chamar a função para calcular a área do RETANGULO
                area = areaRetangulo(base, altura);

                // Mostrar o resultado
                printf("\n\tA área do retângulo de dimensões %.1f m e %.1f m é %.1f m2 \n\n", base, altura, area);
                break;

            case 2:
                printf("\n\tÁREA DO CÍRCULO\n");
                // Ler os dados para calcular a área do CIRCULO
                printf("\n\tInforme o raio do círculo: ");
                raio = lerFloat();

                // Chamar a função para calcular a área do CIRCULO
                area = areaCirculo(raio);

                // Mostrar o resultado
                printf("\n\tA área do círculo de raio %.1f m é %.1f m2 \n\n", raio, area);

                break;
        }

        system("PAUSE");
    } while ( opcao > 0);

    return 0;
}
