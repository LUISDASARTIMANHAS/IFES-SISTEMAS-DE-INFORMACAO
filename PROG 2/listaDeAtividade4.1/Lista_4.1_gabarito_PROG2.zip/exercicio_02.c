#include <stdio.h>
#include <ctype.h>

int lerPreco() {
    float preco;

    do {
        printf("\n\tPreço: ");
        scanf("%f", &preco);
    } while ( preco <= 0.0 ) ;
    
    return preco;
}


char lerPgto() {
    char pag;

    do {
        printf("\n\tForma de pagamento (V - a vista ou P - a prazo): ");
        scanf(" %c", &pag);
        pag = toupper(pag);   // Converte um CHAR para maiúsculo
    } while ( ( pag != 'V' ) && ( pag != 'P') ) ;
    
    return pag;
}

int lerQtde() {
    int qtde;

    do {
        printf("\n\tQuantidade: ");
        scanf("%d", &qtde);
    } while ( qtde <= 0.0 ) ;
    
    return qtde;
}

float calcTotal(float preco, char pgto, float qtde) {
    float valor;
    if ( pgto == 'V') {
        valor = preco * qtde * 0.9;
    } else {
        valor = preco * qtde * 1.1;
    }

    return valor;
}


int main() {

    float preco, valorTotal;
    char pgto;
    int qtde;

    preco = lerPreco();
    pgto = lerPgto();
    qtde = lerQtde();

    valorTotal = calcTotal(preco, pgto, qtde);

    printf("\n\tValor a pagar: R$ %6.2f \n\n", valorTotal );

    return 0;
}