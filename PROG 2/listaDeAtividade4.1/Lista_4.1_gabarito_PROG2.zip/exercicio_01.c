#include <stdio.h>

int lerMatricula() {
    int mat;

    do {
        printf("\n\tMatrícula: ");
        scanf("%d", &mat);
    } while ( mat <= 0 );
    
    return mat;
}

int lerNota(int num) {
    float nota;

    do {
        printf("\n\tNota %d: ", num);
        scanf("%f", &nota);
    } while ( ( nota < 0.0 ) || ( nota > 10.0) );
    
    return nota;
}

float calcMedia(float n1, float n2, float n3) {
    return (n1 + n2 + n3) / 3;
}

void mostrarResultado(int mat, float media) {
    printf("\n\tO aluno %d ficou com média %.1f e está ", mat, media);
    if ( media < 6 ) {
        printf("REPROVADO.\n");
    } else if ( media < 7 ) {
        printf("de PROVA FINAL.\n");
    } else {
        printf("APROVADO.\n");
    }
    printf("\n\n");
}


int main() {

    float nota1, nota2, nota3, media;
    int matricula;

    matricula = lerMatricula();
    nota1 = lerNota(1);
    nota2 = lerNota(2);
    nota3 = lerNota(3);

    media = calcMedia(nota1, nota2, nota3);
    mostrarResultado(matricula, media);

    return 0;
}
