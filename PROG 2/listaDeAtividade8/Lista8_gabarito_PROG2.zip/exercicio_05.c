#include <stdio.h>
#include <stdlib.h> 
#include <string.h> 
#include <windows.h>

#define MAX 100
#define NUM_POLTRONAS 46  

struct Horario {
	int hora;
	int minuto;
	int qtdeDisponivel;
	int poltronas[NUM_POLTRONAS];
};
typedef struct Horario Horario;


struct Linha {
	char origem[MAX];
	char destino[MAX];
	Horario horarios[50];
	int totalHorarios;
};
typedef struct Linha Linha;


struct Linhas {
	Linha vetLinhas[100];
	int totalLinhas;
};
typedef struct Linhas Linhas;



int menu() {
	int op;
	system("@cls||clear");  // LIMPA A TELA
	printf("1 -> Inserir linha\n");
	printf("2 -> Vender passagem\n");
	printf("3 -> Mostrar linhas\n");
	printf("0 -> Sair\n");
	do {
		printf("ESCOLHA: ");
		scanf("%d", &op);
	} while (op < 0 || op > 3);
	return op;
}

int subMenu() {
	int op;	
	printf("1 -> Inserir Horário\n");
	printf("0 -> Voltar\n");
	printf("ESCOLHA: ");
	do {
		printf("ESCOLHA: ");
		scanf("%d", &op);
	} while (op < 0 || op > 1);
	return op;
	
}

// ----- Inicializar VETOR de LINHAS  
void inicializar (Linhas *linhas) {
	linhas->totalLinhas = 0;		
}


// ----- Inicializar UM HORARIO 
void inicializarHorario (Horario * h) {
	int i;
	
	h->hora = 0;
	h->minuto = 0;
	h->qtdeDisponivel = NUM_POLTRONAS;
	
	for(i=0 ; i < NUM_POLTRONAS; i++ ) {
		h->poltronas[i] = 0;		
	}
}

// Lê um numero MAIOR que ZERO e menor ou IGUAL A MAX
int lerNumero( char * msg, int max){
	int num;
	do {
		printf("%s", msg);
		scanf("%d", &num);
	} while ( num < 0 || num > max);
	return num;
}

void mostrarHorario (int ind, Horario h) {

	printf("\t%2d\t %02d:%02d\t%7d\n", ind, h.hora, h.minuto, h.qtdeDisponivel );
		
}

// Mostrar TODAS os HORARIOS de UMA linha
void listarHorarios(Linha lin) {
	int i;
	printf("\n\tIND\tHORÁRIO\t DISPONÍVEIS\n");
	for (i=0; i < lin.totalHorarios ; i++ ){
		mostrarHorario(i+1, lin.horarios[i] );
	}
}

void mostrarLinha (int ind, Linha lin) {
	
	printf("LINHA %2d: %s X %s\n", ind, lin.origem, lin.destino);
	
	listarHorarios( lin );
	
}

void inserirHorario( Linha * lin ) {
	int hora, min;
	int pos = lin->totalHorarios;
	
	// Aumenta UM HORARIO
	lin->totalHorarios++;
	
	inicializarHorario( &lin->horarios[pos] );
	
	do {
		printf("Hora: ");
		scanf("%d", &hora );
	} while ( hora < 0 || hora > 23 );
	
	lin->horarios[pos].hora = hora;
	
	do {
		printf("Minuto: ");
		scanf("%d", &min );
	} while ( min < 0 || min > 59 );
	
	lin->horarios[pos].minuto = min;	
	
}

// Insere uma LINHA de onibus
void inserirLinha(Linhas *linhas) {
	int op;
	int pos = linhas->totalLinhas;
	
	// Aumento UMA LINHA
	linhas->totalLinhas++;
	
	linhas->vetLinhas[pos].totalHorarios = 0;
	
	printf("Cidade de origem: ");
	scanf(" %99[^\n]s", linhas->vetLinhas[pos].origem );
	
	printf("Cidade de destino: ");
	scanf(" %99[^\n]s", linhas->vetLinhas[pos].destino );
		
	do {
		system("@cls||clear");  // LIMPA A TELA
		mostrarLinha( pos+1, linhas->vetLinhas[pos] );
		printf("-----------------------------\n\n");
		op = subMenu();
		switch (op) {
			case 0: break;
			case 1:  // Inserir Horário
				inserirHorario( &linhas->vetLinhas[pos] );
				break;		
			default:
				printf("\nOpçãoo inválida!\n");
				system("PAUSE");
		}			
	} while (op != 0);

		
}


// Mostrar TODAS as linhas cadastradas
void listarLinhas (Linhas linhas) {
	int i;
	printf("\n################################\n");
	for (i=0; i < linhas.totalLinhas ; i++ ){
		mostrarLinha(i+1, linhas.vetLinhas[i] );
		printf("\n--------------------------------\n");
	}
	printf("\n################################\n\n");
}


// Pesquisar no VETOR de LINHA a LINHA com origem e destino
int pesquisarLinha (Linhas * linhas, char * origem, char * destino) {
	int i;
	for (i=0; i < linhas->totalLinhas ; i++ ) {
		if ( strcmp(strupr(origem), strupr(linhas->vetLinhas[i].origem) ) == 0  && 
			 strcmp(strupr(destino), strupr(linhas->vetLinhas[i].destino) ) == 0 ) {
			return i;
		}
		
	}
	return -1;  // LINHA NÃO encontrada
}

void mostrarPoltronas (Horario * hora) {
	int i;
	printf("\n--------------------------------------------------------------");
	
	// PRIMEIRA FILEIRA
	printf("\n|     |");
	for (i=4; i <= NUM_POLTRONAS; i=i+4) {
		if ( hora->poltronas[i-1] == 0 ) {		
			printf(" %02d |", i );
		} else {
			printf(" XX |" );
		}
	}
	printf(" BN |");
	
	// SEGUNDA FILEIRA
	printf("\n|     |");
	for (i=3; i <= NUM_POLTRONAS; i=i+4) {
		if ( hora->poltronas[i-1] == 0 ) {		
			printf(" %02d |", i );
		} else {
			printf(" XX |" );
		}
	}
	printf(" BN |");

	printf("\n|                                                            |");
	
	// TERCEIRA FILEIRA
	printf("\n| MOT |");
	for (i=2; i <= NUM_POLTRONAS; i=i+4) {
		if ( hora->poltronas[i-1] == 0 ) {		
			printf(" %02d |", i );
		} else {
			printf(" XX |" );
		}
	}

	// QUARTA FILEIRA
	printf("\n| MOT |");
	for (i=1; i <= NUM_POLTRONAS; i=i+4) {
		if ( hora->poltronas[i-1] == 0 ) {		
			printf(" %02d |", i );
		} else {
			printf(" XX |" );
		}
	}
	printf("\n--------------------------------------------------------------\n\n");
}


void lerPoltrona( int ind, Horario * hora) {
	int num, sair;
	do {
		system("@cls||clear");  // LIMPA A TELA
		mostrarHorario( ind, *hora );	
		mostrarPoltronas( hora );
		printf("\n\t0 para VOLTAR\n");
		num = lerNumero("Nº poltrona: ", NUM_POLTRONAS);   // Le um numero entre 0 e 41
		
		if (num > 0 ) {
			num--;		
			if ( hora->poltronas[num] == 1 ) {
				printf("\nPoltrona já vendida!\n");
			} else {
				hora->poltronas[num] = 1;
				hora->qtdeDisponivel--;
			}
			
			printf("\n\tDIGITE:\n\t\t 1 PARA ESCOLHER OUTRA POLTRONA ou\n\t\t 0 para VOLTAR.\n");
			printf("\tEscolha: ");
			scanf("%d", &sair);	
		} else {
			sair = 0;
		}
			

	} while ( sair != 0 );
}



void venderPassagem (Linhas * linhas){
	char origem[100], destino[100];
	int horario, sair = 0;
	
	printf("Cidade de origem: ");
	scanf(" %99[^\n]s", origem );
	
	printf("Cidade de destino: ");
	scanf(" %99[^\n]s", destino );
	
	int pos = pesquisarLinha(linhas, origem, destino);
	if ( pos >= 0) {
		
		do {
			system("@cls||clear");  // LIMPA A TELA
			mostrarLinha( pos+1, linhas->vetLinhas[pos] );	
			printf("\n\t0 para VOLTAR\n");
			horario = lerNumero( "Horário: ", linhas->vetLinhas[pos].totalHorarios);

			if ( horario > 0 ) {		
				horario--;
				
				if ( linhas->vetLinhas[pos].horarios[horario].qtdeDisponivel > 0 ) {
					lerPoltrona( horario+1, &linhas->vetLinhas[pos].horarios[horario] );
				} else {
					printf("\n\n\tNÃO HÁ POLTRONAS DISPONÍVEIS.\n");
				}
				
				printf("\n\tDIGITE:\n\t\t 1 PARA ESCOLHER OUTRO HORÁRIO ou\n\t\t 0 para VOLTAR.\n");
				printf("\tEscolha: ");
				scanf("%d", &sair);				
			} else {
				sair = 0;
			}

		} while (sair != 0 );
		
	} else {
		printf("\n\n\tLINHA NÃO ENCONTRADA.\n\n");
	}
	
}




// ##############  PRINCIPAL #########################

int main() {
	int op;
	struct Linhas linhas;		
	
	SetConsoleOutputCP(65001);
	
	inicializar(&linhas);	
	
	do {		

		op = menu();
		switch(op) {
			case 0: 
				printf("\n\tFIM DO PROGRAMA.\n\n");
				break;
				
			case 1: // INSERIR UMA LINHA
				inserirLinha(&linhas);
				break;
				
			case 2: // VENDER PASSAGENS
				venderPassagem(&linhas);
				break;
				
			case 3:	// MOSTRAR TODAS AS LINHAS
				listarLinhas(linhas);
				break;
			default:
				printf("\n\tOpção inválida!\n");				
		}
		system("PAUSE");
	} while (op != 0);

	return 0;
}

