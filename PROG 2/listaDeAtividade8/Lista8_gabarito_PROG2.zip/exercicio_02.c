#include <stdio.h>
#include <math.h>

struct Ponto {
	float x;
	float y;
	char cor[50];
};
typedef struct Ponto Ponto;


struct Reta {
	Ponto p1;
	Ponto p2;
	char cor[50];
};
typedef struct Reta Reta;


// ####### FUNCOES PARA PONTO ####################
void lerPonto (Ponto *p) {
	printf("\n\tX: ");
	scanf("%f", &p->x );

	printf("\tY: ");
	scanf("%f", &p->y );

	printf("\tCOR DO PONTO: ");
	scanf(" %49[^\n]s", p->cor );
}


void mostrarPonto (Ponto p) {
	printf("\n\tPONTO: (%.2f, %.2f) -> %s", p.x, p.y, p.cor );
	
}


// ####### FUNCOES PARA RETA ####################
void lerReta (Reta * r) {
	lerPonto(&r->p1);
	lerPonto(&r->p2);
	
	printf("\tCOR DA RETA: ");
	scanf(" %49[^\n]s", r->cor );
}


void mostrarReta (Reta r) {
	printf("\n\n\tRETA:\n");
	mostrarPonto(r.p1);
	mostrarPonto(r.p2);
	printf("\n\tCor da RETA: %s\n\n", r.cor );
	
}

// Calcula a distância entre os dois pontos da RETA
float distancia (Reta r) {
	
	return sqrt( pow(r.p2.x - r.p1.x,2) + pow(r.p2.y - r.p1.y,2) );	
	
}




int main() {
	struct Reta r;
	
	// RETA
	lerReta(&r);
	mostrarReta(r);
	printf("\n\tDISTÂNCIA DA RETA: %.2f", distancia(r) );
	return 0;
}
