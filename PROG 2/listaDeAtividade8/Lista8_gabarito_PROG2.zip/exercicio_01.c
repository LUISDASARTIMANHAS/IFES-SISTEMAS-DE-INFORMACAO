#include <stdio.h>

struct Ponto {
	float x;
	float y;
	char cor[50];
};
typedef struct Ponto Ponto;


void lerPonto (Ponto *p) {
	printf("\n\tX: ");
	scanf("%f", &p->x );

	printf("\tY: ");
	scanf("%f", &p->y );

	printf("\tCOR: ");
	scanf(" %49[^\n]s", p->cor );
}


void mostrarPonto (Ponto p) {
	printf("\n\t(%.2f, %.2f) -> %s\n\n", p.x, p.y, p.cor );
	
}


int main() {
	Ponto p1, p2;
	lerPonto(&p1);
	mostrarPonto(p1);

	lerPonto(&p2);
	mostrarPonto(p2);
	return 0;
}
