#include <stdio.h>
#include <string.h>
#include <ctype.h>

// PALÍNDROME
// Retorna 0-false	1-Verdadeiro
// Uso dois índices. Um que começa do início e outro que começa do final.
// Comparo caracter por caracter desses índices. Enquanto forem iguais, continuo.
// Ignoro os demais símbolos.
int palindrome(char * str) {
	int i, f;
	i = 0;				 // INICIO
	f = strlen(str)-1;   // FINAL

	while ( i < f ) {

		// Considerar apenas LETRAS
		while ( ! isalpha(str[i]) ) { 
			i++;
		}
		while ( ! isalpha(str[f]) ) { 
			f--;
		}

		if ( str[i] == str[f] ){
			i++;
			f--;
		} else {
			return 0;	// NÃO É
		}
	}
	return 1;   // É PALINDROME
}



int main () {
    //char str[100] = "Socorram-me, subi no onibus em marrocos.";
	//char str[100] = "Luza Rocelina, a namorada do Manuel, leu na moda da Romana: anil e cor azul.";
	char str[100] = "O duplo po do trote torpe de potro meu que morto pede protetor todo polpudo.";

    strupr(str);

    if ( palindrome(str) ) {
    	printf("\n\nA frase \"%s\" é palíndrome.\n\n", str);
	} else {
		printf("\n\nA frase \"%s\" NÃO é palíndrome.\n\n", str);
	}

	return 0;
}
