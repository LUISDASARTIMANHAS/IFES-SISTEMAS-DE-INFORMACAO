#include <stdio.h>

int tamanho ( char * s ) {
	int cont = 0;
	while ( s[cont] != '\0') {
		cont++;
	}

	return cont;


}


int main() {

	char str[50] = "Boa tarde!";

	printf("\n\tA string \"%s\" tem %d caracteres.\n\n" , str, tamanho(str) );

	return 0;


}
