#include <stdio.h>
#include <string.h>

// Conta quantos caracteres CH estão em STR
int contCaractere(char * str, char ch) {

    int cont = 0;
    char * pch;	// Ponteiro para char

    pch = strchr(str,ch);
    while ( pch != NULL) {
        cont++;
        pch = strchr(pch+1,ch);	// Procura novamente a partir da última posição encontrada
    }
    return cont;
}



int main () {
    char str[50] = "Exemplo de string para teste";
    char ch = 'e';
    int cont;

    cont = contCaractere(str,ch);
    printf("\n\tO caractere '%c' aparece %d vezes na string \"%s\"\n\n", ch, cont, str);
    
    return 0;
}