#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// CONVERTER DATA
// Retorna a DATA CONVERTIDA ou
//   NULL se for DATA INVÁLIDA
char * converterData(char * str) {
	char * p, dia[11], mes[11], ano[11];

	char * dtRetorno;   // Essa data será RETORNADA PELA FUNÇÃO,
                        //   portanto ela DEVE ser alocada dinamicamente
	dtRetorno = (char *) malloc(11);

	strcpy(dia,str);
	// Procurando PRIMEIRA '/'
	p = strchr(dia,'/');
	if ( p != NULL ) {
        p[0] = '\0';

        strcpy(mes,p+1);

        // Procurando SEGUNDA '/'
        p = strchr(mes,'/');
        if ( p != NULL ) {
            p[0] = '\0';
            strcpy(ano,p+1);

            strcpy(dtRetorno,ano);
            strcat(dtRetorno,"-");
            strcat(dtRetorno,mes);
            strcat(dtRetorno,"-");
            strcat(dtRetorno,dia);
            return dtRetorno;
        }
	}
	return NULL;
}



int main () {
    char str[11];
    char * dtConvertida;

    printf("INFORME A DATA: ");
    scanf("%10[^\n]s", str);


    dtConvertida = converterData(str);

	if ( dtConvertida != NULL ) {
	    printf("\n\tDATA ORIGINAL: %s", str);
	    printf("\n\tDATA CONVERTIDA: %s\n\n", dtConvertida);
	} else {
		printf("\n\tDATA INVÁLIDA: \n\n");
	}

    return 0;
}
