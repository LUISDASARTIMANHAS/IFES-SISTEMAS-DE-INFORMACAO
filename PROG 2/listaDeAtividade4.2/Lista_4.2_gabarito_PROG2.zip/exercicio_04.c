/*
	EXPONENCIAÇÃO
*/

#include <stdio.h>
#include <math.h>


// Lê um numero FLOAT
// Usado a passagem de parâmetro por referência
void lerNumeroReal(float * num) {
	printf("\tInforme um número REAL: ");
	scanf("%f", num);
}

// Lê um numero INT
// Usado a passagem de parâmetro por referência
void lerNumeroInt(int * num) {
	printf("\tInforme um número INTEIRO: ");
	scanf("%d", num);
}


void lerDados(float * n1, int * n2) {
	// Ler NUM 1
	printf("\n\tNÚMERO 1\n");
	lerNumeroReal(&*n1);
	
	// Ler NUM 2
	printf("\n\tNÚMERO 2\n");
	lerNumeroInt(n2);
}


// Calcula a multiplicação entre dois numeros
float multiplicacao(float x, float y) {
	
	int i, yInt;
	float soma, yDec;
	soma = 0;
	
	// Verificar sinal de Y
	if ( y > 0 ){
		yInt = floor(y);  // Pega a parte inteira de Y
		yDec = y - yInt;  // Pega a parte decimal de Y
		
		for (i = 1; i <= yInt; i++ ){
			soma = soma + x;   // POSITIVO ==> soma
		}
		
		return soma + (x / (1/yDec) ) ;   //Somando com a parte decimal de Y.
		
	} else if ( y < 0 ) {

		yInt = floor(y) + 1;  // Pega a parte inteira de Y
		yDec = y - yInt;  // Pega a parte decimal de Y
		
		for (i = -1; i >= yInt; i-- ){
			soma = soma - x;	// NEGATIVO ==> subtrai
		}

		return soma + (x / (1/yDec) ) ;   //Somando com a parte decimal de Y.
		
	} else {
		return 0;
	}
		
}


// Calcula X elevado e Y
float potencia(float x, int y) {
	
	int i;
	float mult;
	mult = 1;
		
	for (i = 1; i <= y; i++ ){
		mult = multiplicacao(mult,x);  // SIGNIFICA  mult = mult * x;
	}
	
	return mult;
}


int main() {
	
	float num1, pot;
	int num2;
	
	lerDados(&num1, &num2);
	
	pot = potencia(num1,num2);

	printf("\n\n\tA potencialização entre %f e %d é: %f\n", num1, num2, pot);
	printf("\n\tContra-prova: %f\n\n", pow(num1, num2));

	return 0;

}
