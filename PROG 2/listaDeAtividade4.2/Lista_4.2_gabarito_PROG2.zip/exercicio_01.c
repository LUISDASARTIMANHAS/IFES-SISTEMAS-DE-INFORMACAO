/*
	Distancia entre dois pontos (X1,Y1) e (X2,Y2)
*/

#include <stdio.h>
#include <math.h>

// Lê o X e Y de um ponto
// Usado a passagem de parâmetro por referência
void lerPonto(float * x, float * y) {
	printf("\n\tInforme a coordenada X: ");
	scanf("%f", x);
	printf("\n\tInforme a coordenada Y: ");
	scanf("%f", y);
}


// Calcula a distância entre dois pontos
float distancia(float x1, float y1, float x2, float y2) {
	
	return sqrt( pow(x2-x1,2) + pow(y2-y1,2) );	
	
}


int main() {
	
	float x1, y1;	// PONTO 1
	float x2, y2;	// PONTO 2
	float dist;
	
	// Ler PONTO 1
	printf("\n\tPONTO 1\n");
	lerPonto(&x1,&y1);
	
	// Ler PONTO 2
	printf("\n\tPONTO 2\n");
	lerPonto(&x2,&y2);
	
	dist = distancia(x1,y1,x2,y2);

	printf("\n\n\tA distância é: %.2f\n\n", dist);

	return 0;
}
