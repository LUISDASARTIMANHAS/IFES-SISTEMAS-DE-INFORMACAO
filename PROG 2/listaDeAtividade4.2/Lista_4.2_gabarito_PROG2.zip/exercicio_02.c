/*
	Perímetro de um triângulo
*/

#include <stdio.h>
#include <math.h>

// Lê o X e Y de um ponto
// Usado a passagem de parâmetro por referência
void lerPonto(float * x, float * y) {
	printf("\n\tInforme a coordenada X: ");
	scanf("%f", x);
	printf("\n\tInforme a coordenada Y: ");
	scanf("%f", y);
}


// Calcula a distância entre dois pontos
float distancia(float x1, float y1, float x2, float y2) {
	
	return sqrt( pow(x2-x1,2) + pow(y2-y1,2) );	
	
}

// Calcula o perímetro dado pelos 3 pontos de um triangulo
float perimetro(float x1, float y1, float x2, float y2, float x3, float y3) {
	
	return distancia(x1,y1,x2,y2) + distancia(x1,y1,x3,y3) + distancia(x2,y2,x3,y3);	
	
}

int main() {
	
	float x1, y1;	// PONTO 1
	float x2, y2;	// PONTO 2
	float x3, y3;	// PONTO 3
	float perim;
	
	// Ler PONTO 1
	printf("\n\tPONTO 1\n");
	lerPonto(&x1,&y1);
	
	// Ler PONTO 2
	printf("\n\tPONTO 2\n");
	lerPonto(&x2,&y2);
	
	// Ler PONTO 3
	printf("\n\tPONTO 3\n");
	lerPonto(&x3,&y3);

	perim = perimetro(x1,y1,x2,y2,x3,y3);

	printf("\n\n\tO perímetro do triângulo é: %.2f\n\n", perim);

	return 0;
}
