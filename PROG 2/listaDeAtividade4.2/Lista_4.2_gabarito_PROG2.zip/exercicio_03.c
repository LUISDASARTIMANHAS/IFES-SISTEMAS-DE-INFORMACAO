/*
	MULTIPLICAÇÃO
*/

#include <stdio.h>
#include <math.h>

// Lê um número qualquer
// Usado a passagem de parâmetro por referência
void lerNumero (float * num) {
	printf("\tInforme um número: ");
	scanf("%f", num);
}

void lerDados(float * n1, float * n2) {
	// Ler NUM 1
	printf("\n\tNÚMERO 1\n");
	lerNumero(&*n1);
	
	// Ler NUM 2
	printf("\n\tNÚMERO 2\n");
	lerNumero(n2);
}


// Calcula a multiplicaçãoo entre dois numeros
float multiplicacao(float x, float y) {
	
	int i, yInt;
	float soma, yDec;
	soma = 0;
	
	// Verificar sinal de Y
	if ( y > 0 ){
		yInt = floor(y);  // Pega a parte inteira de Y
		yDec = y - yInt;  // Pega a parte decimal de Y
		
		for (i = 1; i <= yInt; i++ ){
			soma = soma + x;   // POSITIVO ==> soma
		}
		
		return soma + (x / (1/yDec) ) ;   //Somando com a parte decimal de Y.
		
	} else if ( y < 0 ) {

		yInt = floor(y) + 1;  // Pega a parte inteira de Y
		yDec = y - yInt;  // Pega a parte decimal de Y
		
		for (i = -1; i >= yInt; i-- ){
			soma = soma - x;	// NEGATIVO ==> subtrai
		}

		return soma + (x / (1/yDec) ) ;   //Somando com a parte decimal de Y.
		
	} else {
		return 0;
	}
	
	
}


int main(){
	
	float num1, num2, mult;
	
	lerDados(&num1, &num2);
	
	mult = multiplicacao(num1,num2);

	printf("\n\n\tA multiplicaçãoo entre %f e %f é: %f\n\n", num1, num2, mult);

	return 0;

}
