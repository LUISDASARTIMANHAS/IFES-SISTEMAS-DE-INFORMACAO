/*
	Implemente um programa em C que imprima todos os números inteiros de 100 a 1 (em ordem decrescente).
*/

#include <stdio.h>

int main() {
	int num;

	for (num = 100; num > 0; num--) {
		printf("%d\t", num);
		
		// Coloca uma quebra de linha a cada 10 números
		if ( num % 10 == 0 ) {
			printf("\n");
		} 
	}

	printf("\n\n");
	return 0;
}
