/*
	Implemente um programa em C que imprima todos os n�meros m�ltiplos de 5, no intervalo fechado de 1 a 500.	
*/

#include <stdio.h>

int main() {
	int num;

	for (num = 1; num <= 500; num++) {
		if (num % 5 == 0)
			printf("%d\t", num);
	}
	printf("\n\n");

	// ###   OU   ####

	for (num = 5; num <= 500; num = num + 5) {
		printf("%d\t", num);
	}
	printf("\n\n");

	return 0;
}
