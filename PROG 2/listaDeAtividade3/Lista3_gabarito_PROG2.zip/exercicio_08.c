#include <stdio.h>
#include <stdlib.h>

/* Deseja-se as seguintes informações estatásticas:

1. Quantos homens existem na turma ?
2. Quantas mulheres existem na turma ?
3. Qual é a média das notas ?
4. Quantos alunos DR existem na turma ?
5. Quantos alunos DI existem na turma ?
6. Qual a % de alunos DB, DR e DI na turma ?
7. Qual a % de homens DB, DR e DI na turma ?
8. Qual a % de mulheres DB, DR e DI na turma ?

Definições:
DB - Desenvolvendo-se bem: entre 80 e 100
DR - Desenvolvendo-se regularmente: nota entre 60 e 79.
DI - Desenvolvendo-se insuficiente: nota menor que 60. 

*/

int main() {
	int qt_homens=0, qt_mulheres=0; 
	int qt_homens_DB = 0, qt_mulheres_DB=0;
	int qt_homens_DR = 0, qt_mulheres_DR=0;
	int qt_homens_DI = 0, qt_mulheres_DI=0;
	int qt_aluno_DR, qt_aluno_DI, qt_aluno_DB;
	float nota, soma=0, media=0;
	float porcentagem_DB= 0, porcentagem_DR= 0, porcentagem_DI= 0;
	float porcentagem_homem_DB= 0, porcentagem_homem_DR= 0, porcentagem_homem_DI= 0;
	float porcentagem_mulheres_DB= 0, porcentagem_mulheres_DR= 0, porcentagem_mulheres_DI= 0;		
	char sexo;
	int matricula;
	
	// A leitura da primeira matricula será fora do while 
	//	pois ela pode ser uma matricula valida ou negativa, indicando a saída do programa	
	printf("\n\tEntre com a matrícula do aluno ou -1 para sair: ");
	scanf("%d", &matricula);
	
	while (matricula > 0 ) {
		// Ler e validar a nota
		do{
			printf("\n\tInforme a nota do aluno: ");
			scanf("%f", &nota);
		} while ( (nota < 0 ) || ( nota > 100 ) );

		soma = soma + nota;

		// Esse do while vai obrigar que o sexo seja f ou m
		do{
			printf("\n\tDigite o sexo (f para FEMININO e m para MASCULINO): ");
			scanf(" %c", &sexo);
		} while ( ( sexo != 'f') && ( sexo != 'F' ) && ( sexo != 'm' ) && ( sexo != 'M' ) );
		
		// Se for homem
		if ( ( sexo == 'm') || ( sexo == 'M' ) ) { 
			qt_homens++;
			if (nota >= 80) {
				qt_homens_DB++;
			}
			else if (nota >= 60) {
				qt_homens_DR++;	
			}
			else {
				qt_homens_DI++;
			}
		} 
		else { // Se for mulher
			qt_mulheres++;
			if (nota >= 80) {
				qt_mulheres_DB++;
			}
			else if (nota >= 60) {
				qt_mulheres_DR++;	
			} 
			else {
				qt_mulheres_DI++;
			}
		}
		printf("\n\tEntre com a próxima matrícula do aluno ou -1 para sair: ");
		scanf("%d", &matricula);
	}
	
	printf("\n\tA quantidade de homens é: %d\n", qt_homens);
	printf("\n\tA quantidade de mulheres é: %d\n", qt_mulheres);

	// Evitando divisão por 0
	if ( (qt_homens + qt_mulheres) > 0 )
		media = soma / (qt_homens + qt_mulheres);
	printf("\n\tA média das notas é: %0.2f\n", media);
	
	qt_aluno_DB = qt_homens_DB + qt_mulheres_DB;
	qt_aluno_DR = qt_homens_DR + qt_mulheres_DR;
	qt_aluno_DI = qt_homens_DI + qt_mulheres_DI;	
	printf("\n\tA quantidade de alunos DB é: %d\n", qt_aluno_DB);
	printf("\n\tA quantidade de alunos DR é: %d\n", qt_aluno_DR);
	printf("\n\tA quantidade de alunos DI é: %d\n", qt_aluno_DI);
			
	// Evitando divisão por 0
	if ( (qt_homens + qt_mulheres) > 0 ) {
		porcentagem_DB = (float) qt_aluno_DB / (qt_homens + qt_mulheres);
		porcentagem_DR = (float) qt_aluno_DR / (qt_homens + qt_mulheres);
		porcentagem_DI = (float) qt_aluno_DI / (qt_homens + qt_mulheres);
	}

	// Evitando divisão por 0
	if (qt_homens > 0) {
		porcentagem_homem_DB = (float) qt_homens_DB / qt_homens;
		porcentagem_homem_DR = (float) qt_homens_DR / qt_homens;
		porcentagem_homem_DI = (float) qt_homens_DI / qt_homens;		
	}

	// Evitando divisão por 0
	if (qt_mulheres > 0) {
		porcentagem_mulheres_DB = (float) qt_mulheres_DB / qt_mulheres;
		porcentagem_mulheres_DR = (float) qt_mulheres_DR / qt_mulheres;
		porcentagem_mulheres_DI = (float) qt_mulheres_DI / qt_mulheres;		
	}

	
	printf("\n\tA porcentagem de alunos DB é: %0.2f%%\n", 100*porcentagem_DB);
	printf("\n\tA porcentagem de alunos DR é: %0.2f%%\n", 100*porcentagem_DR);
	printf("\n\tA porcentagem de alunos DI é: %0.2f%%\n", 100*porcentagem_DI);

	printf("\n\tA porcentagem de homens DB é: %0.2f%%\n", 100*porcentagem_homem_DB);
	printf("\n\tA porcentagem de homens DR é: %0.2f%%\n", 100*porcentagem_homem_DR);
	printf("\n\tA porcentagem de homens DI é: %0.2f%%\n", 100*porcentagem_homem_DI);
	
	printf("\n\tA porcentagem de mulheres DB é: %0.2f%%\n", 100*porcentagem_mulheres_DB);
	printf("\n\tA porcentagem de mulheres DR é: %0.2f%%\n", 100*porcentagem_mulheres_DR);
	printf("\n\tA porcentagem de mulheres DI é: %0.2f%%\n", 100*porcentagem_mulheres_DI);

	return 0;	
}
