/*
	Senso da academia: mais alto, o mais baixo, o mais gordo e o mais magro.
*/

#include <stdio.h>

int main() { 
	
	// Declaração e iniciaização das variáveis
	int cod = 0	;			// Código do cliente
	int cont = 0 ;          // Contador de clientes
	float peso = 0.0 ;   	// Ler o peso
	float altura = 0.0 ; 	// Ler a altura
	float mediaPeso = 0.0;	// Media de pesos
	float mediaAltura = 0.0; // Media de alturas
	
	/* 	Variáveis para armazenar o MAIS ALTO.
		No início o mais alto é ZERO, para o primeiro a ser lido 
		ser mais alto que essa variável
	*/
	float maisAlto = 0.0;
	int codMaisAlto = 0;
	
	/* 	Variáveis para armazenar o MAIS BAIXO.
		No início o mais baixo é um valor alto, por exemplo 5, 
		para o primeiro a ser lido ser mais baixo que essa variável
	*/
	float maisBaixo = 5.0;
	int codMaisBaixo = 0;
	
	/*	Variáveis para armazenar o MAIS GORDO.
		No início o mais gordo é ZERO, para o primeiro a ser lido 
		ser mais gordo que essa variável
	*/
	float maisGordo = 0.0;
	int codMaisGordo = 0;
	
	/* 	Variáveis para armazenar o MAIS MAGRO. 
		No início o mais magro é um valor alto, por exemplo 500, 
		para o primeiro a ser lido ser mais magro que essa variável
	*/
	float maisMagro = 500.0;
	int codMaisMagro = 0;
	
	// Ler e validar o primeiro codigo
	do{
		printf("\n\tInforme o código do cliente: ");
		scanf("%d", &cod);
	} while ( cod < 0 );
		 
	// Vou repetir até o código digitado for igual a ZERO		 
	while (cod > 0 ) {

		// Ler e validar o peso
		do {
			printf("\n\tInforme o peso do cliente: ");
			scanf("%f", &peso);	
	    } while ( peso <= 0 || peso >= 500 );
	
		// Ler e validar a altura
		do {
			printf("\n\tInforme a altura do cliente: ");
			scanf("%f", &altura);	
	    } while ( altura <= 0.1 || altura >= 2.5 );
	      	
	    mediaPeso = mediaPeso + peso;
	    mediaAltura = mediaAltura + altura;
	
	    cont = cont + 1;
	
	    // Verificar se é mais ALTO
	    if ( altura > maisAlto ) {
	        maisAlto = altura;
	        codMaisAlto = cod;
	    }
	
	    // Verificar se é mais BAIXO
	    if ( altura < maisBaixo ) {		
	        maisBaixo = altura;
	        codMaisBaixo = cod;
	    }
	
	    // Verificar se é mais GORDO
	    if ( peso > maisGordo ) {
	        maisGordo = peso;
	        codMaisGordo = cod;
	    }
	
	    // Verificar se é mais MAGRO
	    if ( peso < maisMagro ) {
	        maisMagro = peso;
	        codMaisMagro = cod;
		}
	    
		// Ler e validar o PRÓXIMO código
		do{
			printf("\n\tInforme o código do cliente: ");
			scanf("%d", &cod);
		} while ( cod < 0 );

	}
	// Fim do WHILE
	
	//Imprimir as informações
	if ( cont > 0 ) {
	    mediaPeso = mediaPeso / cont;
	    mediaAltura = mediaAltura / cont;
	
	    printf("\n\tMAIS ALTO: %2d", codMaisAlto);
	    printf("\n\tAltura: %.2fm\n", maisAlto);
	
	    printf("\n\tMAIS BAIXO: %2d", codMaisBaixo);
	    printf("\n\tAltura: %.2fm\n", maisBaixo);
	
	    printf("\n\tMAIS GORDO: %2d", codMaisGordo);
	    printf("\n\tPeso: %.1fkg\n", maisGordo);
	
	    printf("\n\tMAIS MAGRO: %2d", codMaisMagro);
	    printf("\n\tPeso: %.1fkg\n\n", maisMagro);
	
	    printf("\n\tMÉDIA DAS ALTURAS: %.2fm", mediaAltura);
	    printf("\n\tMÉDIA DOS PESOS: %.1fkg\n\n", mediaPeso);
	}
	else {
	    printf("\n\tNinguém foi cadastrado.\n\n");
	}

	return 0;
	
}
