/*
	Seja a seguinte série:
				1, 4, 9, 16, 25, 36, ...
	Implemente um programa em C que gere esta série até o N-ésimo (último) termo. 
	Este N-ésimo termo é digitado pelo usuúrio.
*/

#include <stdio.h>

int main() {
	int num, i = 1;

	do {
		printf("Informe o numero de termos da série: ");
		scanf("%d", &num);
	} while ( num <= 0 );

	while (num > 0) {
		printf("%d\t", i*i);
		i++;
		num--;
	}	
	printf("\n");

/*
	// ####   OU   ####  
	for (i = 1;  num > 0; i++, num--  ) {
		printf("%d\t", i*i);
	}	
	printf("\n");
*/
	
	return 0;
}
