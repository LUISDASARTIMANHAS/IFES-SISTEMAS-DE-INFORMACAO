/*
	Criar um programa em C que leia os limites inferior e superior de um intervalo e imprima todos os n�meros 
	pares no intervalo aberto e seu somatório. Suponha que os dados digitados s�o para um intervalo crescente, 
	ou seja, o primeiro valor é menor que o segundo.
*/

#include <stdio.h>

int main() {
	int inferior, superior, i, soma=0;

	// Ler o limite inferior
	printf("\n\tInforme o limite inferior: ");
	scanf("%d", &inferior);

	// Ler e validar o limite SUPERIOR, que deve ser maior que o INFERIOR
	do {
		printf("\n\tInforme o limite superior: ");
		scanf("%d", &superior);
	} while ( superior <= inferior );

	printf("\n\tValores pares do intervalo\n");

	// Percorre entre os valore INFERIRO e SUPERIOR
	for( i = inferior ; i <= superior; i++){
		if ( i % 2 == 0 ) {
			printf("\t%d", i);

			// Soma o numero par
			soma = soma + i;
		}
	}
	printf("\n\n\tA soma dos números pares do intervalo é: %d\n\n", soma);

	return 0;
}
