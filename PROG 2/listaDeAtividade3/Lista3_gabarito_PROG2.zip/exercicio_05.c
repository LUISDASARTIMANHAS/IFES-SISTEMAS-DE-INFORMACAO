#include <stdio.h>

int main() {

    // Fatorial de um número
    int i, n, fat;
    
    do {
	    printf("\n\tInforme o numero: ");
	    scanf("%d", &n);
	} while ( n <= 0 );
    
	fat = 1;   
	for ( i=n ; i > 1 ; i--) {
        fat = fat * i;
    }
    printf("\n\tO fatorial: %d \n\n", fat );

    return 0;
}
