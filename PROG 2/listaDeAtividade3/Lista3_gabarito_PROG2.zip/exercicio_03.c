/*
	Criar um programa em C que leia a quantidade de números a serem lidos. 
	Depois, leia os números inteiros até essa quantidade e imprima o menor deles.  
	Suponha que todos os números lidos serão positivos, então coloque a validação 
	desses números.
*/

#include <stdio.h>

int main() {
	int qtde, menor, i, valor;
	menor = 999999;

	// indica a quantidade de números que devem ser digitados
	do {	
		printf("\n\tInforme a quantidade de numeros: ");
		scanf("%d", &qtde);
	} while ( qtde <= 0);

	// faz a leitura dos valores e encontra o menor
	for ( i = 1; i <= qtde; i++ ) {
		
		// Ler e validar cada valor
		do {
			printf("\n\tDigite o %dº valor: ", i);
			scanf("%d", &valor);
		} while ( valor <= 0) ;

		if (valor <= menor) {
			menor = valor;
		}
	}
	
	printf("\n\tO menor valor digitado foi %d\n\n", menor);
	return 0;
}
